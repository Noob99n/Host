import React, { useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";

type RestartAppModalProps = {
  isOpen: boolean;
  title?: string;
  description?: string;
};

export function RestartAppModal({
  isOpen,
  title = "Restarting Application...",
  description = "Please wait while the application restarts."
}: RestartAppModalProps) {
  // Automatically restart when modal is opened
  useEffect(() => {
    if (isOpen) {
      // Set a short timeout to show the loading spinner briefly before redirecting
      const timer = setTimeout(() => {
        window.location.href = "/auth";
      }, 1500); // 1.5 seconds delay to show loading animation
      
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  // Prevent back navigation
  useEffect(() => {
    if (isOpen) {
      const handlePopState = (e: PopStateEvent) => {
        e.preventDefault();
        window.history.pushState(null, document.title, window.location.href);
      };

      // Add state to history to make sure we can intercept back button
      window.history.pushState(null, document.title, window.location.href);
      window.addEventListener("popstate", handlePopState);

      return () => {
        window.removeEventListener("popstate", handlePopState);
      };
    }
  }, [isOpen]);

  // Prevent dialog from being closed by escape key or outside click
  const handleCloseAttempt = (open: boolean) => {
    // Do nothing when user tries to close the dialog
    if (!open) return;
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleCloseAttempt}>
      <DialogContent className="sm:max-w-md" onEscapeKeyDown={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="text-center">{title}</DialogTitle>
          <DialogDescription className="text-center">
            {description}
          </DialogDescription>
        </DialogHeader>
        <div className="mt-6 flex flex-col items-center">
          <RefreshCw className="h-16 w-16 text-primary mb-4 animate-spin" />
          <p className="text-sm text-muted-foreground">Redirecting to login page...</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}