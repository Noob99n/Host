import React from 'react';
import { useLocation, Link } from 'wouter';
import { Home, Trophy, Wallet, Menu, User } from 'lucide-react';

interface BottomNavProps {
  activeItem?: 'home' | 'leaderboard' | 'wallet' | 'more' | 'myteams';
}

const BottomNav: React.FC<BottomNavProps> = ({ activeItem = 'home' }) => {
  const [location] = useLocation();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-10 border-t bg-background shadow-sm">
      <div className="mx-auto flex h-14 max-w-md items-center justify-between px-4">
        <Link href="/matches">
          <a className={`flex flex-col items-center justify-center space-y-1 ${activeItem === 'home' ? 'text-primary' : 'text-muted-foreground'}`}>
            <Home className="h-5 w-5" />
            <span className="text-xs">Home</span>
          </a>
        </Link>
        <Link href="/my-teams">
          <a className={`flex flex-col items-center justify-center space-y-1 ${activeItem === 'myteams' ? 'text-primary' : 'text-muted-foreground'}`}>
            <User className="h-5 w-5" />
            <span className="text-xs">My Teams</span>
          </a>
        </Link>
        <Link href="/leaderboard">
          <a className={`flex flex-col items-center justify-center space-y-1 ${activeItem === 'leaderboard' ? 'text-primary' : 'text-muted-foreground'}`}>
            <Trophy className="h-5 w-5" />
            <span className="text-xs">Leaderboard</span>
          </a>
        </Link>
        <Link href="/wallet">
          <a className={`flex flex-col items-center justify-center space-y-1 ${activeItem === 'wallet' ? 'text-primary' : 'text-muted-foreground'}`}>
            <Wallet className="h-5 w-5" />
            <span className="text-xs">Wallet</span>
          </a>
        </Link>
        <Link href="/more">
          <a className={`flex flex-col items-center justify-center space-y-1 ${activeItem === 'more' ? 'text-primary' : 'text-muted-foreground'}`}>
            <Menu className="h-5 w-5" />
            <span className="text-xs">More</span>
          </a>
        </Link>
      </div>
    </div>
  );
};

export default BottomNav;