import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Player } from "@shared/schema";
import { Plus, X } from "lucide-react";

type PlayerCardProps = {
  player: Player;
  isSelected: boolean;
  onToggle: () => void;
};

export function PlayerCard({ player, isSelected, onToggle }: PlayerCardProps) {
  // Get recent performance string
  const recentPerformance = Array.isArray(player.recentPerformance) 
    ? player.recentPerformance.join(', ') 
    : '';
  
  // Determine team badge color
  const teamColor = player.team === 'IND' ? 'bg-green-500' : 'bg-yellow-500';
  
  return (
    <Card className="shadow-sm border border-neutral-200 dark:border-dark-border">
      <CardContent className="p-3">
        <div className="flex items-center">
          <div className="w-12 h-12 rounded-full overflow-hidden mr-3">
            <img src={player.image} alt={player.name} className="w-full h-full object-cover" />
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-medium">{player.name}</h3>
                <div className="flex items-center gap-2">
                  <span className={`text-xs ${teamColor} text-white px-1 rounded`}>{player.team}</span>
                  <span className="text-xs text-neutral-600 dark:text-neutral-400">{player.role}</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-sm font-medium">{player.credits} Cr</span>
                <p className="text-xs text-neutral-600 dark:text-neutral-400">
                  Sel by {player.selectionPercentage}%
                </p>
              </div>
            </div>
            <div className="flex justify-between mt-2">
              <div className="flex gap-2 text-xs">
                <span>Last 3: {recentPerformance}</span>
              </div>
              <div>
                <Button
                  size="icon"
                  variant="outline"
                  className={`w-6 h-6 rounded-full border-2 ${
                    isSelected 
                      ? 'border-red-500 bg-red-500 text-white hover:bg-red-600 hover:text-white' 
                      : 'border-primary text-primary hover:bg-primary hover:text-white'
                  }`}
                  onClick={onToggle}
                >
                  {isSelected ? (
                    <X className="h-3 w-3" />
                  ) : (
                    <Plus className="h-3 w-3" />
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
