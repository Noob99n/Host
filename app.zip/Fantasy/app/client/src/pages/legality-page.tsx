import { Header } from "@/components/layout/header";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Scale } from "lucide-react";

export default function LegalityPage() {
  const goBack = () => {
    window.history.back();
  };
  
  return (
    <div className="pb-20 min-h-screen bg-gray-50 dark:bg-dark-bg">
      <Header
        title="Legality"
        showBack
        backUrl="javascript:void(0)"
        onBackClick={goBack}
        showWallet={false}
        showNotification={false}
        className="bg-primary text-white"
      />

      <div className="p-4 max-w-[480px] mx-auto">
        <ScrollArea className="h-[calc(100vh-115px)] pr-3">
          <div className="mb-8 space-y-6">
            <section className="space-y-3">
              <h1 className="text-2xl font-bold">Legality</h1>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT offers fantasy sports games that are games of skill as recognized by the Indian legal system. This document outlines the legal framework under which we operate.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Legal Status of Fantasy Sports in India</h2>
              <p className="text-gray-700 dark:text-gray-300">
                Fantasy sports in India operate as "games of skill" as opposed to "games of chance." This distinction is crucial as games of skill are exempt from the prohibitions of gambling laws in most Indian states.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                The Supreme Court of India and several High Courts have consistently held that games where success depends on substantial skill are not "gambling" and are protected as business activities under Article 19(1)(g) of the Constitution of India.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Key Legal Judgments</h2>
              <p className="text-gray-700 dark:text-gray-300">
                Several landmark judgments have established the legal status of fantasy sports in India:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>
                  <strong>Varun Gumber v. UT of Chandigarh (2017):</strong> The Punjab and Haryana High Court ruled that fantasy sports are games of skill and not chance or gambling.
                </li>
                <li>
                  <strong>Gurdeep Singh Sachar v. Union of India (2019):</strong> The Bombay High Court affirmed that fantasy sports are games of skill, not gambling.
                </li>
                <li>
                  <strong>Avinash Mehrotra v. State of Rajasthan (2020):</strong> The Supreme Court of India dismissed special leave petitions challenging the legality of fantasy sports, effectively upholding the High Court judgments.
                </li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">State-wise Regulations</h2>
              <p className="text-gray-700 dark:text-gray-300">
                While fantasy sports are legal in most Indian states, certain states have specific regulations or prohibitions:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>
                  <strong>Assam, Odisha, Telangana, Nagaland, Sikkim, and Andhra Pradesh:</strong> These states have laws that may restrict fantasy sports with real money. Users from these states may not be able to access paid contests.
                </li>
                <li>
                  <strong>Other states:</strong> Fantasy sports are legal in all other states of India.
                </li>
              </ul>
              <p className="text-gray-700 dark:text-gray-300">
                Users are responsible for ensuring compliance with their local laws before participating in any contest on our platform.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">How 11byChatGPT Qualifies as a Game of Skill</h2>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT qualifies as a game of skill for the following reasons:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>
                  <strong>Knowledge and Research:</strong> Success depends on users' knowledge of cricket, player statistics, and match conditions.
                </li>
                <li>
                  <strong>Strategic Team Selection:</strong> Users must strategically select their team within constraints (e.g., credits, number of players from each team).
                </li>
                <li>
                  <strong>Skill-based Outcome:</strong> The outcome predominantly depends on users' skill in selecting players likely to perform well in actual matches.
                </li>
                <li>
                  <strong>Captain and Vice-Captain Selection:</strong> Strategic decisions on multipliers for specific players add another layer of skill.
                </li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Age Restrictions</h2>
              <p className="text-gray-700 dark:text-gray-300">
                In compliance with Indian law, 11byChatGPT is available only to users who are 18 years of age or older. We implement age verification measures and require users to confirm their age during registration.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Tax Compliance</h2>
              <p className="text-gray-700 dark:text-gray-300">
                In accordance with Indian tax laws, Tax Deducted at Source (TDS) at the rate of 30% is applicable on winnings exceeding ₹10,000 in a single contest. 11byChatGPT complies with these regulations by deducting appropriate taxes before processing withdrawals.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                Users are provided with TDS certificates for their records and for filing income tax returns.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Responsible Gaming</h2>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT is committed to promoting responsible gaming. We have implemented various measures to ensure user protection:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>
                  <strong>Deposit Limits:</strong> Users can set daily, weekly, or monthly deposit limits.
                </li>
                <li>
                  <strong>Self-exclusion:</strong> Users can opt for self-exclusion for a specified period.
                </li>
                <li>
                  <strong>Reality Checks:</strong> Periodic reminders about the time spent on the platform.
                </li>
                <li>
                  <strong>Educational Resources:</strong> Information about responsible gaming practices.
                </li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Legal Disclaimer</h2>
              <p className="text-gray-700 dark:text-gray-300">
                This document is for informational purposes only and does not constitute legal advice. The legal status of fantasy sports is subject to change based on future legislation or judicial decisions. Users are advised to seek independent legal advice regarding the laws applicable in their jurisdiction.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                Last updated: April 11, 2025
              </p>
            </section>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}