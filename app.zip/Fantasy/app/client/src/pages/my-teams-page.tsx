import { useQuery } from "@tanstack/react-query";
import { Team } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { NavBar } from "@/components/layout/nav-bar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Users } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function MyTeamsPage() {
  const [, setLocation] = useLocation();
  
  const { data: teams, isLoading, error } = useQuery<Team[]>({
    queryKey: ['/api/teams'],
  });
  
  return (
    <div className="min-h-screen flex flex-col pb-16">
      <Header 
        title="My Teams"
        showWallet={true}
      />
      
      <div className="flex-1 p-4">
        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="text-center py-8 text-red-500">
            Failed to load teams. Please try again.
          </div>
        ) : !teams || teams.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="w-16 h-16 bg-neutral-100 dark:bg-dark-bg rounded-full flex items-center justify-center mb-4">
              <Users className="h-8 w-8 text-neutral-500" />
            </div>
            <h3 className="text-lg font-medium mb-2">No Teams Created Yet</h3>
            <p className="text-neutral-600 dark:text-neutral-400 mb-6 max-w-xs">
              Create your own fantasy cricket team to participate in contests
            </p>
            <Link href="/matches">
              <Button>Browse Matches</Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex justify-between items-center mb-2">
              <h2 className="text-lg font-medium">My Teams ({teams.length})</h2>
              <Button variant="outline" size="sm">
                Filter
              </Button>
            </div>
            
            {teams.map((team) => (
              <Card key={team.id} className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="bg-primary p-3 text-white">
                    <div className="flex justify-between items-center">
                      <h3 className="font-medium">{team.name}</h3>
                      <span className="text-xs bg-white bg-opacity-20 px-2 py-0.5 rounded">
                        {new Date(team.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  
                  <div className="p-3">
                    <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-2">
                      Team for Match #{team.matchId}
                    </p>
                    
                    <div className="flex justify-between mb-3">
                      <div>
                        <p className="text-xs text-neutral-500">Captain</p>
                        <p className="font-medium">Player #{team.captain}</p>
                      </div>
                      <div>
                        <p className="text-xs text-neutral-500">Vice Captain</p>
                        <p className="font-medium">Player #{team.viceCaptain}</p>
                      </div>
                    </div>
                    
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => setLocation(`/matches/${team.matchId}`)}
                    >
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
      
      <NavBar />
    </div>
  );
}
