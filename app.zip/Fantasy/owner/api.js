// Owner Control Panel API module
window.ownerAPI = {
  // Base API URL handling for development and production
  baseApiUrl: '/api/owner',
  
  // Function to handle API requests with error handling
  async apiRequest(url, method = 'GET', data = null) {
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json'
      },
      credentials: 'include', // Important for session cookies
    };
    
    if (data && (method === 'POST' || method === 'PATCH' || method === 'PUT')) {
      options.body = JSON.stringify(data);
    }
    
    try {
      const response = await fetch(`${this.baseApiUrl}${url}`, options);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Unknown error' }));
        throw new Error(errorData.message || `API error: ${response.status}`);
      }
      
      // Check if response has content
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        return await response.json();
      }
      
      return { success: true };
    } catch (error) {
      console.error('API Request failed:', error);
      throw error;
    }
  },

  // Authentication
  loginOwner: async function(username, password) {
    try {
      console.log("Attempting to login with:", { username });
      const result = await this.apiRequest('/login', 'POST', { username, password });
      console.log("Login result:", result);
      // Set local storage for backup client-side check
      localStorage.setItem('ownerLoggedIn', 'true');
      return result;
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    }
  },
  
  checkAuthStatus: async function() {
    try {
      const result = await this.apiRequest('/check-auth');
      return result.authenticated === true;
    } catch (error) {
      console.error('Auth check failed:', error);
      // Clear local flag on failure
      localStorage.removeItem('ownerLoggedIn');
      return false;
    }
  },
  
  logoutOwner: async function() {
    try {
      localStorage.removeItem('ownerLoggedIn');
      // Also invalidate the session on the server
      await this.apiRequest('/logout', 'POST');
      return true;
    } catch (error) {
      console.error('Logout API call failed:', error);
      // Still return true to allow client-side logout
      return true;
    }
  },
  
  // Dashboard data
  getDashboardStats: async function() {
    try {
      return await this.apiRequest('/dashboard-stats');
    } catch (error) {
      console.error('Failed to fetch dashboard stats:', error);
      throw error;
    }
  },
  
  // User management
  getUsers: async function() {
    try {
      return await this.apiRequest('/users');
    } catch (error) {
      console.error('Failed to fetch users:', error);
      throw error;
    }
  },
  
  getUserDetails: async function(userId) {
    try {
      return await this.apiRequest(`/users/${userId}`);
    } catch (error) {
      console.error(`Failed to fetch user ${userId} details:`, error);
      throw error;
    }
  },
  
  updateUser: async function(userId, userData) {
    try {
      return await this.apiRequest(`/users/${userId}`, 'PATCH', userData);
    } catch (error) {
      console.error(`Failed to update user ${userId}:`, error);
      throw error;
    }
  },
  
  deleteUser: async function(userId) {
    try {
      return await this.apiRequest(`/users/${userId}`, 'DELETE');
    } catch (error) {
      console.error(`Failed to delete user ${userId}:`, error);
      throw error;
    }
  },
  
  // Verification management
  getVerifications: async function(status = 'pending', type = 'all') {
    try {
      const queryParams = `status=${status}&type=${type}`;
      return await this.apiRequest(`/verifications?${queryParams}`);
    } catch (error) {
      console.error(`Failed to fetch verifications with status ${status} and type ${type}:`, error);
      throw error;
    }
  },
  
  getVerificationDetails: async function(verificationId) {
    try {
      return await this.apiRequest(`/verification/${verificationId}`);
    } catch (error) {
      console.error(`Failed to fetch verification ${verificationId} details:`, error);
      throw error;
    }
  },
  
  getUserVerifications: async function(userId) {
    try {
      return await this.apiRequest(`/users/${userId}/verifications`);
    } catch (error) {
      console.error(`Failed to fetch verifications for user ${userId}:`, error);
      throw error;
    }
  },
  
  updateVerificationStatus: async function(userId, type, status) {
    try {
      return await this.apiRequest(`/verification/${userId}/${type}/${status}`, 'PATCH');
    } catch (error) {
      console.error(`Failed to update verification status for user ${userId}, type ${type}:`, error);
      throw error;
    }
  },
  
  // Deposit management
  getDeposits: async function(status = 'all', forceRefresh = false) {
    try {
      // Add timestamp to prevent caching issues
      const timestamp = Date.now();
      // Always use timestamp to avoid caching issues with pending status
      const queryParams = `status=${status}&t=${timestamp}`;
      
      console.log(`[getDeposits] Fetching deposits with status: ${status}, timestamp: ${timestamp}`);
      const deposits = await this.apiRequest(`/deposits?${queryParams}`);
      console.log(`[getDeposits] Retrieved ${deposits.length} deposits with status: ${status}`);
      
      // Log any pending deposits to help debug
      if (status === 'pending' || status === 'all') {
        const pendingDeposits = deposits.filter(d => d.status === 'pending');
        if (pendingDeposits.length > 0) {
          console.log(`[getDeposits] Found ${pendingDeposits.length} pending deposits:`, 
            pendingDeposits.map(d => ({ id: d.id, amount: d.amount, date: d.createdAt })));
        }
      }
      
      return deposits;
    } catch (error) {
      console.error('[getDeposits] Failed to fetch deposits:', error);
      throw error;
    }
  },
  
  updateDepositStatus: async function(depositId, status) {
    try {
      console.log(`Calling API to update deposit ${depositId} status to ${status}`);
      const result = await this.apiRequest(`/deposits/${depositId}`, 'PATCH', { status });
      console.log(`API response for deposit update:`, result);
      return result;
    } catch (error) {
      console.error(`Failed to update deposit ${depositId} status:`, error);
      throw error;
    }
  },
  
  // Withdrawal management
  getWithdrawals: async function(status = 'all', forceRefresh = false) {
    try {
      // Always add timestamp to prevent browser caching issues
      const timestamp = Date.now();
      const result = await this.apiRequest(`/withdrawals?status=${status}&_t=${timestamp}`);
      console.log("Retrieved withdrawals with status:", status, "at time:", timestamp, "Result count:", result.length);
      return result;
    } catch (error) {
      console.error('Failed to fetch withdrawals:', error);
      throw error;
    }
  },
  
  updateWithdrawalStatus: async function(withdrawalId, status, comment) {
    try {
      console.log(`Sending API request to update withdrawal #${withdrawalId} to ${status} ${comment ? 'with comment' : ''}`);
      
      // Randomize request to avoid caching issues
      const timestamp = Date.now();
      const result = await this.apiRequest(`/withdrawals/${withdrawalId}?t=${timestamp}`, 'PATCH', { 
        status, 
        comment: comment || undefined 
      });
      
      console.log(`API response for update:`, result);
      
      // Force a full reload of the main list to get fresh data
      setTimeout(() => {
        this.getWithdrawals('all', true);
      }, 500);
      
      return result;
    } catch (error) {
      console.error(`Failed to update withdrawal ${withdrawalId} status:`, error);
      throw error;
    }
  },
  
  approveWithdrawal: async function(withdrawalId) {
    try {
      console.log(`Approving withdrawal ${withdrawalId} with timestamp ${Date.now()}`);
      
      // Update button states immediately in UI
      const approveBtn = document.querySelector(`[data-withdrawal-id="${withdrawalId}"].approve-btn`);
      const rejectBtn = document.querySelector(`[data-withdrawal-id="${withdrawalId}"].reject-btn`);
      const statusCell = document.querySelector(`[data-withdrawal-id="${withdrawalId}"].status-cell`);
      
      if (approveBtn) approveBtn.disabled = true;
      if (rejectBtn) rejectBtn.disabled = true;
      if (statusCell) {
        statusCell.textContent = "Processing...";
        statusCell.className = "status-cell text-yellow-500";
      }
      
      // Call API with cache-busting timestamp
      const timestamp = Date.now();
      console.log(`Making API request to approve withdrawal #${withdrawalId} at ${timestamp}`);
      
      // Using PATCH method with explicit approval endpoint to avoid caching issues
      const result = await this.apiRequest(`/withdrawals/${withdrawalId}?_t=${timestamp}`, 'PATCH', { 
        status: 'completed' 
      });
      
      console.log(`API result after approval (${timestamp}):`, result);
      
      // Update UI after successful API call
      if (statusCell) {
        statusCell.textContent = "Completed";
        statusCell.className = "status-cell text-green-500";
      }
      
      // Force reload of withdrawals data to ensure we get the latest status
      console.log(`Scheduling refresh of withdrawals list`);
      
      setTimeout(() => {
        console.log(`Executing forced refresh of withdrawals data`);
        window.location.hash = '#withdrawals'; // Change to withdrawal section
        loadWithdrawals(); // Explicitly call load function
      }, 1000);
      
      return result;
    } catch (error) {
      console.error(`Failed to approve withdrawal ${withdrawalId}:`, error);
      alert(`Error approving withdrawal: ${error.message || 'Unknown error'}`);
      throw error;
    }
  },
  
  rejectWithdrawal: async function(withdrawalId, reason) {
    try {
      console.log(`Rejecting withdrawal ${withdrawalId} with reason: ${reason} and timestamp ${Date.now()}`);
      
      // Update button states immediately in UI
      const approveBtn = document.querySelector(`[data-withdrawal-id="${withdrawalId}"].approve-btn`);
      const rejectBtn = document.querySelector(`[data-withdrawal-id="${withdrawalId}"].reject-btn`);
      const statusCell = document.querySelector(`[data-withdrawal-id="${withdrawalId}"].status-cell`);
      
      if (approveBtn) approveBtn.disabled = true;
      if (rejectBtn) rejectBtn.disabled = true;
      if (statusCell) {
        statusCell.textContent = "Processing...";
        statusCell.className = "status-cell text-yellow-500";
      }
      
      // Call API with cache-busting timestamp 
      const timestamp = Date.now();
      console.log(`Making API request to reject withdrawal #${withdrawalId} at ${timestamp}`);
      
      // Using PATCH method with explicit reject data to avoid caching issues
      const result = await this.apiRequest(`/withdrawals/${withdrawalId}?_t=${timestamp}`, 'PATCH', { 
        status: 'rejected',
        comment: reason
      });
      
      console.log(`API result after rejection (${timestamp}):`, result);
      
      // Update UI after successful API call
      if (statusCell) {
        statusCell.textContent = "Rejected";
        statusCell.className = "status-cell text-red-500";
      }
      
      // Force reload of withdrawals data to ensure we get the latest status
      console.log(`Scheduling refresh of withdrawals list after rejection`);
      
      setTimeout(() => {
        console.log(`Executing forced refresh of withdrawals data after rejection`);
        window.location.hash = '#withdrawals'; // Change to withdrawal section
        loadWithdrawals(); // Explicitly call load function
      }, 1000);
      
      return result;
    } catch (error) {
      console.error(`Failed to reject withdrawal ${withdrawalId}:`, error);
      alert(`Error rejecting withdrawal: ${error.message || 'Unknown error'}`);
      throw error;
    }
  },
  
  // Verification management
  getVerifications: async function(status = 'pending', type = 'all') {
    try {
      console.log(`Fetching verifications with status=${status}, type=${type}`);
      return await this.apiRequest(`/verifications?status=${status}&type=${type}`);
    } catch (error) {
      console.error(`Failed to fetch verifications:`, error);
      throw error;
    }
  },
  
  getVerificationsByType: async function(type, status = 'pending') {
    try {
      return await this.apiRequest(`/verifications/${type}?status=${status}`);
    } catch (error) {
      console.error(`Failed to fetch ${type} verifications:`, error);
      throw error;
    }
  },
  
  getVerificationDetails: async function(id) {
    try {
      return await this.apiRequest(`/verification/${id}`);
    } catch (error) {
      console.error('Failed to fetch verification details:', error);
      throw error;
    }
  },
  
  updateVerificationStatus: async function(userId, type, status) {
    try {
      console.log(`Calling API to update ${type} verification for user ${userId} to status: ${status}`);
      // The base URL /api/owner is automatically added by apiRequest
      const result = await this.apiRequest(`/verification/update`, 'POST', {
        userId: parseInt(userId),
        type,
        status
      });
      console.log(`API response for verification update:`, result);
      return result;
    } catch (error) {
      console.error(`Failed to update verification status:`, error);
      throw error;
    }
  },
  
  // Legacy method - kept for compatibility
  updateVerificationById: async function(verificationId, status) {
    try {
      console.log(`Calling API to update verification ${verificationId} status to ${status}`);
      const result = await this.apiRequest(`/verification/${verificationId}`, 'PATCH', { status });
      console.log(`API response for verification update:`, result);
      return result;
    } catch (error) {
      console.error(`Failed to update verification ${verificationId} status:`, error);
      throw error;
    }
  },
  
  // Transaction management
  getTransactions: async function(type = 'all', forceRefresh = false) {
    try {
      // Add timestamp to prevent caching issues
      const timestamp = Date.now();
      const queryParams = forceRefresh ? `type=${type}&t=${timestamp}` : `type=${type}`;
      
      console.log(`Fetching transactions of type: ${type}${forceRefresh ? ' (force refresh)' : ''}`);
      const transactions = await this.apiRequest(`/transactions?${queryParams}`);
      console.log(`Fetched ${transactions.length} transactions of type: ${type}`);
      return transactions;
    } catch (error) {
      console.error('Failed to fetch transactions:', error);
      throw error;
    }
  },
  
  // Match management
  getMatches: async function() {
    try {
      return await this.apiRequest('/matches');
    } catch (error) {
      console.error('Failed to fetch matches:', error);
      throw error;
    }
  },
  
  createMatch: async function(matchData) {
    try {
      return await this.apiRequest('/matches', 'POST', matchData);
    } catch (error) {
      console.error('Failed to create match:', error);
      throw error;
    }
  },
  
  updateMatchStatus: async function(matchId, status) {
    try {
      return await this.apiRequest(`/matches/${matchId}`, 'PATCH', { status });
    } catch (error) {
      console.error(`Failed to update match ${matchId} status:`, error);
      throw error;
    }
  },
  
  // User management functions
  getUserDetails: async function(userId) {
    try {
      return await this.apiRequest(`/users/${userId}`);
    } catch (error) {
      console.error(`Failed to get user details for user ${userId}:`, error);
      throw error;
    }
  },
  
  // Get user's verifications
  getUserVerifications: async function(userId) {
    try {
      if (!userId) {
        console.error("[OwnerAPI] Invalid user ID for verifications:", userId);
        return [];
      }
      
      console.log(`[OwnerAPI] Getting verifications for user ID: ${userId}`);
      const fullPath = `/users/${userId}/verifications`;
      console.log(`[OwnerAPI] Verification API path: ${fullPath}`);
      
      try {
        return await this.apiRequest(fullPath);
      } catch (verificationError) {
        console.error(`[OwnerAPI] Verification API error for user ${userId}:`, verificationError);
        console.log(`[OwnerAPI] Falling back to empty array for verifications`);
        return [];
      }
    } catch (error) {
      console.error(`[OwnerAPI] Failed to get verifications for user ${userId}:`, error);
      return [];
    }
  },
  
  updateUser: async function(userId, userData) {
    try {
      return await this.apiRequest(`/users/${userId}`, 'PATCH', userData);
    } catch (error) {
      console.error(`Failed to update user ${userId}:`, error);
      throw error;
    }
  },
  
  deleteUser: async function(userId) {
    try {
      return await this.apiRequest(`/users/${userId}`, 'DELETE');
    } catch (error) {
      console.error(`Failed to delete user ${userId}:`, error);
      throw error;
    }
  }
};