import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Header } from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  User, Settings, LogOut, Wallet, Gift, Trophy, Bell, Shield, 
  HelpCircle, Book, ChevronRight, CreditCard, Edit, RefreshCw
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link, useLocation } from "wouter";
import { EditProfileModal } from "@/components/profile/edit-profile-modal";
import { queryClient } from "@/lib/queryClient";
import PullToRefresh from "@/components/custom/PullToRefresh";

export default function ProfilePage() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  // Handle logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Format date for joined date
  const formatJoinedDate = (date: Date | undefined | string | null) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleDateString('en-US', {
      month: 'long',
      year: 'numeric'
    });
  };

  // Get user initials for avatar
  const getUserInitials = (name: string | undefined) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };
  
  // Handle refresh - refresh user data when the page is pulled down
  const handleRefresh = async () => {
    toast({
      title: "Refreshing profile...",
      description: "Getting the latest data",
    });
    
    try {
      // Invalidate and refetch user data
      await queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      
      // Show success toast
      toast({
        title: "Profile refreshed",
        description: "Your profile has been updated with the latest data",
      });
    } catch (error) {
      toast({
        title: "Error refreshing profile",
        description: "Please try again later",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col pb-8">
      <Header 
        showBack={true}
        backUrl="/"
        title="Profile"
      />
      
      <PullToRefresh 
        onRefresh={handleRefresh}
        className="flex-1"
      >
        <div className="p-4 space-y-6">
        {/* User Profile Card */}
        <div className="flex items-center">
          <Avatar className="h-16 w-16 mr-4">
            <AvatarImage 
              src={user?.photo_url || ""} 
              alt={user?.full_name || user?.username || "User"} 
            />
            <AvatarFallback>{getUserInitials(user?.full_name || user?.username)}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex items-center">
              <h2 className="text-xl font-semibold">{user?.full_name || user?.username}</h2>
              <EditProfileModal />
            </div>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Joined {formatJoinedDate(user?.created_at)}
            </p>
            <div className="flex gap-2 mt-1">
              <Badge variant="outline" className="text-xs px-2 py-0.5 bg-primary/10 text-primary">
                Cricket Expert
              </Badge>
            </div>
          </div>
        </div>
        
        {/* Stats Overview */}
        <div className="grid grid-cols-3 gap-3">
          <Card>
            <CardContent className="p-3 text-center">
              <p className="text-sm text-neutral-600 dark:text-neutral-400">Balance</p>
              <p className="text-lg font-semibold">₹{user?.balance || 0}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <p className="text-sm text-neutral-600 dark:text-neutral-400">Winnings</p>
              <p className="text-lg font-semibold">₹{user?.winnings || 0}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <p className="text-sm text-neutral-600 dark:text-neutral-400">Bonus</p>
              <p className="text-lg font-semibold">₹{user?.bonus || 0}</p>
            </CardContent>
          </Card>
        </div>
        
        {/* Settings Menu */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Settings</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-neutral-200 dark:divide-dark-border">
              <Link href="/wallet">
                <div className="flex items-center justify-between p-4 hover:bg-neutral-50 dark:hover:bg-dark-card cursor-pointer">
                  <div className="flex items-center">
                    <Wallet className="h-5 w-5 mr-3 text-neutral-600" />
                    <span>My Wallet</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-neutral-400" />
                </div>
              </Link>
              
              <Link href="/notifications">
                <div className="flex items-center justify-between p-4 hover:bg-neutral-50 dark:hover:bg-dark-card cursor-pointer">
                  <div className="flex items-center">
                    <Bell className="h-5 w-5 mr-3 text-neutral-600" />
                    <span>Notifications</span>
                  </div>
                  <Badge className="bg-primary text-white rounded-full h-5 w-5 flex items-center justify-center text-xs">
                    2
                  </Badge>
                </div>
              </Link>
              
              <div className="flex items-center justify-between p-4 hover:bg-neutral-50 dark:hover:bg-dark-card cursor-pointer">
                <div className="flex items-center">
                  <CreditCard className="h-5 w-5 mr-3 text-neutral-600" />
                  <span>Payment Methods</span>
                </div>
                <Badge className="bg-gray-200 text-gray-500 dark:bg-gray-700 dark:text-gray-400 text-xs font-normal">
                  Coming Soon
                </Badge>
              </div>
              
              <Link href="/verify-account">
                <div className="flex items-center justify-between p-4 hover:bg-neutral-50 dark:hover:bg-dark-card cursor-pointer">
                  <div className="flex items-center">
                    <User className="h-5 w-5 mr-3 text-neutral-600" />
                    <span>Account Details</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-neutral-400" />
                </div>
              </Link>
              

            </div>
          </CardContent>
        </Card>
        
        {/* Help & Support */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Help & Support</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-neutral-200 dark:divide-dark-border">
              <Link href="/help-center">
                <div className="flex items-center justify-between p-4 hover:bg-neutral-50 dark:hover:bg-dark-card cursor-pointer">
                  <div className="flex items-center">
                    <HelpCircle className="h-5 w-5 mr-3 text-neutral-600" />
                    <span>Help Center</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-neutral-400" />
                </div>
              </Link>
              
              <Link href="/terms-and-conditions">
                <div className="flex items-center justify-between p-4 hover:bg-neutral-50 dark:hover:bg-dark-card cursor-pointer">
                  <div className="flex items-center">
                    <Book className="h-5 w-5 mr-3 text-neutral-600" />
                    <span>Terms & Conditions</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-neutral-400" />
                </div>
              </Link>
              
              <Link href="/privacy-policy">
                <div className="flex items-center justify-between p-4 hover:bg-neutral-50 dark:hover:bg-dark-card cursor-pointer">
                  <div className="flex items-center">
                    <Shield className="h-5 w-5 mr-3 text-neutral-600" />
                    <span>Privacy Policy</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-neutral-400" />
                </div>
              </Link>
            </div>
          </CardContent>
        </Card>
        
        {/* Logout Button */}
        <Button 
          variant="destructive" 
          className="w-full"
          onClick={handleLogout}
          disabled={logoutMutation.isPending}
        >
          {logoutMutation.isPending ? (
            "Logging out..."
          ) : (
            <>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </>
          )}
        </Button>
        
        {/* App Version */}
        <p className="text-center text-xs text-neutral-500 dark:text-neutral-400 mt-6">
          11byChatGPT v1.0.0
        </p>
      </div>
      </PullToRefresh>
    </div>
  );
}
