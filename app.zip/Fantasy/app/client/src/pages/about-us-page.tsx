import { Header } from "@/components/layout/header";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Info } from "lucide-react";
import { SiOpenai } from "react-icons/si";

export default function AboutUsPage() {
  const goBack = () => {
    window.history.back();
  };
  
  return (
    <div className="pb-20 min-h-screen bg-gray-50 dark:bg-dark-bg">
      <Header
        title="About Us"
        showBack
        backUrl="javascript:void(0)"
        onBackClick={goBack}
        showWallet={false}
        showNotification={false}
        className="bg-primary text-white"
      />

      <div className="p-4 max-w-[480px] mx-auto">
        <ScrollArea className="h-[calc(100vh-115px)] pr-3">
          <div className="mb-8 space-y-6">
            <section className="flex flex-col items-center justify-center space-y-3 text-center mb-6">
              <div className="h-24 w-24 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-lg">
                <SiOpenai className="h-12 w-12 text-white" />
              </div>
              <h1 className="text-2xl font-bold">11byChatGPT</h1>
              <p className="text-gray-600 dark:text-gray-400 text-sm">Version 1.0.0</p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Our Story</h2>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT was created in April 2025 as an innovative fantasy cricket platform built with the assistance of AI technologies, specifically OpenAI's ChatGPT. Our platform represents a unique blend of human creativity and artificial intelligence capabilities.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                This application is <strong>not</strong> an official OpenAI product. Rather, it demonstrates how AI can be leveraged to create sophisticated web applications with the guidance of human developers who provide the vision and domain expertise.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">AI-Assisted Development</h2>
              <p className="text-gray-700 dark:text-gray-300">
                The code for 11byChatGPT was written with the assistance of AI, where ChatGPT helped with:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>Application architecture design</li>
                <li>React component creation and styling</li>
                <li>Backend API implementation</li>
                <li>Database schema design</li>
                <li>Integration of authentication systems</li>
                <li>Implementation of fantasy cricket logic</li>
              </ul>
              <p className="text-gray-700 dark:text-gray-300">
                Human developers provided the creative direction, requirements, and iterative feedback that shaped the final product. This collaboration showcases how AI can empower developers to build complex applications efficiently.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Our Mission</h2>
              <p className="text-gray-700 dark:text-gray-300">
                At 11byChatGPT, our mission is to provide cricket fans with an engaging, fair, and user-friendly platform to enjoy fantasy cricket. We aim to enhance your cricket viewing experience by adding an interactive dimension that tests your knowledge and strategic thinking.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                We're committed to:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>Creating a safe and reliable gaming environment</li>
                <li>Ensuring fair play through transparent scoring systems</li>
                <li>Continuously improving our platform based on user feedback</li>
                <li>Innovating with new features that enhance the fantasy cricket experience</li>
                <li>Promoting responsible gaming practices</li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Our Team</h2>
              <p className="text-gray-700 dark:text-gray-300">
                Behind 11byChatGPT is a team of cricket enthusiasts and technology professionals who believe in the power of AI to transform digital experiences. Our team brings together expertise in:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>Cricket analytics and statistics</li>
                <li>Web application development</li>
                <li>User experience design</li>
                <li>AI and machine learning implementation</li>
                <li>Cybersecurity and data protection</li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Technology Stack</h2>
              <p className="text-gray-700 dark:text-gray-300">
                Our platform is built using modern web technologies:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>Frontend: React.js with TypeScript</li>
                <li>State Management: TanStack Query</li>
                <li>UI Components: Tailwind CSS with custom components</li>
                <li>Backend: Node.js with Express</li>
                <li>Database: PostgreSQL with Drizzle ORM</li>
                <li>Authentication: Custom JWT implementation</li>
                <li>Payment Processing: Secure payment gateway integration</li>
              </ul>
              <p className="text-gray-700 dark:text-gray-300">
                The application was created with the assistance of AI coding tools, demonstrating the potential of AI-human collaboration in software development.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Contact Us</h2>
              <p className="text-gray-700 dark:text-gray-300">
                We value your feedback and are here to assist with any questions or concerns. You can reach our team at:
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                Email: support@11bychatgpt.com<br />
                Customer Support: +91 (800) 555-1234<br />
                Office Hours: Monday to Friday, 9:00 AM to 6:00 PM IST
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                For business inquiries: business@11bychatgpt.com
              </p>
            </section>

            <section className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700 text-center">
              <p className="text-gray-500 dark:text-gray-400 text-sm">
                © 2025 11byChatGPT. All rights reserved.
              </p>
              <p className="text-gray-500 dark:text-gray-400 text-xs mt-1">
                Created with the assistance of OpenAI's ChatGPT
              </p>
            </section>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}