import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ProgressBar } from "@/components/ui/progress-bar";
import { Trophy } from "lucide-react";
import { Contest } from "@shared/schema";
import { cn } from "@/lib/utils";

type ContestCardProps = {
  contest: Contest;
  onClick?: () => void;
};

export function ContestCard({ contest, onClick }: ContestCardProps) {
  // Calculate spots filled percentage
  const spotsFilled = contest.filledSpots;
  const spotsLeft = contest.totalSpots - spotsFilled;
  const fillPercentage = (spotsFilled / contest.totalSpots) * 100;
  
  // Determine contest type colors and badge
  const typeColors = {
    popular: {
      bg: "bg-accent bg-opacity-10 dark:bg-opacity-20",
      border: "border-accent border-opacity-20",
      text: "text-accent",
      badge: "bg-accent text-white",
      label: "POPULAR",
    },
    new: {
      bg: "bg-secondary bg-opacity-10 dark:bg-opacity-20",
      border: "border-secondary border-opacity-20",
      text: "text-secondary",
      badge: "bg-secondary text-white",
      label: "NEW",
    },
    h2h: {
      bg: "bg-primary bg-opacity-10 dark:bg-opacity-20",
      border: "border-primary border-opacity-20",
      text: "text-primary",
      badge: "",
      label: "",
    },
    default: {
      bg: "bg-primary bg-opacity-10 dark:bg-opacity-20",
      border: "border-primary border-opacity-20",
      text: "text-primary",
      badge: "",
      label: "",
    },
  };
  
  const typeStyle = typeColors[contest.type as keyof typeof typeColors] || typeColors.default;
  
  // Format prize amounts (convert to Lakhs/K for readability)
  const formatPrize = (amount: number) => {
    if (amount >= 100000) {
      return `₹${(amount / 100000).toFixed(1)} Lakhs`;
    } else if (amount >= 1000) {
      return `₹${(amount / 1000).toFixed(1)}K`;
    } else {
      return `₹${amount}`;
    }
  };
  
  return (
    <Card 
      className="shadow-sm border border-neutral-200 dark:border-dark-border hover:shadow-md transition-shadow overflow-hidden"
      onClick={onClick}
    >
      <div className={cn("p-3 border-b", typeStyle.bg, typeStyle.border)}>
        <div className="flex justify-between items-center">
          <h3 className={cn("font-semibold", typeStyle.text)}>{contest.name}</h3>
          {typeStyle.badge && (
            <span className={cn("text-xs px-2 py-0.5 rounded", typeStyle.badge)}>
              {typeStyle.label}
            </span>
          )}
        </div>
        <p className="text-sm text-neutral-600 dark:text-neutral-400">
          {contest.type === 'popular' && "Win big with the biggest prize pool"}
          {contest.type === 'new' && "Perfect for first-time players"}
          {contest.type === 'h2h' && "Compete against one opponent"}
        </p>
      </div>
      
      <div className="p-3">
        <div className="flex justify-between mb-2">
          <div>
            <h4 className="font-semibold text-lg">{formatPrize(contest.prizePool)}</h4>
            <p className="text-xs text-neutral-600 dark:text-neutral-400">Prize Pool</p>
          </div>
          <div className="text-right">
            <h4 className="font-semibold text-lg">₹{contest.entryFee}</h4>
            <p className="text-xs text-neutral-600 dark:text-neutral-400">Entry Fee</p>
          </div>
        </div>
        
        <div className="mb-2">
          <div className="flex justify-between text-sm mb-1">
            <span>{contest.totalSpots} spots</span>
            <span>{spotsLeft} spots left</span>
          </div>
          <ProgressBar value={fillPercentage} max={100} />
        </div>
        
        <div className="flex justify-between items-center mt-3">
          <div className="flex items-center gap-2">
            <Trophy className="text-primary h-4 w-4" />
            <span className="text-sm">₹{formatPrize(contest.firstPrize)} to 1st</span>
          </div>
          <Button size="sm">
            Join
          </Button>
        </div>
      </div>
    </Card>
  );
}
