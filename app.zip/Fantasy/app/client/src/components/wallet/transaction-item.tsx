import { Transaction } from "@shared/schema";
import { ArrowDownRight, ArrowUpRight, Trophy, Check, Clock, XCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

type TransactionItemProps = {
  transaction: Transaction;
};

export function TransactionItem({ transaction }: TransactionItemProps) {
  // Determine transaction icon and color based on type
  const getTransactionDetails = () => {
    if (transaction.type === 'credit') {
      if (transaction.description === 'Money Added') {
        return {
          icon: <ArrowDownRight className="text-green-500" />,
          bgColor: 'bg-green-500 bg-opacity-10',
          textColor: getStatusColor(transaction.status, 'credit'),
          sign: '+',
        };
      } else if (transaction.description.includes('Contest')) {
        return {
          icon: <Trophy className="text-primary" />,
          bgColor: 'bg-primary bg-opacity-10',
          textColor: 'text-green-500',
          sign: '+',
        };
      } else if (transaction.description.includes('Referral')) {
        return {
          icon: <ArrowDownRight className="text-green-500" />,
          bgColor: 'bg-green-500 bg-opacity-10',
          textColor: 'text-green-500',
          sign: '+',
        };
      } else {
        return {
          icon: <ArrowDownRight className="text-green-500" />,
          bgColor: 'bg-green-500 bg-opacity-10',
          textColor: getStatusColor(transaction.status, 'credit'),
          sign: '+',
        };
      }
    } else {
      return {
        icon: <ArrowUpRight className="text-red-500" />,
        bgColor: 'bg-red-500 bg-opacity-10',
        textColor: getStatusColor(transaction.status, 'debit'),
        sign: '-',
      };
    }
  };

  // Get status color based on transaction status
  const getStatusColor = (status: string, type: 'credit' | 'debit') => {
    if (status === 'completed') {
      return 'text-green-500';
    } else if (status === 'pending') {
      return 'text-amber-500';
    } else if (status === 'rejected') {
      return 'text-red-500';
    }
    return type === 'credit' ? 'text-green-500' : 'text-red-500';
  };

  // Get status indicator for transaction
  const getStatusIndicator = () => {
    if (transaction.status === 'completed') {
      return <Check size={14} className="ml-1 text-green-500" />;
    } else if (transaction.status === 'pending') {
      return <Clock size={14} className="ml-1 text-amber-500" />;
    } else if (transaction.status === 'rejected') {
      return <XCircle size={14} className="ml-1 text-red-500" />;
    }
    return null;
  };

  const { icon, bgColor, textColor, sign } = getTransactionDetails();
  
  // Format date
  const formattedDate = transaction.createdAt ? formatDistanceToNow(new Date(transaction.createdAt), { addSuffix: true }) : '';

  return (
    <div className="flex justify-between items-center">
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-full ${bgColor} flex items-center justify-center`}>
          {icon}
        </div>
        <div>
          <h4 className="font-medium flex items-center">
            {transaction.description}
            {getStatusIndicator()}
          </h4>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">{formattedDate}</p>
        </div>
      </div>
      <span className={`font-medium ${textColor}`}>{sign}₹{transaction.amount}</span>
    </div>
  );
}
