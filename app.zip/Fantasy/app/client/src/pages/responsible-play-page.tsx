import { Header } from "@/components/layout/header";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ShieldCheck, AlertTriangle, Clock, BrainCircuit, Users, Ban, BadgeInfo, Megaphone, Timer } from "lucide-react";

export default function ResponsiblePlayPage() {
  const goBack = () => {
    window.history.back();
  };
  
  return (
    <div className="pb-20 min-h-screen bg-gray-50 dark:bg-dark-bg">
      <Header
        title="Responsible Play"
        showBack
        backUrl="javascript:void(0)"
        onBackClick={goBack}
        showWallet={false}
        showNotification={false}
        className="bg-primary text-white"
      />

      <div className="p-4 max-w-[480px] mx-auto">
        <ScrollArea className="h-[calc(100vh-115px)] pr-3">
          <div className="mb-8 space-y-6">
            <section className="space-y-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-6 w-6 text-green-600" />
                <h1 className="text-2xl font-bold">Responsible Play</h1>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                At 11byChatGPT, we're committed to providing a safe, fun, and responsible gaming environment. While fantasy sports are games of skill that can be enjoyed by adults, we believe in promoting responsible play habits among our users.
              </p>
            </section>

            <section className="space-y-3 bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-900/30">
              <div className="flex items-center gap-2">
                <BrainCircuit className="h-6 w-6 text-green-600" />
                <h2 className="text-xl font-bold">Fantasy Cricket is a Game of Skill</h2>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                Fantasy cricket on 11byChatGPT is a game of skill, not chance. Success depends on your knowledge of cricket, understanding of player statistics, awareness of pitch conditions, and strategic team selection. 
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                Research, analysis, and informed decision-making are key to performing well, distinguishing it from games of pure chance or gambling.
              </p>
            </section>

            <section className="space-y-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-6 w-6 text-amber-500" />
                <h2 className="text-xl font-bold">Signs of Problematic Play</h2>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                It's important to recognize potential warning signs of problematic gaming behavior:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>Spending more time or money than you can afford</li>
                <li>Joining contests to chase losses</li>
                <li>Neglecting personal or professional responsibilities</li>
                <li>Experiencing anxiety or stress about fantasy results</li>
                <li>Hiding your gaming activities from family or friends</li>
                <li>Borrowing money to participate in contests</li>
              </ul>
              <p className="text-gray-700 dark:text-gray-300">
                If you recognize any of these signs, we encourage you to use our responsible gaming tools or seek professional support.
              </p>
            </section>

            <section className="space-y-3">
              <div className="flex items-center gap-2">
                <Clock className="h-6 w-6 text-blue-600" />
                <h2 className="text-xl font-bold">Our Responsible Gaming Tools</h2>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT offers several tools to help you play responsibly:
              </p>
              
              <div className="space-y-4">
                <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-3 border border-gray-100 dark:border-gray-800">
                  <div className="flex items-center gap-2 mb-2">
                    <Timer className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">Deposit Limits</h3>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300 text-sm">
                    Set daily, weekly, or monthly limits on how much you can deposit into your 11byChatGPT wallet.
                  </p>
                </div>
                
                <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-3 border border-gray-100 dark:border-gray-800">
                  <div className="flex items-center gap-2 mb-2">
                    <Ban className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">Self-Exclusion</h3>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300 text-sm">
                    Take a break from playing by self-excluding for a defined period (1 week to 12 months).
                  </p>
                </div>
                
                <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-3 border border-gray-100 dark:border-gray-800">
                  <div className="flex items-center gap-2 mb-2">
                    <BadgeInfo className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">Reality Checks</h3>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300 text-sm">
                    Set up periodic reminders that display how long you've been playing and your current session activity.
                  </p>
                </div>
                
                <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-3 border border-gray-100 dark:border-gray-800">
                  <div className="flex items-center gap-2 mb-2">
                    <Megaphone className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">Contest Entry Limits</h3>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300 text-sm">
                    Set a maximum limit on the number of contests you can join per day.
                  </p>
                </div>
              </div>
              
              <p className="text-gray-700 dark:text-gray-300">
                To access these tools, visit your Profile section and look for "Responsible Gaming" settings.
              </p>
            </section>

            <section className="space-y-3">
              <div className="flex items-center gap-2">
                <Users className="h-6 w-6 text-violet-600" />
                <h2 className="text-xl font-bold">Age Verification</h2>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT is strictly for users 18 years and older. We implement rigorous age verification processes, including:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>Mandatory date of birth verification during registration</li>
                <li>ID verification for withdrawals</li>
                <li>Regular account reviews</li>
              </ul>
              <p className="text-gray-700 dark:text-gray-300">
                If we discover a user is underage, the account will be immediately suspended and any funds returned via the original payment method.
              </p>
            </section>

            <section className="space-y-3">
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold">Tips for Responsible Play</h2>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-900/30 space-y-2">
                <h3 className="font-semibold text-gray-900 dark:text-gray-100">Set a Budget</h3>
                <p className="text-gray-700 dark:text-gray-300 text-sm">
                  Decide in advance how much money you can afford to spend, and never exceed this amount.
                </p>
                
                <h3 className="font-semibold text-gray-900 dark:text-gray-100 mt-3">Play for Entertainment</h3>
                <p className="text-gray-700 dark:text-gray-300 text-sm">
                  Treat fantasy cricket as entertainment, not as a way to make money. Any winnings should be considered a bonus.
                </p>
                
                <h3 className="font-semibold text-gray-900 dark:text-gray-100 mt-3">Take Breaks</h3>
                <p className="text-gray-700 dark:text-gray-300 text-sm">
                  Regular breaks help maintain perspective. Don't let fantasy sports interfere with your daily life.
                </p>
                
                <h3 className="font-semibold text-gray-900 dark:text-gray-100 mt-3">Never Chase Losses</h3>
                <p className="text-gray-700 dark:text-gray-300 text-sm">
                  Accept losses as part of the game. Never try to recover losses by increasing your contest entries or entry fees.
                </p>
                
                <h3 className="font-semibold text-gray-900 dark:text-gray-100 mt-3">Don't Play Under Influence</h3>
                <p className="text-gray-700 dark:text-gray-300 text-sm">
                  Avoid playing when under the influence of alcohol or when emotionally upset.
                </p>
              </div>
            </section>

            <section className="space-y-3">
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold">Support Resources</h2>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                If you or someone you know is struggling with gaming habits, help is available:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li><strong>National Helpline for Responsible Gaming:</strong> 1800-11-0711</li>
                <li><strong>Responsible Gaming Council of India:</strong> www.rgci.org</li>
                <li><strong>11byChatGPT Support:</strong> help@11bychatgpt.com</li>
              </ul>
              <p className="text-gray-700 dark:text-gray-300">
                These resources provide confidential support, information, and guidance for those concerned about their gaming habits.
              </p>
            </section>

            <section className="bg-primary/10 p-4 rounded-lg border border-primary/20">
              <h2 className="text-lg font-bold mb-2">Our Commitment</h2>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT is committed to promoting a culture of responsible gaming. We regularly review and improve our responsible gaming measures, train our staff in responsible gaming practices, and collaborate with experts in the field.
              </p>
              <p className="text-gray-700 dark:text-gray-300 mt-2">
                We believe fantasy sports should be an enjoyable form of entertainment that enhances your love for cricket without causing any harm.
              </p>
            </section>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}