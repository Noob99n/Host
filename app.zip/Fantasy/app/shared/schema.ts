import { pgTable, text, serial, integer, boolean, timestamp, jsonb, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  full_name: text("full_name").notNull(),  // Using snake_case for column names
  email: text("email").notNull().unique(),
  phone: text("phone").notNull().unique(), // Indian phone number for OTP
  photo_url: text("photo_url"), // Using snake_case for column names
  balance: integer("balance").default(0),
  winnings: integer("winnings").default(0),
  bonus: integer("bonus").default(0),
  referral_code: text("referral_code").notNull().unique(), // Using snake_case for column names
  referred_by: text("referred_by"), // Using snake_case for column names
  created_at: timestamp("created_at").defaultNow(), // Using snake_case for column names
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  full_name: true,
  email: true,
  phone: true,
  referred_by: true,
});

// Matches
export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  team1: text("team1").notNull(),
  team2: text("team2").notNull(),
  format: text("format").notNull(),
  startTime: timestamp("start_time").notNull(),
  status: text("status").notNull(),
  team1Logo: text("team1_logo").notNull(),
  team2Logo: text("team2_logo").notNull(),
});

export const insertMatchSchema = createInsertSchema(matches).omit({
  id: true,
});

// Contests
export const contests = pgTable("contests", {
  id: serial("id").primaryKey(),
  matchId: integer("match_id").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  entryFee: integer("entry_fee").notNull(),
  totalSpots: integer("total_spots").notNull(),
  filledSpots: integer("filled_spots").default(0),
  prizePool: integer("prize_pool").notNull(),
  firstPrize: integer("first_prize").notNull(),
});

export const insertContestSchema = createInsertSchema(contests).omit({
  id: true,
  filledSpots: true,
});

// Players
export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  team: text("team").notNull(),
  role: text("role").notNull(),
  credits: real("credits").notNull(),
  selectionPercentage: integer("selection_percentage").default(0),
  recentPerformance: jsonb("recent_performance").notNull(),
  image: text("image").notNull(),
});

export const insertPlayerSchema = createInsertSchema(players).omit({
  id: true,
  selectionPercentage: true,
});

// User Teams
export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  matchId: integer("match_id").notNull(),
  name: text("name").notNull(),
  captain: integer("captain").notNull(),
  viceCaptain: integer("vice_captain").notNull(),
  players: jsonb("players").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTeamSchema = createInsertSchema(teams).omit({
  id: true,
  createdAt: true,
});

// Transactions
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(),
  amount: integer("amount").notNull(),
  status: text("status").notNull(),
  description: text("description").notNull(),
  // Note: metadata column was removed as it caused database issues
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Match = typeof matches.$inferSelect;
export type InsertMatch = z.infer<typeof insertMatchSchema>;

export type Contest = typeof contests.$inferSelect;
export type InsertContest = z.infer<typeof insertContestSchema>;

export type Player = typeof players.$inferSelect;
export type InsertPlayer = z.infer<typeof insertPlayerSchema>;

export type Team = typeof teams.$inferSelect;
export type InsertTeam = z.infer<typeof insertTeamSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

// Verifications
export const verifications = pgTable("verifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // 'pan', 'upi', 'bank'
  status: text("status").notNull(), // 'pending', 'approved', 'rejected'
  data: jsonb("data").notNull(), // Contains specific verification data (PAN number, UPI ID, bank details)
  documentUrl: text("document_url"), // URL to the uploaded document (if any)
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertVerificationSchema = createInsertSchema(verifications).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type Verification = typeof verifications.$inferSelect;
export type InsertVerification = z.infer<typeof insertVerificationSchema>;

// User preferences table for customization
export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  theme: text("theme").default("system").notNull(), // light, dark, system
  language: text("language").default("en").notNull(), // en, hi, etc.
  notificationsEnabled: boolean("notifications_enabled").default(true).notNull(),
  matchNotifications: boolean("match_notifications").default(true).notNull(),
  transactionNotifications: boolean("transaction_notifications").default(true).notNull(),
  promotionalNotifications: boolean("promotional_notifications").default(true).notNull(),
  contentPreferences: text("content_preferences").default("{}"),
  defaultView: text("default_view").default("matches"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserPreferencesSchema = createInsertSchema(userPreferences).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type UserPreference = typeof userPreferences.$inferSelect;
export type InsertUserPreference = z.infer<typeof insertUserPreferencesSchema>;


