import React, { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Header } from "@/components/layout/header";
import { useAuth } from "@/hooks/use-auth";
import { NavBar } from "@/components/layout/nav-bar";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { 
  User, 
  FileCheck, 
  FileText, 
  BarChart3, 
  Shield, 
  FileTerminal, 
  Info, 
  HelpCircle, 
  ShieldCheck,
  Scale,
  Phone,
  Megaphone,
  LogOut,
  Share,
  Lock
} from "lucide-react";

const moreOptions = [
  { path: "/profile", icon: User, label: "Profile" },
  { path: "/verify-account", icon: FileCheck, label: "Verify Account" },
  { path: "/download-tds", icon: FileText, label: "Download TDS Certificate" },
  { path: "/refer", icon: Share, label: "Refer & Earn" },
  { path: "/fantasy-points", icon: BarChart3, label: "Fantasy Point System" },
  { path: "/privacy-policy", icon: Shield, label: "Privacy Policy" },
  { path: "/terms-and-conditions", icon: FileTerminal, label: "Terms & Conditions" },
  { path: "/about-us", icon: Info, label: "About Us" },
  { path: "/how-to-play", icon: HelpCircle, label: "How To Play" },
  { path: "/responsible-play", icon: ShieldCheck, label: "Responsible Play" },
  { path: "/legality", icon: Scale, label: "Legality" },
  { path: "/contact-us", icon: Phone, label: "Contact Us" },
  { path: "/promoter-app", icon: Megaphone, label: "Promoter App" },
];

export default function MorePage() {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(true);
  const [optionsToShow, setOptionsToShow] = useState<typeof moreOptions>([]);
  
  // Pre-load options to avoid render delay
  useEffect(() => {
    // Show only first 6 options immediately
    setOptionsToShow(moreOptions.slice(0, 6));
    
    // Add a very short timeout to load rest of options
    // This improves perceived performance
    const timer = setTimeout(() => {
      setOptionsToShow(moreOptions);
      setIsLoading(false);
    }, 50);
    
    return () => clearTimeout(timer);
  }, []);

  // Handle direct logout with force redirects
  const handleLogout = async () => {
    try {
      // Immediate execute logout and force cache invalidation
      await logoutMutation.mutateAsync();
    } catch (error) {
      console.error("Logout failed:", error);
      // Force redirect to auth page even if the mutation fails
      window.location.href = "/auth";
    }
  };

  return (
    <div className="pb-20 min-h-screen bg-gray-50 dark:bg-dark-bg">
      <Header
        title="More"
        className="bg-primary text-white"
        showWallet={true}
      />

      <div className="p-4 max-w-[480px] mx-auto space-y-4">
        <div className="bg-white dark:bg-dark-card rounded-xl shadow-sm overflow-hidden">
          {isLoading && optionsToShow.length < moreOptions.length && (
            <div className="py-10 flex justify-center items-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          )}
          
          {optionsToShow.map((option, index) => (
            <div key={option.path}>
              <Link
                href={option.path}
                className="flex items-center justify-between p-4 hover:bg-gray-50 dark:hover:bg-dark-hover"
              >
                <div className="flex items-center gap-3">
                  <option.icon className="w-6 h-6 text-gray-500 dark:text-gray-400" />
                  <span className="font-medium">{option.label}</span>
                </div>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 text-gray-400"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5l7 7-7 7"
                  />
                </svg>
              </Link>
              {index < optionsToShow.length - 1 && (
                <div className="h-px bg-gray-100 dark:bg-dark-border mx-4" />
              )}
            </div>
          ))}
        </div>
        
        {/* Secret admin functionality removed */}
        
        {/* Logout Button */}
        <Button 
          variant="destructive" 
          onClick={handleLogout} 
          className="w-full py-6 bg-red-500 hover:bg-red-600 flex items-center justify-center gap-2"
          disabled={logoutMutation.isPending}
        >
          <LogOut className="h-5 w-5" />
          {logoutMutation.isPending ? "Logging out..." : "Logout"}
        </Button>
      </div>
      
      <NavBar />
    </div>
  );
}