import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Edit, Upload, Camera, User as UserIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Form schema
const formSchema = z.object({
  fullName: z.string().min(2, "Name must be at least 2 characters"),
  photoUrl: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

export function EditProfileModal() {
  const [open, setOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Initialize form with current user data
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      photoUrl: user?.photoUrl || "",
    },
  });
  
  // Reset form when dialog opens
  useEffect(() => {
    if (open) {
      form.reset({
        fullName: user?.fullName || "",
        photoUrl: user?.photoUrl || "",
      });
      setPreviewUrl(user?.photoUrl || "");
    }
  }, [open, user, form]);
  
  // Get user initials for avatar
  const getUserInitials = (name: string | undefined) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };
  
  // Handle image upload using Base64 encoding with resizing and compression
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Maximum file size check (5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 5MB",
        variant: "destructive",
      });
      return;
    }
    
    // Create a local preview URL for immediate feedback
    const localPreviewUrl = URL.createObjectURL(file);
    setPreviewUrl(localPreviewUrl);
    
    // Process the image
    processImage(file);
  };
  
  // New function to process and compress the image
  const processImage = async (file: File) => {
    return new Promise<void>((resolve, reject) => {
      try {
        // Create a FileReader to read the file
        const reader = new FileReader();
        
        reader.onload = (event) => {
          // Create an image element
          const img = new Image();
          
          img.onload = () => {
            try {
              // Create a canvas for the initial resize
              const canvas = document.createElement('canvas');
              
              // Calculate dimensions - smaller than before (300px max)
              const MAX_SIZE = 300;
              let width = img.width;
              let height = img.height;
              
              // Determine orientation (portrait or landscape)
              if (width > height) {
                if (width > MAX_SIZE) {
                  height = Math.round(height * (MAX_SIZE / width));
                  width = MAX_SIZE;
                }
              } else {
                if (height > MAX_SIZE) {
                  width = Math.round(width * (MAX_SIZE / height));
                  height = MAX_SIZE;
                }
              }
              
              // Set canvas size and draw the resized image
              canvas.width = width;
              canvas.height = height;
              const ctx = canvas.getContext('2d');
              
              if (!ctx) {
                toast({
                  title: "Error processing image",
                  description: "Could not create canvas context",
                  variant: "destructive",
                });
                reject(new Error("Could not create canvas context"));
                return;
              }
              
              // Draw the image with a white background first (for transparent PNGs)
              ctx.fillStyle = '#FFFFFF';
              ctx.fillRect(0, 0, width, height);
              
              // Draw the actual image
              ctx.drawImage(img, 0, 0, width, height);
              
              // Convert to JPEG with quality 0.6 (60%)
              let compressedBase64 = canvas.toDataURL('image/jpeg', 0.6);
              
              // Check if the result is still too large
              if (compressedBase64.length > 100000) {
                // Try with even lower quality
                compressedBase64 = canvas.toDataURL('image/jpeg', 0.4);
                
                // If still too large, resize again
                if (compressedBase64.length > 100000) {
                  // Create a second canvas with even smaller dimensions
                  const canvas2 = document.createElement('canvas');
                  const MAX_SIZE_2 = 200;
                  
                  let width2 = width;
                  let height2 = height;
                  
                  if (width2 > height2) {
                    if (width2 > MAX_SIZE_2) {
                      height2 = Math.round(height2 * (MAX_SIZE_2 / width2));
                      width2 = MAX_SIZE_2;
                    }
                  } else {
                    if (height2 > MAX_SIZE_2) {
                      width2 = Math.round(width2 * (MAX_SIZE_2 / height2));
                      height2 = MAX_SIZE_2;
                    }
                  }
                  
                  canvas2.width = width2;
                  canvas2.height = height2;
                  const ctx2 = canvas2.getContext('2d');
                  
                  if (ctx2) {
                    ctx2.fillStyle = '#FFFFFF';
                    ctx2.fillRect(0, 0, width2, height2);
                    ctx2.drawImage(canvas, 0, 0, width, height, 0, 0, width2, height2);
                    compressedBase64 = canvas2.toDataURL('image/jpeg', 0.4);
                  }
                }
              }
              
              // Save the final compressed Base64 string to form
              form.setValue("photoUrl", compressedBase64);
              
              // Log details for debugging
              console.log("Original file size:", file.size, "bytes");
              console.log("Compressed image size:", Math.round(compressedBase64.length * 0.75), "bytes");
              console.log("Image resized and compressed successfully");
              
              resolve();
            } catch (error) {
              console.error("Error processing image in canvas:", error);
              reject(error);
            }
          };
          
          img.onerror = (error) => {
            console.error("Error loading image:", error);
            reject(error);
          };
          
          // Set the source of the image to the FileReader result
          img.src = event.target?.result as string;
        };
        
        reader.onerror = (error) => {
          console.error("Error reading file:", error);
          reject(error);
        };
        
        // Read the file as a data URL
        reader.readAsDataURL(file);
      } catch (error) {
        console.error("Error in processImage:", error);
        reject(error);
      }
    });
  };
  
  async function onSubmit(values: FormData) {
    try {
      setIsSubmitting(true);
      
      // Do a final check for image size (should be already handled by processImage)
      if (values.photoUrl && values.photoUrl.length > 200000) {
        throw new Error("Profile image is too large. Please try again with a smaller image.");
      }
      
      // Log submission details
      console.log("Submitting profile update:", values.fullName);
      console.log("Final photo URL length:", values.photoUrl?.length || 0);
      
      // Submit the data to the API
      const response = await apiRequest("POST", "/api/update-profile", {
        fullName: values.fullName,
        photoUrl: values.photoUrl || null, // Ensure it's null if empty
      });
      
      // Handle API errors
      if (!response.ok) {
        let errorMsg = "Failed to update profile";
        try {
          const errorData = await response.json();
          errorMsg = errorData.message || errorMsg;
        } catch (e) {
          // If JSON parsing fails, use status text
          errorMsg = response.statusText || errorMsg;
        }
        throw new Error(errorMsg);
      }
      
      // Process successful response
      try {
        const updatedUser = await response.json();
        console.log("Profile updated successfully");
        
        // Check if we have a photo URL back
        if (updatedUser.photoUrl) {
          console.log("Photo URL is present in response");
        } else {
          console.log("No photo URL in response");
        }
      } catch (jsonError) {
        console.warn("Could not parse response JSON:", jsonError);
      }
      
      // Simply invalidate the query - don't try any fancy refetching
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      
      // Show success message
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully",
      });
      
      // Close the dialog
      setOpen(false);
      
    } catch (error: any) {
      console.error("Profile update error:", error);
      
      // Show a user-friendly error message
      toast({
        title: "Update failed",
        description: error.message || "Failed to update profile. Please try with a smaller image.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  }
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="ghost" 
          size="icon" 
          className="ml-2 h-7 w-7 rounded-full"
        >
          <Edit className="h-4 w-4" />
          <span className="sr-only">Edit profile</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Edit Profile</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 py-4">
            {/* Profile Photo */}
            <div className="flex flex-col items-center">
              <div className="relative">
                <Avatar className="h-20 w-20">
                  {previewUrl ? (
                    <AvatarImage src={previewUrl} alt="Profile" />
                  ) : (
                    <>
                      <AvatarImage 
                        src={user?.photoUrl || ""} 
                        alt={user?.fullName || user?.username || "User"} 
                      />
                      <AvatarFallback>
                        {getUserInitials(user?.fullName || user?.username)}
                      </AvatarFallback>
                    </>
                  )}
                </Avatar>
                <label 
                  htmlFor="photo-upload" 
                  className="absolute bottom-0 right-0 bg-primary text-white p-1 rounded-full cursor-pointer"
                >
                  <Camera className="h-4 w-4" />
                  <input 
                    type="file" 
                    id="photo-upload" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={handleImageUpload}
                  />
                </label>
              </div>
              <p className="text-xs text-neutral-500 mt-2">Tap to change profile photo</p>
            </div>
            
            {/* Full Name Field */}
            <FormField
              control={form.control}
              name="fullName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Non-editable fields - just for display */}
            <div className="space-y-4">
              <Separator />
              
              <div>
                <h3 className="text-sm font-medium mb-1">Account Information</h3>
                <p className="text-xs text-neutral-500 mb-4">These details cannot be changed</p>
              </div>
              
              <div className="space-y-3">
                {/* Username */}
                <div className="space-y-1">
                  <label className="text-sm font-medium">Username</label>
                  <div className="flex items-center border rounded-md px-3 py-2 bg-neutral-50 dark:bg-dark-card">
                    <UserIcon className="h-4 w-4 mr-2 text-neutral-400" />
                    <span className="text-sm text-neutral-600 dark:text-neutral-400">
                      {user?.username || "Not set"}
                    </span>
                  </div>
                </div>
                
                {/* Email */}
                <div className="space-y-1">
                  <label className="text-sm font-medium">Email</label>
                  <div className="flex items-center border rounded-md px-3 py-2 bg-neutral-50 dark:bg-dark-card">
                    <span className="text-sm text-neutral-600 dark:text-neutral-400">
                      {user?.email || "Not set"}
                    </span>
                  </div>
                </div>
                
                {/* Phone */}
                <div className="space-y-1">
                  <label className="text-sm font-medium">Phone</label>
                  <div className="flex items-center border rounded-md px-3 py-2 bg-neutral-50 dark:bg-dark-card">
                    <span className="text-sm text-neutral-600 dark:text-neutral-400">
                      {user?.phone || "Not set"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button 
                type="submit" 
                disabled={isSubmitting}
                className="w-full"
              >
                {isSubmitting ? "Saving..." : "Save Changes"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}