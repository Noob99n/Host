import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Clock, AlertCircle, Info } from "lucide-react";

export default function FantasyPointsPage() {
  const [sportType, setSportType] = useState("cricket");
  
  // Point system from Vision11 video
  const pointCategories = [
    {
      title: "Batting Points",
      items: [
        { action: "Run", points: "1", description: "Per run scored" },
        { action: "Boundary Bonus", points: "1", description: "Extra point for boundary" },
        { action: "Six Bonus", points: "2", description: "Extra points for six" },
        { action: "30 Run Bonus", points: "4", description: "Bonus for scoring 30+ runs" },
        { action: "Half Century", points: "8", description: "Bonus for scoring 50+ runs" },
        { action: "Century", points: "16", description: "Bonus for scoring 100+ runs" }, 
        { action: "Duck", points: "-2", description: "Penalty for 0 runs (except bowlers)" },
      ]
    },
    {
      title: "Bowling Points",
      items: [
        { action: "Wicket (Except Run-out)", points: "25", description: "Points per wicket" },
        { action: "Bonus (LBW/Bowled)", points: "8", description: "Extra points for LBW/Bowled wicket" },
        { action: "3 Wicket Haul Bonus", points: "4", description: "Bonus for 3 wickets" },
        { action: "4 Wicket Haul Bonus", points: "8", description: "Bonus for 4 wickets" },
        { action: "5 Wicket Haul Bonus", points: "16", description: "Bonus for 5 wickets" },
        { action: "Maiden Over", points: "12", description: "Bonus per maiden over" },
      ]
    },
    {
      title: "Fielding Points",
      items: [
        { action: "Catch", points: "8", description: "Points per catch" },
        { action: "3 Catch Bonus", points: "4", description: "Bonus for 3 catches" },
        { action: "Stumping/Run-out", points: "12", description: "Direct stumping or run-out" },
        { action: "Run-out (Thrower/Catcher)", points: "6", description: "Involved in run-out" },
      ]
    },
    {
      title: "Economy Rate (Min. 2 overs)",
      items: [
        { action: "Below 5 runs per over", points: "6", description: "For economy < 5" },
        { action: "Between 5-6 runs per over", points: "4", description: "For economy 5-6" },
        { action: "Between 6-7 runs per over", points: "2", description: "For economy 6-7" },
        { action: "Between 10-11 runs per over", points: "-2", description: "For economy 10-11" },
        { action: "Between 11-12 runs per over", points: "-4", description: "For economy 11-12" },
        { action: "Above 12 runs per over", points: "-6", description: "For economy > 12" },
      ]
    },
    {
      title: "Strike Rate (Min. 10 balls)",
      items: [
        { action: "Above 170", points: "6", description: "Strike rate > 170" },
        { action: "Between 150-170", points: "4", description: "Strike rate 150-170" },
        { action: "Between 130-150", points: "2", description: "Strike rate 130-150" },
        { action: "Between 60-70", points: "-2", description: "Strike rate 60-70" },
        { action: "Between (50-60)", points: "-4", description: "Strike rate 50-60" },
        { action: "Below 50", points: "-6", description: "Strike rate < 50" },
      ]
    },
    {
      title: "Other Points",
      items: [
        { action: "Captain", points: "2x", description: "Double points for captain" },
        { action: "Vice Captain", points: "1.5x", description: "1.5x points for vice captain" },
        { action: "Starting 11", points: "4", description: "Selected in playing 11" },
        { action: "Man of the Match", points: "12", description: "Awarded MoM" },
      ]
    }
  ];

  // Sports types for tabs
  const sportsTypes = [
    { id: "cricket", label: "Cricket" },
    { id: "football", label: "Football" },
    { id: "kabaddi", label: "Kabaddi" },
    { id: "basketball", label: "Basketball" }
  ];
  
  // Coming soon component for other sports
  const ComingSoonContent = ({ sportName }: { sportName: string }) => (
    <div className="mt-8 text-center p-6 bg-gray-100 dark:bg-gray-800 rounded-xl">
      <Clock className="mx-auto h-12 w-12 text-gray-400 mb-4" />
      <h3 className="text-xl font-bold mb-2">{sportName} Coming Soon</h3>
      <p className="text-gray-500 dark:text-gray-400">
        We're working hard to bring you fantasy points for {sportName.toLowerCase()}.
        Stay tuned for updates!
      </p>
    </div>
  );

  return (
    <div className="pb-20 min-h-screen bg-gray-50 dark:bg-dark-bg">
      <Header
        title="Fantasy Point System"
        showBack
        className="bg-primary text-white"
      />

      <div className="p-4 max-w-[480px] mx-auto">
        {/* Sport selection tabs */}
        <Tabs defaultValue="cricket" className="mb-4" value={sportType} onValueChange={setSportType}>
          <TabsList className="w-full">
            {sportsTypes.map(sport => (
              <TabsTrigger 
                key={sport.id} 
                value={sport.id} 
                className="flex-1"
              >
                {sport.label}
              </TabsTrigger>
            ))}
          </TabsList>
          
          {/* Cricket content */}
          <TabsContent value="cricket" className="mt-4">
            <div className="space-y-4">
              {pointCategories.map((category, index) => (
                <div key={index} className="bg-white dark:bg-dark-card rounded-xl shadow-sm overflow-hidden">
                  <div className="bg-primary p-3">
                    <h2 className="text-lg font-bold text-white">{category.title}</h2>
                  </div>
                  <div className="p-2">
                    <table className="w-full text-sm">
                      <thead className="text-gray-700 dark:text-gray-300">
                        <tr>
                          <th className="text-left py-2 px-3">Action</th>
                          <th className="text-center py-2 px-3">Points</th>
                          <th className="text-left py-2 px-3">Description</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                        {category.items.map((item, itemIndex) => (
                          <tr key={itemIndex} className="hover:bg-gray-50 dark:hover:bg-dark-hover">
                            <td className="py-2 px-3 font-medium">{item.action}</td>
                            <td className="py-2 px-3 text-center">{item.points}</td>
                            <td className="py-2 px-3 text-gray-500 dark:text-gray-400">
                              {item.description}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <p className="text-sm text-blue-700 dark:text-blue-300">
                Note: Point distribution may vary slightly for different contest formats. 
                Special tournaments might have unique scoring systems which will be 
                announced before the contest.
              </p>
            </div>
          </TabsContent>
          
          {/* Football content - Coming soon */}
          <TabsContent value="football">
            <ComingSoonContent sportName="Football" />
          </TabsContent>
          
          {/* Kabaddi content - Coming soon */}
          <TabsContent value="kabaddi">
            <ComingSoonContent sportName="Kabaddi" />
          </TabsContent>
          
          {/* Basketball content - Coming soon */}
          <TabsContent value="basketball">
            <ComingSoonContent sportName="Basketball" />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}