import { Header } from "@/components/layout/header";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  HelpCircle, Mail, Phone, MessageCircle, 
  ArrowRight, FileText, Shield, Book, ZapIcon,
  BellRing, Gift, Trophy, Users
} from "lucide-react";
import { Link } from "wouter";

export default function HelpCenterPage() {
  const goBack = () => {
    window.history.back();
  };
  
  return (
    <div className="pb-20 min-h-screen bg-gray-50 dark:bg-dark-bg">
      <Header
        title="Help Center"
        showBack
        backUrl="javascript:void(0)"
        onBackClick={goBack}
        showWallet={false}
        showNotification={false}
        className="bg-primary text-white"
      />

      <div className="p-4 max-w-[480px] mx-auto">
        <ScrollArea className="h-[calc(100vh-115px)] pr-3">
          <div className="mb-8 space-y-6">
            {/* Support Section */}
            <section className="space-y-3">
              <div className="flex items-center gap-2">
                <HelpCircle className="h-6 w-6 text-primary" />
                <h1 className="text-2xl font-bold">Customer Support</h1>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                We're here to help! Our customer support team is available to assist you with any questions or issues you may have.
              </p>
              
              <Card className="border-primary/20">
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-start gap-3">
                    <Mail className="h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-medium text-lg">Email Support</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        For general inquiries and support
                      </p>
                      <a 
                        href="mailto:support@11bychatgpt.com" 
                        className="text-primary font-medium flex items-center gap-1 mt-1"
                      >
                        support@11bychatgpt.com
                      </a>
                      <Badge className="mt-2 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
                        Active 24/7
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="h-px bg-gray-200 dark:bg-gray-700 my-2"></div>
                  
                  <div className="flex items-start gap-3">
                    <MessageCircle className="h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-medium text-lg">Live Chat</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Chat with our support team for immediate assistance
                      </p>
                      <Button variant="outline" className="mt-2" size="sm">
                        <MessageCircle className="h-4 w-4 mr-2" />
                        Start Chat
                      </Button>
                      <Badge className="ml-2 bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100">
                        Coming Soon
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </section>

            {/* Common Help Topics */}
            <section className="space-y-3">
              <h2 className="text-xl font-bold">Common Help Topics</h2>
              
              <div className="grid grid-cols-2 gap-3">
                <Link href="/how-to-play">
                  <Card className="hover:border-primary hover:shadow-md transition-all cursor-pointer h-full">
                    <CardContent className="p-3 flex flex-col items-center text-center justify-center h-full">
                      <ZapIcon className="h-8 w-8 text-primary mb-2" />
                      <h3 className="font-medium">How to Play</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        Learn fantasy cricket basics
                      </p>
                    </CardContent>
                  </Card>
                </Link>
                
                <Link href="/wallet">
                  <Card className="hover:border-primary hover:shadow-md transition-all cursor-pointer h-full">
                    <CardContent className="p-3 flex flex-col items-center text-center justify-center h-full">
                      <Trophy className="h-8 w-8 text-primary mb-2" />
                      <h3 className="font-medium">Withdrawals</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        How to withdraw winnings
                      </p>
                    </CardContent>
                  </Card>
                </Link>
                
                <Link href="/verify-account">
                  <Card className="hover:border-primary hover:shadow-md transition-all cursor-pointer h-full">
                    <CardContent className="p-3 flex flex-col items-center text-center justify-center h-full">
                      <Shield className="h-8 w-8 text-primary mb-2" />
                      <h3 className="font-medium">Account Verification</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        Verify your account
                      </p>
                    </CardContent>
                  </Card>
                </Link>
                
                <Link href="/refer">
                  <Card className="hover:border-primary hover:shadow-md transition-all cursor-pointer h-full">
                    <CardContent className="p-3 flex flex-col items-center text-center justify-center h-full">
                      <Gift className="h-8 w-8 text-primary mb-2" />
                      <h3 className="font-medium">Referral Program</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        Earn bonus through referrals
                      </p>
                    </CardContent>
                  </Card>
                </Link>
              </div>
            </section>

            {/* Legal and Information */}
            <section className="space-y-3">
              <h2 className="text-xl font-bold">Legal & Information</h2>
              
              <div className="space-y-2">
                <Link href="/terms-and-conditions">
                  <div className="flex items-center justify-between p-3 bg-white dark:bg-dark-card rounded-lg border border-gray-200 dark:border-dark-border hover:border-primary dark:hover:border-primary transition-all cursor-pointer">
                    <div className="flex items-center gap-3">
                      <FileText className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                      <span>Terms & Conditions</span>
                    </div>
                    <ArrowRight className="h-4 w-4 text-gray-400" />
                  </div>
                </Link>
                
                <Link href="/privacy-policy">
                  <div className="flex items-center justify-between p-3 bg-white dark:bg-dark-card rounded-lg border border-gray-200 dark:border-dark-border hover:border-primary dark:hover:border-primary transition-all cursor-pointer">
                    <div className="flex items-center gap-3">
                      <Shield className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                      <span>Privacy Policy</span>
                    </div>
                    <ArrowRight className="h-4 w-4 text-gray-400" />
                  </div>
                </Link>
                
                <Link href="/responsible-play">
                  <div className="flex items-center justify-between p-3 bg-white dark:bg-dark-card rounded-lg border border-gray-200 dark:border-dark-border hover:border-primary dark:hover:border-primary transition-all cursor-pointer">
                    <div className="flex items-center gap-3">
                      <Users className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                      <span>Responsible Play</span>
                    </div>
                    <ArrowRight className="h-4 w-4 text-gray-400" />
                  </div>
                </Link>
                
                <Link href="/legality">
                  <div className="flex items-center justify-between p-3 bg-white dark:bg-dark-card rounded-lg border border-gray-200 dark:border-dark-border hover:border-primary dark:hover:border-primary transition-all cursor-pointer">
                    <div className="flex items-center gap-3">
                      <Book className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                      <span>Legality</span>
                    </div>
                    <ArrowRight className="h-4 w-4 text-gray-400" />
                  </div>
                </Link>
              </div>
            </section>
            
            {/* FAQ Section */}
            <section className="space-y-3 border-t border-gray-200 dark:border-gray-700 pt-4">
              <h2 className="text-xl font-bold">Frequently Asked Questions</h2>
              
              <div className="space-y-4">
                <div className="bg-white dark:bg-dark-card rounded-lg border border-gray-200 dark:border-dark-border p-4">
                  <h3 className="font-medium text-lg">When can I withdraw my winnings?</h3>
                  <p className="text-gray-700 dark:text-gray-300 mt-2">
                    You can withdraw your winnings once you've completed account verification. All withdrawals are processed within 24-48 hours.
                  </p>
                </div>
                
                <div className="bg-white dark:bg-dark-card rounded-lg border border-gray-200 dark:border-dark-border p-4">
                  <h3 className="font-medium text-lg">How do I verify my account?</h3>
                  <p className="text-gray-700 dark:text-gray-300 mt-2">
                    Go to Profile → Account Details → Verify Account and follow the steps to submit your PAN and bank details.
                  </p>
                </div>
                
                <div className="bg-white dark:bg-dark-card rounded-lg border border-gray-200 dark:border-dark-border p-4">
                  <h3 className="font-medium text-lg">What is the minimum withdrawal amount?</h3>
                  <p className="text-gray-700 dark:text-gray-300 mt-2">
                    The minimum withdrawal amount is ₹200. There is no maximum limit for withdrawals.
                  </p>
                </div>
                
                <div className="bg-white dark:bg-dark-card rounded-lg border border-gray-200 dark:border-dark-border p-4">
                  <h3 className="font-medium text-lg">How are fantasy points calculated?</h3>
                  <p className="text-gray-700 dark:text-gray-300 mt-2">
                    Fantasy points are calculated based on real player performance in the actual match. Visit our Fantasy Point System page for detailed information on point calculations.
                  </p>
                  <Link href="/fantasy-points">
                    <Button variant="outline" className="mt-3" size="sm">
                      View Points System
                      <ArrowRight className="h-3.5 w-3.5 ml-1" />
                    </Button>
                  </Link>
                </div>
              </div>
            </section>
            
            {/* Still Need Help */}
            <section className="bg-primary/10 p-4 rounded-lg border border-primary/20 text-center">
              <h2 className="text-lg font-bold mb-2">Still Need Help?</h2>
              <p className="text-gray-700 dark:text-gray-300 mb-3">
                Our support team is here to assist you with any questions or concerns.
              </p>
              <a href="mailto:support@11bychatgpt.com">
                <Button>
                  <Mail className="h-4 w-4 mr-2" />
                  Contact Support
                </Button>
              </a>
            </section>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}