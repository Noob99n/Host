import { QueryClient, QueryFunction } from "@tanstack/react-query";

// Define RequestPriority type for TypeScript
type RequestPriority = 'high' | 'low' | 'auto';

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  // Create an AbortController to set a timeout
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 5000); // Increase timeout to 5 seconds
  
  try {
    const res = await fetch(url, {
      method,
      headers: {
        ...(data ? { "Content-Type": "application/json" } : {})
      },
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include",
      signal: controller.signal,
      // Use 'auto' priority for better performance balance
      priority: 'auto' as RequestPriority,
    });
    
    await throwIfResNotOk(res);
    return res;
  } finally {
    clearTimeout(timeoutId);
  }
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    // Create an AbortController to set a timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000); // Increase timeout to 5 seconds
    
    try {
      const res = await fetch(queryKey[0] as string, {
        credentials: "include",
        signal: controller.signal,
        // Use 'auto' priority for better performance balance
        priority: 'auto' as RequestPriority,
      });
  
      if (unauthorizedBehavior === "returnNull" && res.status === 401) {
        return null;
      }
  
      await throwIfResNotOk(res);
      return await res.json();
    } finally {
      clearTimeout(timeoutId);
    }
  };

// Create a local storage persister for verification status
// This will help keep verification status even after app refresh
const localStorageKey = 'verification-status-cache';

// Load initial verification status from local storage if available
let initialVerificationStatus = null;
try {
  const savedStatus = localStorage.getItem(localStorageKey);
  if (savedStatus) {
    initialVerificationStatus = JSON.parse(savedStatus);
    console.log('Loaded verification status from cache');
  }
} catch (error) {
  console.error('Failed to load verification status from cache:', error);
}

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false, 
      refetchOnWindowFocus: true, // Refresh when window regains focus
      staleTime: 30 * 1000, // Increase stale time to 30 seconds for better performance
      retry: false,
      networkMode: 'always', // Ensures queries don't wait for network reconnect
      refetchOnMount: true, // Refetch when component mounts
      gcTime: 60 * 60 * 1000, // Increase garbage collection time to 1 hour for better persistence
    },
    mutations: {
      retry: false,
      networkMode: 'always', // Ensures mutations don't wait for network reconnect
    },
  },
});

// Set initial data for verification status if available
if (initialVerificationStatus) {
  queryClient.setQueryData(['/api/verify/status'], initialVerificationStatus);
}

// Subscribe to query cache changes to save verification status
// This modification fixes the issues with WebSocket errors by being more selective about cache updates
let lastCacheUpdate = 0;
queryClient.getQueryCache().subscribe(event => {
  if (event.query.queryKey[0] === '/api/verify/status' && event.type === 'updated') {
    try {
      // Only update cache once every 5 seconds to reduce console spam and WebSocket errors
      const now = Date.now();
      if (now - lastCacheUpdate > 5000) {
        const data = queryClient.getQueryData(['/api/verify/status']);
        if (data) {
          localStorage.setItem(localStorageKey, JSON.stringify(data));
          // Suppress excessive logging
          // console.log('Saved verification status to cache');
          lastCacheUpdate = now;
        }
      }
    } catch (error) {
      console.error('Failed to save verification status to cache:', error);
    }
  }
});
