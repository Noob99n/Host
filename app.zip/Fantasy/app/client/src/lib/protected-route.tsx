import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Route, useLocation } from "wouter";
import { useEffect, useState } from "react";

export function ProtectedRoute({
  path,
  component: Component,
}: {
  path: string;
  component: () => React.JSX.Element;
}) {
  const { user, isLoading } = useAuth();
  const [, navigate] = useLocation();
  const [redirecting, setRedirecting] = useState(false);

  // Effect for redirecting when authentication changes with improved handling
  useEffect(() => {
    // Only redirect if authentication check is complete and no user is found
    if (!isLoading && !user && !redirecting) {
      console.log("ProtectedRoute: No authenticated user found, redirecting to /auth");
      setRedirecting(true);
      
      // Force hard redirect to auth page
      window.location.href = "/auth";
      return;
    }
    
    // If user is found after loading, reset redirecting state
    if (!isLoading && user) {
      setRedirecting(false);
    }
  }, [user, isLoading, navigate, redirecting]);

  // Loading state while checking authentication
  if (isLoading) {
    return (
      <Route path={path}>
        <div className="flex flex-col items-center justify-center min-h-screen">
          <Loader2 className="h-10 w-10 animate-spin text-primary mb-4" />
          <p className="text-sm text-muted-foreground">Loading...</p>
        </div>
      </Route>
    );
  }

  // If no user, show loader while redirecting
  if (!user || redirecting) {
    return (
      <Route path={path}>
        <div className="flex flex-col items-center justify-center min-h-screen">
          <Loader2 className="h-10 w-10 animate-spin text-primary mb-4" />
          <p className="text-sm text-muted-foreground">Redirecting to login...</p>
        </div>
      </Route>
    );
  }

  // User is authenticated, show the protected component
  return <Route path={path} component={Component} />;
}
