import { Header } from "@/components/layout/header";
import { FileDown } from "lucide-react";

export default function DownloadTDSPage() {
  return (
    <div className="pb-20 min-h-screen bg-gray-50 dark:bg-dark-bg">
      <Header
        title="Download TDS Certificate"
        showBack
        className="bg-primary text-white"
      />

      <div className="p-4 max-w-[480px] mx-auto">
        <div className="bg-white dark:bg-dark-card rounded-xl shadow-sm p-4">
          <h2 className="text-xl font-bold mb-4">TDS Certificates</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            Download your TDS certificates for income tax filing purposes.
          </p>

          <div className="space-y-4">
            <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg flex justify-between items-center">
              <div>
                <h3 className="font-medium">Financial Year 2024-25</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  April 2024 - March 2025
                </p>
              </div>
              <button className="p-2 bg-primary text-white rounded-full">
                <FileDown className="h-5 w-5" />
              </button>
            </div>

            <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg flex justify-between items-center">
              <div>
                <h3 className="font-medium">Financial Year 2023-24</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  April 2023 - March 2024
                </p>
              </div>
              <button className="p-2 bg-primary text-white rounded-full">
                <FileDown className="h-5 w-5" />
              </button>
            </div>
          </div>

          <div className="mt-6 p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
            <p className="text-sm text-amber-700 dark:text-amber-300">
              Note: TDS certificates are generated quarterly as per government regulations.
              If you haven't earned enough winnings for TDS deduction, no certificate will be available.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}