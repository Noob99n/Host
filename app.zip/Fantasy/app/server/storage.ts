import { 
  users, type User, type InsertUser,
  matches, type Match, type InsertMatch,
  contests, type Contest, type InsertContest,
  players, type Player, type InsertPlayer,
  teams, type Team, type InsertTeam,
  transactions, type Transaction, type InsertTransaction,
  verifications, type Verification, type InsertVerification,
  userPreferences, type UserPreference, type InsertUserPreference
} from "@shared/schema";
import session from "express-session";
import { Store } from "express-session";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";
import { generateReferralCode } from "./utils";
import { db, pool } from "./db";
import { eq, and, desc, sql } from "drizzle-orm";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

// Storage interface with CRUD methods
export interface IStorage {
  // Session store
  sessionStore: Store;
  
  // User related methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  getUserByReferralCode(code: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(userId: number, amount: number): Promise<User>;
  updateUserPassword(userId: number, newPassword: string): Promise<User>;
  updateUserProfile(userId: number, profile: { fullName?: string; photoUrl?: string }): Promise<User>;
  
  // Match related methods
  getMatches(): Promise<Match[]>;
  getMatch(id: number): Promise<Match | undefined>;
  createMatch(match: InsertMatch): Promise<Match>;
  
  // Contest related methods
  getContests(matchId: number): Promise<Contest[]>;
  getContest(id: number): Promise<Contest | undefined>;
  createContest(contest: InsertContest): Promise<Contest>;
  
  // Player related methods
  getPlayers(matchId: number): Promise<Player[]>;
  getPlayersByTeamAndRole(matchId: number, team: string, role: string): Promise<Player[]>;
  getPlayer(id: number): Promise<Player | undefined>;
  createPlayer(player: InsertPlayer): Promise<Player>;
  
  // Team related methods
  getTeams(userId: number): Promise<Team[]>;
  getTeamsByMatch(userId: number, matchId: number): Promise<Team[]>;
  getTeam(id: number): Promise<Team | undefined>;
  createTeam(team: InsertTeam): Promise<Team>;
  
  // Transaction related methods
  getTransactions(userId: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  
  // Verification related methods
  getVerifications(userId: number, type?: string): Promise<Verification[]>;
  getVerificationsByType(type: string, status?: string): Promise<Verification[]>;
  getVerification(id: number): Promise<Verification | undefined>;
  createVerification(verification: InsertVerification): Promise<Verification>;
  updateVerificationStatus(id: number, status: string): Promise<Verification>;
  
  // User preferences methods
  getUserPreferences(userId: number): Promise<UserPreference | undefined>;
  createUserPreferences(preferences: InsertUserPreference): Promise<UserPreference>;
  updateUserPreferences(userId: number, preferences: Partial<InsertUserPreference>): Promise<UserPreference>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  sessionStore: Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
    
    // Initialize database with seed data if needed
    this.initializeDb();
  }
  
  private async initializeDb() {
    // Check if we have any matches, if not seed the database
    const matchesData = await db.select().from(matches);
    if (matchesData.length === 0) {
      this.seedData();
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    // Query the database for the user
    const [dbUser] = await db.select().from(users).where(eq(users.id, id));
    
    if (!dbUser) return undefined;
    
    // Access the raw database fields (snake_case column names)
    const rawUser = dbUser as any;
    
    // Create a fully mapped user object
    const mappedUser: User = {
      ...dbUser,
      // No need to map as we're now using the raw database field names directly
      // The schema and database column names are now the same
      // This approach eliminates field mapping issues
    };
    
    return mappedUser;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [dbUser] = await db.select().from(users).where(eq(users.username, username));
    if (!dbUser) return undefined;
    
    // Use the same mapping as getUser for consistency
    const rawUser = dbUser as any;
    
    // Create a fully mapped user object
    const mappedUser: User = {
      ...dbUser,
      // Explicitly map all snake_case database columns to camelCase properties
      fullName: rawUser.full_name,
      photoUrl: rawUser.photo_url || null, 
      referralCode: rawUser.referral_code,
      referredBy: rawUser.referred_by,
      createdAt: rawUser.created_at
    };
    
    return mappedUser;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [dbUser] = await db.select().from(users).where(eq(users.email, email));
    if (!dbUser) return undefined;
    
    // Use the same mapping as getUser for consistency
    const rawUser = dbUser as any;
    
    // Create a fully mapped user object
    const mappedUser: User = {
      ...dbUser,
      // Explicitly map all snake_case database columns to camelCase properties
      fullName: rawUser.full_name,
      photoUrl: rawUser.photo_url || null, 
      referralCode: rawUser.referral_code,
      referredBy: rawUser.referred_by,
      createdAt: rawUser.created_at
    };
    
    return mappedUser;
  }
  
  async getUserByReferralCode(code: string): Promise<User | undefined> {
    const [dbUser] = await db.select().from(users).where(eq(users.referral_code, code));
    if (!dbUser) return undefined;
    
    // Use the same mapping as getUser for consistency
    const rawUser = dbUser as any;
    
    // Create a fully mapped user object
    const mappedUser: User = {
      ...dbUser,
      // Explicitly map all snake_case database columns to camelCase properties
      fullName: rawUser.full_name,
      photoUrl: rawUser.photo_url || null, 
      referralCode: rawUser.referral_code,
      referredBy: rawUser.referred_by,
      createdAt: rawUser.created_at
    };
    
    return mappedUser;
  }
  
  async getUserByPhone(phone: string): Promise<User | undefined> {
    const [dbUser] = await db.select().from(users).where(eq(users.phone, phone));
    if (!dbUser) return undefined;
    
    // Use the same mapping as getUser for consistency
    const rawUser = dbUser as any;
    
    // Create a fully mapped user object
    const mappedUser: User = {
      ...dbUser,
      // Explicitly map all snake_case database columns to camelCase properties
      fullName: rawUser.full_name,
      photoUrl: rawUser.photo_url || null, 
      referralCode: rawUser.referral_code,
      referredBy: rawUser.referred_by,
      createdAt: rawUser.created_at
    };
    
    return mappedUser;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Now we're explicitly setting the referral_code from either provided value or generated one
    // Referral code should be already generated in the auth.ts file and passed here
    
    // Create the user with proper database column names (snake_case)
    const [dbUser] = await db.insert(users)
      .values({
        ...insertUser,
        balance: 0,
        winnings: 0,
        bonus: 0
      })
      .returning();
    
    // Map the raw DB user to the expected User interface
    const user: User = {
      ...dbUser,
      fullName: dbUser.full_name,
      photoUrl: dbUser.photo_url,
      referralCode: dbUser.referral_code, 
      referredBy: dbUser.referred_by,
      createdAt: dbUser.created_at
    };
    
    // If there's a referral code, process the bonus
    if (insertUser.referredBy) {
      const referrer = await this.getUserByReferralCode(insertUser.referredBy);
      if (referrer) {
        // Add bonus to referrer - changed from 50 to 10 as requested
        await this.updateUserBalance(referrer.id, 10);
        
        // Create a transaction for the referrer
        await this.createTransaction({
          userId: referrer.id,
          type: 'credit',
          amount: 10,
          status: 'completed',
          description: 'Referral bonus'
        });
        
        // Add bonus to new user
        await db.update(users)
          .set({ bonus: 10 })
          .where(eq(users.id, user.id));
          
        user.bonus = 10;
      }
    }
    
    return user;
  }
  
  async updateUserBalance(userId: number, amount: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    const newBalance = (user.balance || 0) + amount;
    
    const [updatedUser] = await db.update(users)
      .set({ balance: newBalance })
      .where(eq(users.id, userId))
      .returning();
      
    return updatedUser;
  }
  
  async updateUserWinnings(userId: number, amount: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    const newWinnings = (user.winnings || 0) + amount;
    
    if (newWinnings < 0) {
      throw new Error('Insufficient winnings balance');
    }
    
    const [updatedUser] = await db.update(users)
      .set({ winnings: newWinnings })
      .where(eq(users.id, userId))
      .returning();
      
    return updatedUser;
  }
  
  async processWithdrawal(userId: number, amount: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    // Check if user has enough winnings
    if ((user.winnings || 0) < amount) {
      throw new Error('Insufficient winnings balance');
    }
    
    // Deduct from winnings, not from main balance
    const newWinnings = (user.winnings || 0) - amount;
    
    const [updatedUser] = await db.update(users)
      .set({ winnings: newWinnings })
      .where(eq(users.id, userId))
      .returning();
      
    return updatedUser;
  }
  
  async updateUserPassword(userId: number, newPassword: string): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    // In a real app, hash the password here
    // For now, we're assuming it's already hashed in auth.ts
    
    const [updatedUser] = await db.update(users)
      .set({ password: newPassword })
      .where(eq(users.id, userId))
      .returning();
      
    return updatedUser;
  }
  
  async updateUserProfile(userId: number, profile: { fullName?: string; photoUrl?: string }): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    // Create update data object with correctly mapped database column names
    const updates: Record<string, any> = {};
    
    // Add fullName if provided
    if (profile.fullName !== undefined) {
      updates.full_name = profile.fullName;
    }
    
    // Map photoUrl to photo_url database column
    if (profile.photoUrl !== undefined) {
      // If photoUrl is null or empty string, explicitly set to null
      updates.photo_url = profile.photoUrl || null;
      
      console.log(`Setting photo_url for user ${userId}`);
      if (profile.photoUrl) {
        console.log(`Photo URL length: ${profile.photoUrl.length} characters`);
      } else {
        console.log('Photo URL is null or empty');
      }
    }
    
    console.log('Update data:', Object.keys(updates));
    
    try {
      // Use SQL query to manually construct the update statement to avoid any syntax issues
      const updateQuery = sql`
        UPDATE "users"
        SET ${
          Object.entries(updates).map(([column, value]) => {
            return sql`${sql.identifier(column)} = ${value}`;
          }).reduce((acc, curr, idx) => {
            if (idx === 0) return curr;
            return sql`${acc}, ${curr}`;
          }, sql``)
        }
        WHERE "id" = ${userId}
        RETURNING *
      `;
      
      // Execute the query
      const result = await db.execute(updateQuery);
      
      if (!result.rows || result.rows.length === 0) {
        throw new Error('Failed to update user profile');
      }
      
      // Get the first row of the result
      const dbUpdatedUser = result.rows[0];
      
      // Create a mapped user object with correct property names
      const mappedUser: User = {
        id: dbUpdatedUser.id,
        username: dbUpdatedUser.username,
        password: dbUpdatedUser.password,
        email: dbUpdatedUser.email || null,
        phone: dbUpdatedUser.phone || null,
        fullName: dbUpdatedUser.full_name || null,
        photoUrl: dbUpdatedUser.photo_url || null,
        balance: dbUpdatedUser.balance || 0,
        winnings: dbUpdatedUser.winnings || 0,
        bonus: dbUpdatedUser.bonus || 0,
        referralCode: dbUpdatedUser.referral_code || null,
        referredBy: dbUpdatedUser.referred_by || null,
        createdAt: dbUpdatedUser.created_at || new Date()
      };
      
      console.log('Updated user profile successfully');
      console.log('Photo URL in returned user:', mappedUser.photoUrl ? 'Present' : 'Not present');
      
      return mappedUser;
    } catch (error) {
      console.error('Error updating user profile:', error);
      throw error;
    }
  }

  // Match methods
  async getMatches(): Promise<Match[]> {
    return await db.select().from(matches);
  }
  
  async getMatch(id: number): Promise<Match | undefined> {
    const [match] = await db.select().from(matches).where(eq(matches.id, id));
    return match;
  }
  
  async createMatch(match: InsertMatch): Promise<Match> {
    const [newMatch] = await db.insert(matches).values(match).returning();
    return newMatch;
  }
  
  // Contest methods
  async getContests(matchId: number): Promise<Contest[]> {
    return await db.select().from(contests).where(eq(contests.matchId, matchId));
  }
  
  async getContest(id: number): Promise<Contest | undefined> {
    const [contest] = await db.select().from(contests).where(eq(contests.id, id));
    return contest;
  }
  
  async createContest(contest: InsertContest): Promise<Contest> {
    const [newContest] = await db.insert(contests)
      .values({ ...contest, filledSpots: 0 })
      .returning();
    return newContest;
  }
  
  // Player methods
  async getPlayers(matchId: number): Promise<Player[]> {
    // In a real app, players would be linked to matches
    // For now, return all players
    return await db.select().from(players);
  }
  
  async getPlayersByTeamAndRole(matchId: number, team: string, role: string): Promise<Player[]> {
    return await db.select().from(players)
      .where(and(
        eq(players.team, team),
        eq(players.role, role)
      ));
  }
  
  async getPlayer(id: number): Promise<Player | undefined> {
    const [player] = await db.select().from(players).where(eq(players.id, id));
    return player;
  }
  
  async createPlayer(player: InsertPlayer): Promise<Player> {
    const [newPlayer] = await db.insert(players)
      .values({ ...player, selectionPercentage: 0 })
      .returning();
    return newPlayer;
  }
  
  // Team methods
  async getTeams(userId: number): Promise<Team[]> {
    return await db.select().from(teams).where(eq(teams.userId, userId));
  }
  
  async getTeamsByMatch(userId: number, matchId: number): Promise<Team[]> {
    return await db.select().from(teams).where(
      and(
        eq(teams.userId, userId),
        eq(teams.matchId, matchId)
      )
    );
  }
  
  async getTeam(id: number): Promise<Team | undefined> {
    const [team] = await db.select().from(teams).where(eq(teams.id, id));
    return team;
  }
  
  async createTeam(team: InsertTeam): Promise<Team> {
    const [newTeam] = await db.insert(teams)
      .values(team)
      .returning();
    return newTeam;
  }
  
  // Transaction methods
  async getTransactions(userId: number): Promise<Transaction[]> {
    return await db.select().from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt));
  }
  
  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    // Create a sanitized transaction object by filtering out any fields not in the schema
    const sanitizedTransaction: InsertTransaction = {
      userId: transaction.userId,
      type: transaction.type,
      amount: transaction.amount, 
      status: transaction.status,
      description: transaction.description,
      // Do not include metadata if it's not in the database schema
    };
    
    const [newTransaction] = await db.insert(transactions)
      .values({ ...sanitizedTransaction, createdAt: new Date() })
      .returning();
    return newTransaction;
  }
  
  // Verification methods
  async getVerifications(userId: number, type?: string): Promise<Verification[]> {
    if (type) {
      // If type is provided, use and condition
      return await db.select()
        .from(verifications)
        .where(and(
          eq(verifications.userId, userId),
          eq(verifications.type, type)
        ))
        .orderBy(desc(verifications.createdAt));
    } else {
      // If no type, just filter by userId
      return await db.select()
        .from(verifications)
        .where(eq(verifications.userId, userId))
        .orderBy(desc(verifications.createdAt));
    }
  }
  
  async getVerificationsByType(type: string, status?: string): Promise<Verification[]> {
    if (status) {
      return await db.select().from(verifications)
        .where(and(
          eq(verifications.type, type),
          eq(verifications.status, status)
        ))
        .orderBy(desc(verifications.createdAt));
    } else {
      return await db.select().from(verifications)
        .where(eq(verifications.type, type))
        .orderBy(desc(verifications.createdAt));
    }
  }
  
  async getVerification(id: number): Promise<Verification | undefined> {
    const [verification] = await db.select().from(verifications).where(eq(verifications.id, id));
    return verification;
  }
  
  async createVerification(verification: InsertVerification): Promise<Verification> {
    const [newVerification] = await db.insert(verifications)
      .values({ 
        ...verification,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return newVerification;
  }
  
  async updateVerificationStatus(id: number, status: string): Promise<Verification> {
    const [updatedVerification] = await db.update(verifications)
      .set({ 
        status,
        updatedAt: new Date()
      })
      .where(eq(verifications.id, id))
      .returning();
    
    return updatedVerification;
  }
  
  // User Preferences methods
  async getUserPreferences(userId: number): Promise<UserPreference | undefined> {
    const [userPreference] = await db.select()
      .from(userPreferences)
      .where(eq(userPreferences.userId, userId));
    
    return userPreference;
  }
  
  async createUserPreferences(preferences: InsertUserPreference): Promise<UserPreference> {
    const [newPreferences] = await db.insert(userPreferences)
      .values({
        ...preferences,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
      
    return newPreferences;
  }
  
  async updateUserPreferences(userId: number, preferences: Partial<InsertUserPreference>): Promise<UserPreference> {
    // Get existing preferences first
    const existing = await this.getUserPreferences(userId);
    
    if (!existing) {
      // If no preferences exist, create them
      return this.createUserPreferences({
        userId,
        ...preferences
      } as InsertUserPreference);
    }
    
    // Update existing preferences
    const [updatedPreferences] = await db.update(userPreferences)
      .set({
        ...preferences,
        updatedAt: new Date()
      })
      .where(eq(userPreferences.userId, userId))
      .returning();
      
    return updatedPreferences;
  }
  
  // Seed initial data for demo purposes
  private async seedData() {
    // Seed matches
    const match1 = await this.createMatch({
      team1: 'IND',
      team2: 'AUS',
      format: 'T20',
      startTime: new Date(Date.now() + 10 * 60 * 60 * 1000), // 10 hours from now
      status: 'upcoming',
      team1Logo: 'https://img.freepik.com/premium-vector/india-cricket-team-jersey-tshirt-sports_1302-32126.jpg',
      team2Logo: 'https://img.freepik.com/premium-vector/australia-cricket-team-jersey_1302-32118.jpg'
    });
    
    const match2 = await this.createMatch({
      team1: 'ENG',
      team2: 'SA',
      format: 'T20',
      startTime: new Date(Date.now() + 20 * 60 * 60 * 1000), // 20 hours from now
      status: 'upcoming',
      team1Logo: 'https://img.freepik.com/premium-vector/england-cricket-team-jersey_1302-32121.jpg',
      team2Logo: 'https://img.freepik.com/premium-vector/south-africa-cricket-team-jersey_1302-32113.jpg'
    });
    
    // Seed contests
    await this.createContest({
      matchId: match1.id,
      name: 'MEGA Contest',
      type: 'popular',
      entryFee: 599,
      totalSpots: 10000,
      prizePool: 1000000, // 10 Lakhs
      firstPrize: 100000 // 1 Lakh
    });
    
    await this.createContest({
      matchId: match1.id,
      name: "Beginner's Contest",
      type: 'new',
      entryFee: 49,
      totalSpots: 5000,
      prizePool: 50000,
      firstPrize: 10000
    });
    
    await this.createContest({
      matchId: match1.id,
      name: 'Head to Head',
      type: 'h2h',
      entryFee: 275,
      totalSpots: 2,
      prizePool: 500,
      firstPrize: 500
    });
    
    // Seed players
    await this.createPlayer({
      name: 'R. Pant',
      team: 'IND',
      role: 'WK',
      credits: 9.5,
      recentPerformance: [45, 67, 21],
      image: 'https://img.freepik.com/free-vector/cricket-player-action-cartoon-character_1308-108820.jpg'
    });
    
    await this.createPlayer({
      name: 'A. Carey',
      team: 'AUS',
      role: 'WK',
      credits: 8.5,
      recentPerformance: [32, 48, 17],
      image: 'https://img.freepik.com/free-vector/cricket-player-action-cartoon-character_1308-108846.jpg'
    });
    
    await this.createPlayer({
      name: 'K.L. Rahul',
      team: 'IND',
      role: 'WK-BAT',
      credits: 10.0,
      recentPerformance: [78, 52, 103],
      image: 'https://img.freepik.com/free-vector/cricket-player-action-cartoon-character_1308-108837.jpg'
    });
    
    await this.createPlayer({
      name: 'J. Inglis',
      team: 'AUS',
      role: 'WK',
      credits: 8.0,
      recentPerformance: [24, 35, 41],
      image: 'https://img.freepik.com/free-vector/cricket-player-action-cartoon-character_1308-108851.jpg'
    });
    
    // Add more players for other roles
    await this.createPlayer({
      name: 'V. Kohli',
      team: 'IND',
      role: 'BAT',
      credits: 10.5,
      recentPerformance: [82, 35, 56],
      image: 'https://img.freepik.com/free-vector/cricket-player-action-cartoon-character_1308-108837.jpg'
    });
    
    await this.createPlayer({
      name: 'S. Smith',
      team: 'AUS',
      role: 'BAT',
      credits: 10.0,
      recentPerformance: [45, 76, 32],
      image: 'https://img.freepik.com/free-vector/cricket-player-action-cartoon-character_1308-108846.jpg'
    });
    
    await this.createPlayer({
      name: 'H. Pandya',
      team: 'IND',
      role: 'AR',
      credits: 9.0,
      recentPerformance: [32, 2, 41],
      image: 'https://img.freepik.com/free-vector/cricket-player-action-cartoon-character_1308-108820.jpg'
    });
    
    await this.createPlayer({
      name: 'M. Starc',
      team: 'AUS',
      role: 'BOWL',
      credits: 9.5,
      recentPerformance: [3, 1, 4],
      image: 'https://img.freepik.com/free-vector/cricket-player-action-cartoon-character_1308-108851.jpg'
    });
  }
}

export const storage = new DatabaseStorage();