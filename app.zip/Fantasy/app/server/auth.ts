import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser, insertUserSchema } from "@shared/schema";
import { generateReferralCode } from "./utils";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

// Export these functions so they can be used for password reset
export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

export async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "cricket-fantasy-app-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
      httpOnly: true,
      secure: false, // Set to true in production with HTTPS
      sameSite: 'lax'
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        // Check if login is by username or email
        let user = await storage.getUserByUsername(username);
        if (!user) {
          user = await storage.getUserByEmail(username);
        }
        
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false);
        } else {
          return done(null, user);
        }
      } catch (error) {
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      // Extend the validation schema
      const extendedSchema = insertUserSchema.extend({
        password: insertUserSchema.shape.password.min(6, "Password must be at least 6 characters"),
        email: insertUserSchema.shape.email.email("Invalid email format")
      });
      
      const userData = extendedSchema.parse(req.body);
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(userData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      // If referral code provided, validate it
      if (userData.referred_by) {
        const referrer = await storage.getUserByReferralCode(userData.referred_by);
        if (!referrer) {
          return res.status(400).json({ message: "Invalid referral code" });
        }
      }
      
      // Hash password before storing
      const hashedPassword = await hashPassword(userData.password);
      
      // Generate referral code from username
      const referralCode = generateReferralCode(userData.full_name || userData.username);
      
      // Create user with the correct snake_case field names
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
        referral_code: referralCode
      });
      
      // Login the user
      req.login(user, (err) => {
        if (err) return next(err);
        
        // Return user without password
        const { password, ...userWithoutPassword } = user;
        res.status(201).json(userWithoutPassword);
      });
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Registration failed" });
      }
    }
  });

  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err: Error | null, user: SelectUser | false, info: { message: string }) => {
      if (err) return next(err);
      if (!user) return res.status(400).json({ message: info?.message || "Invalid username or password" });
      
      req.login(user, (err: Error | null) => {
        if (err) return next(err);
        
        // Return user without password
        const { password, ...userWithoutPassword } = user;
        res.status(200).json(userWithoutPassword);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      // Always fetch fresh user data from database
      const freshUser = await storage.getUser(req.user.id);
      if (!freshUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Update the session user object
      req.user = freshUser;
      
      // Remove sensitive data and manually transform snake_case to camelCase for client
      const { password, ...userFields } = freshUser;
      
      // Convert raw database fields to client-friendly format
      const clientUser = {
        ...userFields,
        // Map snake_case to camelCase for client compatibility
        fullName: freshUser.full_name,
        photoUrl: freshUser.photo_url, 
        referralCode: freshUser.referral_code,
        referredBy: freshUser.referred_by,
        createdAt: freshUser.created_at
      };
      
      res.json(clientUser);
    } catch (error) {
      console.error("Error fetching fresh user data:", error);
      res.status(500).json({ message: "Server error fetching user data" });
    }
  });
}
