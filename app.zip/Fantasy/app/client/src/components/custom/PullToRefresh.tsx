import React, { useRef, useState, useEffect } from 'react';

interface PullToRefreshProps {
  onRefresh: () => Promise<any>;
  children: React.ReactNode;
  pullDownThreshold?: number;
  className?: string;
}

const PullToRefresh: React.FC<PullToRefreshProps> = ({
  onRefresh,
  children,
  pullDownThreshold = 100,
  className = "",
}) => {
  const [isPulling, setIsPulling] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const touchStartY = useRef<number | null>(null);

  const handleTouchStart = (e: TouchEvent) => {
    if (containerRef.current && containerRef.current.scrollTop <= 0) {
      touchStartY.current = e.touches[0].clientY;
    } else {
      touchStartY.current = null;
    }
  };

  const handleTouchMove = (e: TouchEvent) => {
    if (touchStartY.current !== null && !isRefreshing) {
      const touchY = e.touches[0].clientY;
      const distance = touchY - touchStartY.current;
      
      if (distance > 0) {
        e.preventDefault();
        setIsPulling(true);
        // Use a damping factor to make the pull resistance increase as you pull further
        const dampedDistance = Math.min(Math.pow(distance, 0.8), pullDownThreshold * 1.5);
        setPullDistance(dampedDistance);
      }
    }
  };

  const handleTouchEnd = async () => {
    if (isPulling) {
      if (pullDistance > pullDownThreshold && !isRefreshing) {
        try {
          setIsRefreshing(true);
          await onRefresh();
        } finally {
          setIsRefreshing(false);
        }
      }
      
      setIsPulling(false);
      setPullDistance(0);
    }
    touchStartY.current = null;
  };

  useEffect(() => {
    const container = containerRef.current;
    if (container) {
      container.addEventListener('touchstart', handleTouchStart, { passive: false });
      container.addEventListener('touchmove', handleTouchMove, { passive: false });
      container.addEventListener('touchend', handleTouchEnd);
      
      return () => {
        container.removeEventListener('touchstart', handleTouchStart);
        container.removeEventListener('touchmove', handleTouchMove);
        container.removeEventListener('touchend', handleTouchEnd);
      };
    }
  }, [isPulling, isRefreshing, pullDistance]);

  return (
    <div 
      ref={containerRef} 
      className={`overflow-auto ${className}`}
      style={{ position: 'relative', height: '100%' }}
    >
      {isPulling || isRefreshing ? (
        <div 
          className="flex items-center justify-center py-3 text-primary transition-all"
          style={{ 
            height: `${Math.max(pullDistance, isRefreshing ? 60 : 0)}px`, 
            marginTop: '-1px',
            transition: isPulling ? 'none' : 'height 0.2s ease'
          }}
        >
          <div className={`flex items-center space-x-2 ${isRefreshing ? 'animate-pulse' : ''}`}>
            <svg 
              className={`h-5 w-5 ${isRefreshing ? 'animate-spin' : ''}`} 
              style={{ 
                transform: !isRefreshing ? `rotate(${Math.min(pullDistance / pullDownThreshold * 360, 360)}deg)` : '',
                transition: isPulling ? 'none' : 'transform 0.2s ease' 
              }}
              xmlns="http://www.w3.org/2000/svg" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            <span className="text-sm">
              {isRefreshing ? 'Refreshing...' : pullDistance > pullDownThreshold ? 'Release to refresh' : 'Pull down to refresh'}
            </span>
          </div>
        </div>
      ) : null}
      
      <div style={{ marginTop: isPulling ? `${pullDistance}px` : '0', transition: isPulling ? 'none' : 'margin-top 0.2s ease' }}>
        {children}
      </div>
    </div>
  );
};

export default PullToRefresh;