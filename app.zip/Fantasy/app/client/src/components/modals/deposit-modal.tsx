import { useState, useRef, ChangeEvent } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { CreditCard, BadgeIndianRupee, Copy, Download, AlertCircle, Upload, CheckCircle2, Image } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

type DepositModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

export function DepositModal({ isOpen, onClose }: DepositModalProps) {
  const [amount, setAmount] = useState("500");
  const [paymentMethod, setPaymentMethod] = useState("upi");
  const [activeTab, setActiveTab] = useState("upi");
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [transactionId, setTransactionId] = useState("");
  const [screenshotFile, setScreenshotFile] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const upiIdRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  // UPI ID to copy
  const UPI_ID = "gyrange.satyam@fam";

  const depositMutation = useMutation({
    mutationFn: async ({ amount, paymentMethod }: { amount: number; paymentMethod: string }) => {
      const res = await apiRequest("POST", "/api/wallet/deposit", {
        amount,
        paymentMethod,
      });
      return await res.json();
    },
    onSuccess: (data) => {
      // Immediately update the cache with the new user data
      queryClient.setQueryData(['/api/user'], data.user);
      
      // Also update transaction data
      const existingTransactions = queryClient.getQueryData<any[]>(['/api/wallet/transactions']) || [];
      queryClient.setQueryData(['/api/wallet/transactions'], [data.transaction, ...existingTransactions]);
      
      // Force refetch all related data to ensure consistency
      setTimeout(() => {
        queryClient.refetchQueries({ queryKey: ['/api/user'] });
        queryClient.refetchQueries({ queryKey: ['/api/wallet/transactions'] });
      }, 100);
      
      toast({
        title: "Deposit successful",
        description: `₹${amount} has been added to your wallet.`,
      });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Deposit failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAmountSelect = (value: string) => {
    setAmount(value);
  };

  // Copy UPI ID to clipboard
  const copyUpiId = () => {
    navigator.clipboard.writeText(UPI_ID);
    toast({
      title: "UPI ID copied",
      description: "The UPI ID has been copied to your clipboard.",
    });
  };
  
  // Download QR code image
  const downloadQrCode = () => {
    const link = document.createElement('a');
    link.href = '/qr-code.jpg';
    link.download = 'upi-qr-code.jpg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "QR Code downloading",
      description: "The QR code image is downloading.",
    });
  };

  const handleDeposit = () => {
    const amountNum = parseInt(amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }

    depositMutation.mutate({ amount: amountNum, paymentMethod });
  };
  
  // Handle screenshot file selection
  const handleScreenshotChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setScreenshotFile(file);
      
      // Create a preview URL
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshotPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Handle payment verification submission
  const handleVerificationSubmit = async () => {
    if (!transactionId.trim()) {
      toast({
        title: "Transaction ID Required",
        description: "Please enter the transaction ID from your payment",
        variant: "destructive",
      });
      return;
    }
    
    if (!screenshotFile) {
      toast({
        title: "Screenshot Required",
        description: "Please upload a screenshot of your payment",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Validate amount
      const amountNum = parseInt(amount);
      if (isNaN(amountNum) || amountNum <= 0) {
        toast({
          title: "Invalid amount",
          description: "Please enter a valid amount",
          variant: "destructive",
        });
        return;
      }
      
      // Create json payload for verification
      const verificationData = {
        amount: amountNum,
        transactionId: transactionId
      };
      
      // Submit the payment verification using apiRequest helper
      const response = await apiRequest("POST", "/api/wallet/verify-deposit", verificationData);
      
      // In a production app, you would upload the screenshot to cloud storage
      // For now, we'll skip actual file upload since this is a prototype
      
      if (!response.ok) {
        throw new Error('Failed to submit payment verification');
      }
      
      // Parse response
      const data = await response.json();
      
      // Update local cache with the new transaction
      const existingTransactions = queryClient.getQueryData<any[]>(['/api/wallet/transactions']) || [];
      if (data.transaction) {
        queryClient.setQueryData(['/api/wallet/transactions'], [data.transaction, ...existingTransactions]);
      }
      
      // Force immediate refetch to ensure we have the latest data
      queryClient.invalidateQueries({ queryKey: ['/api/wallet/transactions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      
      toast({
        title: "Verification Submitted",
        description: "Your payment verification has been submitted and is pending approval.",
      });
      
      onClose();
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium">Add Money</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 pt-2">
          <div>
            <Label htmlFor="amount" className="text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
              Amount
            </Label>
            <Input
              id="amount"
              type="text"
              inputMode="numeric"
              className="w-full p-3 rounded-lg border border-neutral-300 dark:border-dark-border bg-white dark:bg-dark-bg"
              placeholder="Enter amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>

          <div className="flex gap-2 mb-4">
            <Button
              type="button"
              variant={amount === "100" ? "default" : "outline"}
              className="flex-1 border border-neutral-300 dark:border-dark-border"
              onClick={() => handleAmountSelect("100")}
            >
              ₹100
            </Button>
            <Button
              type="button"
              variant={amount === "500" ? "default" : "outline"}
              className="flex-1 border border-neutral-300 dark:border-dark-border"
              onClick={() => handleAmountSelect("500")}
            >
              ₹500
            </Button>
            <Button
              type="button"
              variant={amount === "1000" ? "default" : "outline"}
              className="flex-1 border border-neutral-300 dark:border-dark-border"
              onClick={() => handleAmountSelect("1000")}
            >
              ₹1000
            </Button>
          </div>

          <div className="space-y-3">
            <Label className="text-sm font-medium text-neutral-700 dark:text-neutral-300">
              Payment Method
            </Label>
            
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="upi">UPI</TabsTrigger>
                <TabsTrigger value="card">Card</TabsTrigger>
              </TabsList>
              
              <TabsContent value="upi" className="mt-4 space-y-4">
                <div className="flex flex-col items-center p-4 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-900">
                  {/* QR Code */}
                  <div className="w-48 h-48 mb-3 border-4 border-white dark:border-gray-800 rounded-lg shadow-sm overflow-hidden bg-white">
                    <img src="/qr-code.jpg" alt="UPI QR Code" className="w-full h-full object-contain" />
                  </div>
                  
                  {/* UPI ID */}
                  <div 
                    ref={upiIdRef}
                    className="flex items-center justify-between w-full py-2 px-3 mt-3 bg-white dark:bg-gray-800 rounded-md border border-gray-200 dark:border-gray-700"
                  >
                    <span className="text-sm font-medium">{UPI_ID}</span>
                    <Button variant="ghost" size="sm" onClick={copyUpiId} className="h-8 px-2">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="flex gap-2 w-full mt-3">
                    <Button
                      variant="outline"
                      className="flex-1 text-xs"
                      onClick={copyUpiId}
                    >
                      <Copy className="h-4 w-4 mr-1" />
                      Copy UPI ID
                    </Button>
                    <Button
                      variant="outline"
                      className="flex-1 text-xs"
                      onClick={downloadQrCode}
                    >
                      <Download className="h-4 w-4 mr-1" />
                      Save QR
                    </Button>
                  </div>
                  
                  <div className="w-full mt-4 text-xs text-gray-500 dark:text-gray-400 flex items-start">
                    <AlertCircle className="h-4 w-4 mr-1 flex-shrink-0 mt-0.5 text-amber-500" />
                    <span>
                      After making the payment, click the button below to upload 
                      your payment screenshot and transaction ID.
                    </span>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="card" className="space-y-4 mt-4">
                <div className="relative p-8 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-900 overflow-hidden">
                  <div className="absolute -rotate-12 top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-gray-500/10 dark:bg-gray-700/20 px-6 py-2 rounded-md">
                    <span className="text-xl font-bold text-gray-500 dark:text-gray-400">Coming Soon</span>
                  </div>
                  
                  <div className="opacity-50 flex flex-col items-center">
                    <CreditCard className="h-16 w-16 mb-4 text-gray-400" />
                    <h3 className="text-center font-medium mb-2">Card Payments</h3>
                    <p className="text-center text-sm text-gray-500 dark:text-gray-400 mb-4">
                      Card payment option will be available soon.
                    </p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Payment verification form */}
        {activeTab === "upi" && showUploadForm && (
          <div className="border-t pt-4 mt-2 border-gray-200 dark:border-gray-700">
            <h3 className="text-sm font-medium mb-4">Verify Your Payment</h3>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="transactionId" className="text-sm">Transaction ID</Label>
                <Input 
                  id="transactionId"
                  value={transactionId}
                  onChange={(e) => setTransactionId(e.target.value)}
                  placeholder="Enter UPI transaction ID"
                  className="mt-1"
                />
              </div>
              
              <div>
                <Label htmlFor="screenshot" className="text-sm">Payment Screenshot</Label>
                <div className="mt-1">
                  {!screenshotPreview ? (
                    <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-4 text-center">
                      <label htmlFor="screenshot-upload" className="cursor-pointer block">
                        <Image className="mx-auto h-12 w-12 text-gray-400" />
                        <span className="mt-2 block text-sm font-medium text-gray-500 dark:text-gray-400">
                          Click to upload screenshot
                        </span>
                        <input
                          id="screenshot-upload"
                          name="screenshot"
                          type="file"
                          accept="image/*"
                          className="sr-only"
                          onChange={handleScreenshotChange}
                        />
                      </label>
                    </div>
                  ) : (
                    <div className="relative">
                      <img 
                        src={screenshotPreview} 
                        alt="Payment screenshot preview" 
                        className="max-h-48 mx-auto rounded-lg border border-gray-200 dark:border-gray-700"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={() => {
                          setScreenshotFile(null);
                          setScreenshotPreview(null);
                        }}
                      >
                        ×
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="flex gap-2 mt-4">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setShowUploadForm(false)}
                disabled={isSubmitting}
              >
                Back
              </Button>
              <Button
                className="flex-1"
                onClick={handleVerificationSubmit}
                disabled={isSubmitting || !transactionId || !screenshotFile}
              >
                {isSubmitting ? (
                  <>
                    <span className="animate-spin mr-2">⏳</span> Submitting...
                  </>
                ) : (
                  <>Submit Verification</>
                )}
              </Button>
            </div>
          </div>
        )}
        
        <DialogFooter className="pt-2">
          {activeTab === "upi" ? (
            showUploadForm ? null : (
              <Button
                className="w-full"
                onClick={() => setShowUploadForm(true)}
              >
                <Upload className="mr-2 h-4 w-4" /> Verify Payment
              </Button>
            )
          ) : (
            <Button
              className="w-full"
              disabled={true}
            >
              Card Payment Coming Soon
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
