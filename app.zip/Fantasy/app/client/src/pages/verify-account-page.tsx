import { useState, useRef, useEffect } from "react";
import { Header } from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, AlertCircle, Check, Calendar, Upload, Image as ImageIcon, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";

// PAN Card Schema
const panSchema = z.object({
  panNumber: z
    .string()
    .trim()
    .refine(val => val.length === 10, "PAN number must be exactly 10 characters")
    .refine(val => /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(val), "Invalid PAN format"),
  fullName: z
    .string()
    .trim()
    .min(3, "Full name must be at least 3 characters"),
  dob: z
    .date({
      required_error: "Date of birth is required",
    }),
});

// UPI Schema
const upiSchema = z.object({
  upiId: z
    .string()
    .trim()
    .min(3, "UPI ID must be at least 3 characters")
    .refine(val => /^[\w.-]+@[\w.-]+$/.test(val), "Invalid UPI ID format (e.g. name@upi)"),
  upiName: z
    .string()
    .trim()
    .min(3, "Name linked with UPI must be at least 3 characters"),
  phoneNumber: z
    .string()
    .trim()
    .refine(val => /^[6-9]\d{9}$/.test(val), "Invalid Indian phone number"),
});

// Bank Account Schema
const bankSchema = z.object({
  accountNumber: z
    .string()
    .trim()
    .min(9, "Account number must be at least 9 digits")
    .max(18, "Account number cannot exceed 18 digits")
    .refine(val => /^\d+$/.test(val), "Account number must contain only digits"),
  accountName: z
    .string()
    .trim()
    .min(3, "Account holder name must be at least 3 characters"),
  ifscCode: z
    .string()
    .trim()
    .transform(val => val.toUpperCase())
    .refine(val => val.length === 11, "IFSC code must be exactly 11 characters")
    .refine(val => /^[A-Z]{4}0[A-Z0-9]{6}$/.test(val), "Invalid IFSC code format"),
});

type PanFormValues = z.infer<typeof panSchema>;
type UpiFormValues = z.infer<typeof upiSchema>;
type BankFormValues = z.infer<typeof bankSchema>;

export default function VerifyAccountPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isPanSubmitting, setIsPanSubmitting] = useState(false);
  const [isUpiSubmitting, setIsUpiSubmitting] = useState(false);
  const [isBankSubmitting, setIsBankSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState("pan");
  
  // For PAN card image upload
  const [panCardImage, setPanCardImage] = useState<File | null>(null);
  const [panCardPreview, setPanCardPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // For Bank passbook image upload
  const [passbookImage, setPassbookImage] = useState<File | null>(null);
  const [passbookPreview, setPassbookPreview] = useState<string | null>(null);
  const passbookFileInputRef = useRef<HTMLInputElement>(null);
  
  // Fetch verification status
  const { data: verificationStatus, isLoading } = useQuery({
    queryKey: ['/api/verify/status'],
    refetchOnWindowFocus: true,
    refetchOnMount: true,
    staleTime: 0, // Don't use cached data
    gcTime: 60 * 60 * 1000, // Keep cache for 1 hour for better persistence
    refetchInterval: 3000, // Refetch more frequently (every 3 seconds)
    retry: 3, // Retry failed requests up to 3 times
    retryDelay: 1000, // 1 second delay between retries
  });

  // Form initializers
  const panForm = useForm<PanFormValues>({
    resolver: zodResolver(panSchema),
    defaultValues: {
      panNumber: "",
      fullName: "",
    },
  });

  const upiForm = useForm<UpiFormValues>({
    resolver: zodResolver(upiSchema),
    defaultValues: {
      upiId: "",
      upiName: "",
      phoneNumber: "",
    },
  });
  
  const bankForm = useForm<BankFormValues>({
    resolver: zodResolver(bankSchema),
    defaultValues: {
      accountNumber: "",
      accountName: "",
      ifscCode: "",
    },
  });
  
  // Properly type the verification status
  type VerificationStatus = {
    pan: { id: number; userId: number; type: string; status: string; data: any } | null;
    upi: { id: number; userId: number; type: string; status: string; data: any } | null;
    bank: { id: number; userId: number; type: string; status: string; data: any } | null;
  };
  
  const defaultStatus: VerificationStatus = { pan: null, upi: null, bank: null };
  const verifyStatus = (verificationStatus as VerificationStatus) || defaultStatus;
  
  // Effect to load verification data
  useEffect(() => {
    if (!verificationStatus) return;
    
    // Cast the verification status to our type for proper access
    const typedVerificationStatus = verificationStatus as VerificationStatus;
    
    // Populate the forms with existing data if available
    if (typedVerificationStatus.pan?.data) {
      const panData = typedVerificationStatus.pan.data;
      if (panData.panNumber) {
        panForm.setValue('panNumber', panData.panNumber);
      }
      if (panData.fullName) {
        panForm.setValue('fullName', panData.fullName);
      }
      if (panData.dob) {
        try {
          const dobDate = new Date(panData.dob);
          panForm.setValue('dob', dobDate);
        } catch (e) {
          console.error("Failed to parse DOB from verification data", e);
        }
      }
    }
    
    if (typedVerificationStatus.upi?.data) {
      const upiData = typedVerificationStatus.upi.data;
      if (upiData.upiId) {
        upiForm.setValue('upiId', upiData.upiId);
      }
      
      // Check for both name formats (name and upiName)
      if (upiData.name) {
        upiForm.setValue('upiName', upiData.name);
      } else if (upiData.upiName) {
        upiForm.setValue('upiName', upiData.upiName);
      }
      
      // Check for both phone formats (phone and phoneNumber)
      if (upiData.phone) {
        upiForm.setValue('phoneNumber', upiData.phone);
      } else if (upiData.phoneNumber) {
        upiForm.setValue('phoneNumber', upiData.phoneNumber);
      }
    }
    
    if (typedVerificationStatus.bank?.data) {
      const bankData = typedVerificationStatus.bank.data;
      if (bankData.accountNumber) {
        bankForm.setValue('accountNumber', bankData.accountNumber);
      }
      if (bankData.accountName) {
        bankForm.setValue('accountName', bankData.accountName);
      }
      if (bankData.ifscCode) {
        bankForm.setValue('ifscCode', bankData.ifscCode);
      }
    }
  }, [verificationStatus, panForm, upiForm, bankForm]);
  
  // Effect to show a loading indicator when submitting verifications
  useEffect(() => {
    const isSubmitting = isPanSubmitting || isUpiSubmitting || isBankSubmitting;
    if (isSubmitting) {
      // Force immediate refresh after submission completes
      const timeout = setTimeout(() => {
        queryClient.refetchQueries({ queryKey: ['/api/verify/status'] });
      }, 500); // Short delay to ensure backend has processed the request
      
      return () => clearTimeout(timeout);
    }
  }, [isPanSubmitting, isUpiSubmitting, isBankSubmitting]);
  
  // Check verification status for each type
  const isPanVerified = verifyStatus.pan ? (verifyStatus.pan.status === "pending" || verifyStatus.pan.status === "approved") : false;
  const isPanApproved = verifyStatus.pan ? verifyStatus.pan.status === "approved" : false;
  const isPanPending = verifyStatus.pan ? verifyStatus.pan.status === "pending" : false;
  
  const isUpiVerified = verifyStatus.upi ? (verifyStatus.upi.status === "pending" || verifyStatus.upi.status === "approved") : false;
  const isUpiApproved = verifyStatus.upi ? verifyStatus.upi.status === "approved" : false;
  const isUpiPending = verifyStatus.upi ? verifyStatus.upi.status === "pending" : false;
  
  const isBankVerified = verifyStatus.bank ? (verifyStatus.bank.status === "pending" || verifyStatus.bank.status === "approved") : false;
  const isBankApproved = verifyStatus.bank ? verifyStatus.bank.status === "approved" : false;
  const isBankPending = verifyStatus.bank ? verifyStatus.bank.status === "pending" : false;
  
  // Track which verification type has been completed
  const hasPanVerification = isPanVerified;
  const hasUpiVerification = isUpiVerified; // Users can verify both UPI and bank now
  const hasBankVerification = isBankVerified; // Users can verify both UPI and bank now
  
  // Handle file input change
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file type
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid file type",
          description: "Please upload an image file (JPG, PNG)",
          variant: "destructive",
        });
        return;
      }
      
      // Check file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "File size should be less than 5MB",
          variant: "destructive",
        });
        return;
      }
      
      setPanCardImage(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setPanCardPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Remove file
  const removeFile = () => {
    setPanCardImage(null);
    setPanCardPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const onSubmitPan = async (data: PanFormValues) => {
    // Check if verification is already pending
    if (isPanPending) {
      toast({
        title: "Verification In Progress",
        description: "Your PAN verification is already in progress. Please wait for approval or rejection.",
        variant: "destructive",
      });
      return;
    }
    
    // Check if PAN card image is uploaded
    if (!panCardImage) {
      toast({
        title: "PAN Card Image Required",
        description: "Please upload a photo of your PAN card for verification.",
        variant: "destructive",
      });
      return;
    }
    
    setIsPanSubmitting(true);
    
    try {
      // Convert the image to base64 for transfer
      const reader = new FileReader();
      
      // Create a promise to handle the asynchronous FileReader
      const imageBase64 = await new Promise<string>((resolve) => {
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(panCardImage);
      });
      
      // Make the actual API call
      const response = await apiRequest("POST", "/api/verify/submit", {
        type: "pan",
        data: {
          panNumber: data.panNumber,
          fullName: data.fullName,
          dob: data.dob.toISOString(),
        },
        documentUrl: imageBase64
      });
      
      if (response.ok) {
        // Immediately fetch updated verification status to reflect changes right away
        await queryClient.refetchQueries({ queryKey: ['/api/verify/status'] });
        
        toast({
          title: "PAN Verification Request Submitted",
          description: "Your PAN verification will be processed within 24-48 hours.",
        });
        
        // Reload the page after successful submission
        window.location.reload();
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to submit verification");
      }
    } catch (error) {
      console.error("PAN verification submission error:", error);
      toast({
        title: "Submission Failed",
        description: error instanceof Error ? error.message : "Failed to submit PAN verification. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsPanSubmitting(false);
    }
  };

  const onSubmitUpi = async (data: UpiFormValues) => {
    // Check if verification is already pending
    if (isUpiPending) {
      toast({
        title: "Verification In Progress",
        description: "Your UPI verification is already in progress. Please wait for approval or rejection.",
        variant: "destructive",
      });
      return;
    }
    
    setIsUpiSubmitting(true);
    
    try {
      // Make the actual API call
      const response = await apiRequest("POST", "/api/verify/submit", {
        type: "upi",
        data: {
          upiId: data.upiId,
          name: data.upiName,     // Changed from upiName to name for consistency
          phone: data.phoneNumber, // Changed from phoneNumber to phone for consistency
          // Keep the original fields too for backward compatibility
          upiName: data.upiName,
          phoneNumber: data.phoneNumber,
        }
      });
      
      if (response.ok) {
        // Immediately fetch updated verification status to reflect changes right away
        await queryClient.refetchQueries({ queryKey: ['/api/verify/status'] });
        
        toast({
          title: "UPI Details Submitted",
          description: "Your UPI details have been saved successfully.",
        });
        
        // Reload the page after successful submission
        window.location.reload();
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to submit UPI details");
      }
    } catch (error) {
      console.error("UPI verification submission error:", error);
      toast({
        title: "Submission Failed",
        description: error instanceof Error ? error.message : "Failed to submit UPI details. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsUpiSubmitting(false);
    }
  };
  
  // Handle passbook file change
  const handlePassbookFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file type
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid file type",
          description: "Please upload an image file (JPG, PNG)",
          variant: "destructive",
        });
        return;
      }
      
      // Check file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "File size should be less than 5MB",
          variant: "destructive",
        });
        return;
      }
      
      setPassbookImage(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setPassbookPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Remove passbook file
  const removePassbookFile = () => {
    setPassbookImage(null);
    setPassbookPreview(null);
    if (passbookFileInputRef.current) {
      passbookFileInputRef.current.value = '';
    }
  };
  
  const onSubmitBank = async (data: BankFormValues) => {
    // Check if verification is already pending
    if (isBankPending) {
      toast({
        title: "Verification In Progress",
        description: "Your bank account verification is already in progress. Please wait for approval or rejection.",
        variant: "destructive",
      });
      return;
    }
    
    // Check if passbook image is uploaded
    if (!passbookImage) {
      toast({
        title: "Passbook Image Required",
        description: "Please upload a photo of your bank passbook for verification.",
        variant: "destructive",
      });
      return;
    }
    
    setIsBankSubmitting(true);
    
    try {
      // Convert the image to base64 for transfer
      const reader = new FileReader();
      
      // Create a promise to handle the asynchronous FileReader
      const imageBase64 = await new Promise<string>((resolve) => {
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(passbookImage);
      });
      
      // Make the actual API call
      const response = await apiRequest("POST", "/api/verify/submit", {
        type: "bank",
        data: {
          accountNumber: data.accountNumber,
          accountName: data.accountName,
          ifscCode: data.ifscCode,
        },
        documentUrl: imageBase64
      });
      
      if (response.ok) {
        // Immediately fetch updated verification status to reflect changes right away
        await queryClient.refetchQueries({ queryKey: ['/api/verify/status'] });
        
        toast({
          title: "Bank Account Details Submitted",
          description: "Your bank account details have been saved successfully.",
        });
        
        // Reload the page after successful submission
        window.location.reload();
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to submit bank details");
      }
    } catch (error) {
      console.error("Bank verification submission error:", error);
      toast({
        title: "Submission Failed",
        description: error instanceof Error ? error.message : "Failed to submit bank details. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsBankSubmitting(false);
    }
  };

  return (
    <div className="pb-20 min-h-screen bg-gray-50 dark:bg-dark-bg">
      <Header
        title="Verify Account"
        showBack
        className="bg-primary text-white"
      />

      <div className="p-4 max-w-[480px] mx-auto">
        <div className="bg-white dark:bg-dark-card rounded-xl shadow-sm p-4">
          <h2 className="text-xl font-bold mb-4">Identity Verification</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-2">
            To verify your account, please submit the following documents and details:
          </p>
          <div className="bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-700 rounded-md p-3 mb-6">
            <p className="text-sm text-amber-800 dark:text-amber-200 flex items-start">
              <AlertCircle className="h-5 w-5 mr-2 text-amber-500 flex-shrink-0 mt-0.5" />
              <span>
                <strong>Required:</strong> PAN Card + either UPI ID or Bank Account details. You must verify at least 2 items.
              </span>
            </p>
          </div>

          <div className="space-y-6">
            {/* Tabs for PAN, UPI and Bank */}
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3 mb-4">
                <TabsTrigger value="pan">PAN Card</TabsTrigger>
                <TabsTrigger value="upi">UPI ID</TabsTrigger>
                <TabsTrigger value="bank">Bank Account</TabsTrigger>
              </TabsList>
              
              {/* PAN Tab Content */}
              <TabsContent value="pan">
                <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="font-medium">PAN Card Details</h3>
                    {isPanPending && (
                      <span className="inline-flex items-center text-xs font-medium px-2 py-1 bg-amber-50 border border-amber-200 rounded-full text-amber-600 animate-pulse">
                        <div className="mr-1 h-2 w-2 bg-amber-500 rounded-full"></div>
                        Pending Verification
                      </span>
                    )}
                    {hasPanVerification && (
                      <span className="inline-flex items-center text-xs font-medium px-2 py-1 bg-green-50 border border-green-200 rounded-full text-green-600">
                        <Check className="mr-1 h-3 w-3" />
                        Verified
                      </span>
                    )}
                  </div>
                  
                  {!isPanVerified ? (
                    <Form {...panForm}>
                      <form onSubmit={panForm.handleSubmit(onSubmitPan)} className="space-y-4">
                        <FormField
                          control={panForm.control}
                          name="panNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>PAN Number</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="e.g. ABCDE1234F" 
                                  {...field} 
                                  className="uppercase"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={panForm.control}
                          name="fullName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Full Name (as on PAN Card)</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="e.g. John Doe" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={panForm.control}
                          name="dob"
                          render={({ field }) => (
                            <FormItem className="flex flex-col">
                              <FormLabel>Date of Birth</FormLabel>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <FormControl>
                                    <Button
                                      variant={"outline"}
                                      className={cn(
                                        "pl-3 text-left font-normal",
                                        !field.value && "text-muted-foreground"
                                      )}
                                    >
                                      {field.value ? (
                                        format(field.value, "PPP")
                                      ) : (
                                        <span>Pick a date</span>
                                      )}
                                      <Calendar className="ml-auto h-4 w-4 opacity-50" />
                                    </Button>
                                  </FormControl>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                  <CalendarComponent
                                    mode="single"
                                    selected={field.value}
                                    onSelect={field.onChange}
                                    disabled={(date) =>
                                      date > new Date() || date < new Date("1900-01-01")
                                    }
                                    initialFocus
                                  />
                                </PopoverContent>
                              </Popover>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="space-y-2">
                          <FormLabel>PAN Card Image</FormLabel>
                          <div className="grid gap-4">
                            {!panCardPreview ? (
                              <label
                                htmlFor="panCardUpload"
                                className="cursor-pointer border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center hover:border-primary/50 transition-colors"
                              >
                                <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                                <p className="text-sm text-muted-foreground mb-1">Click to upload PAN Card</p>
                                <p className="text-xs text-muted-foreground">JPG, PNG (max. 5MB)</p>
                                <input
                                  id="panCardUpload"
                                  type="file"
                                  className="hidden"
                                  accept="image/*"
                                  onChange={handleFileChange}
                                  ref={fileInputRef}
                                />
                              </label>
                            ) : (
                              <div className="relative">
                                <img
                                  src={panCardPreview}
                                  alt="PAN Card Preview"
                                  className="w-full rounded-lg object-cover h-[200px]"
                                />
                                <Button
                                  variant="destructive"
                                  size="icon"
                                  className="absolute top-2 right-2 h-8 w-8 rounded-full"
                                  onClick={removeFile}
                                >
                                  ✕
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <Button type="submit" className="w-full" disabled={isPanSubmitting}>
                          {isPanSubmitting ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Submitting...
                            </>
                          ) : (
                            'Submit PAN Verification'
                          )}
                        </Button>
                      </form>
                    </Form>
                  ) : (
                    <div className="space-y-4">
                      {/* Display PAN Information - Read Only */}
                      <div className="space-y-4">
                        <div className="grid gap-1">
                          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">PAN Number</p>
                          <p className="text-sm font-bold">{verifyStatus.pan?.data?.panNumber || 'N/A'}</p>
                        </div>
                        
                        <div className="grid gap-1">
                          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Full Name</p>
                          <p className="text-sm font-bold">{verifyStatus.pan?.data?.fullName || 'N/A'}</p>
                        </div>
                        
                        <div className="grid gap-1">
                          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Date of Birth</p>
                          <p className="text-sm font-bold">
                            {verifyStatus.pan?.data?.dob ? format(new Date(verifyStatus.pan.data.dob), 'PPP') : 'N/A'}
                          </p>
                        </div>
                        
                        {/* Rejected Status */}
                        {verifyStatus.pan?.status === "rejected" && (
                          <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md">
                            <p className="text-sm text-red-700 dark:text-red-300 font-medium">Verification Rejected</p>
                            <p className="text-xs text-red-600 dark:text-red-400 mt-1">
                              Reason: {verifyStatus.pan?.data?.rejectionReason || "Invalid documentation or information. Please resubmit."}
                            </p>
                            <Button 
                              variant="destructive" 
                              size="sm" 
                              className="mt-2"
                              onClick={() => {
                                // Reset the verification status to allow resubmission
                                setActiveTab("pan");
                              }}
                            >
                              Resubmit Verification
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </TabsContent>
              
              {/* UPI Tab Content */}
              <TabsContent value="upi">
                <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="font-medium">UPI Details</h3>
                    {isUpiPending && (
                      <span className="inline-flex items-center text-xs font-medium px-2 py-1 bg-amber-50 border border-amber-200 rounded-full text-amber-600 animate-pulse">
                        <div className="mr-1 h-2 w-2 bg-amber-500 rounded-full"></div>
                        Pending Verification
                      </span>
                    )}
                    {hasUpiVerification && (
                      <span className="inline-flex items-center text-xs font-medium px-2 py-1 bg-green-50 border border-green-200 rounded-full text-green-600">
                        <Check className="mr-1 h-3 w-3" />
                        Verified
                      </span>
                    )}
                  </div>
                  
                  {!isUpiVerified ? (
                    <Form {...upiForm}>
                      <form onSubmit={upiForm.handleSubmit(onSubmitUpi)} className="space-y-4">
                        <FormField
                          control={upiForm.control}
                          name="upiId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>UPI ID</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="e.g. name@upi" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={upiForm.control}
                          name="upiName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Name linked with UPI</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="e.g. John Doe" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={upiForm.control}
                          name="phoneNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number linked with UPI</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="e.g. 9876543210" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button type="submit" className="w-full" disabled={isUpiSubmitting}>
                          {isUpiSubmitting ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Submitting...
                            </>
                          ) : (
                            'Submit UPI Verification'
                          )}
                        </Button>
                      </form>
                    </Form>
                  ) : (
                    <div className="space-y-4">
                      {/* Display UPI Information - Read Only */}
                      <div className="space-y-4">
                        <div className="grid gap-1">
                          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">UPI ID</p>
                          <p className="text-sm font-bold">{verifyStatus.upi?.data?.upiId || 'N/A'}</p>
                        </div>
                        
                        <div className="grid gap-1">
                          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Name linked with UPI</p>
                          <p className="text-sm font-bold">{verifyStatus.upi?.data?.name || verifyStatus.upi?.data?.upiName || 'N/A'}</p>
                        </div>
                        
                        <div className="grid gap-1">
                          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Phone Number</p>
                          <p className="text-sm font-bold">{verifyStatus.upi?.data?.phone || verifyStatus.upi?.data?.phoneNumber || 'N/A'}</p>
                        </div>
                        
                        {/* Rejected Status */}
                        {verifyStatus.upi?.status === "rejected" && (
                          <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md">
                            <p className="text-sm text-red-700 dark:text-red-300 font-medium">Verification Rejected</p>
                            <p className="text-xs text-red-600 dark:text-red-400 mt-1">
                              Reason: {verifyStatus.upi?.data?.rejectionReason || "Invalid UPI details. Please resubmit."}
                            </p>
                            <Button 
                              variant="destructive" 
                              size="sm" 
                              className="mt-2"
                              onClick={() => {
                                // Reset the verification status to allow resubmission
                                setActiveTab("upi");
                              }}
                            >
                              Resubmit Verification
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </TabsContent>
              
              {/* Bank Tab Content */}
              <TabsContent value="bank">
                <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="font-medium">Bank Account Details</h3>
                    {isBankPending && (
                      <span className="inline-flex items-center text-xs font-medium px-2 py-1 bg-amber-50 border border-amber-200 rounded-full text-amber-600 animate-pulse">
                        <div className="mr-1 h-2 w-2 bg-amber-500 rounded-full"></div>
                        Pending Verification
                      </span>
                    )}
                    {hasBankVerification && (
                      <span className="inline-flex items-center text-xs font-medium px-2 py-1 bg-green-50 border border-green-200 rounded-full text-green-600">
                        <Check className="mr-1 h-3 w-3" />
                        Verified
                      </span>
                    )}
                  </div>
                  
                  {!isBankVerified ? (
                    <Form {...bankForm}>
                      <form onSubmit={bankForm.handleSubmit(onSubmitBank)} className="space-y-4">
                        <FormField
                          control={bankForm.control}
                          name="accountNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Account Number</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="e.g. 123456789012" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={bankForm.control}
                          name="accountName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Account Holder Name</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="e.g. John Doe" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={bankForm.control}
                          name="ifscCode"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>IFSC Code</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="e.g. SBIN0123456" 
                                  {...field} 
                                  className="uppercase"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="space-y-2">
                          <FormLabel>Bank Passbook / Statement</FormLabel>
                          <div className="grid gap-4">
                            {!passbookPreview ? (
                              <label
                                htmlFor="passbookUpload"
                                className="cursor-pointer border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center hover:border-primary/50 transition-colors"
                              >
                                <FileText className="h-8 w-8 text-muted-foreground mb-2" />
                                <p className="text-sm text-muted-foreground mb-1">Click to upload Passbook/Statement</p>
                                <p className="text-xs text-muted-foreground">JPG, PNG (max. 5MB)</p>
                                <input
                                  id="passbookUpload"
                                  type="file"
                                  className="hidden"
                                  accept="image/*"
                                  onChange={handlePassbookFileChange}
                                  ref={passbookFileInputRef}
                                />
                              </label>
                            ) : (
                              <div className="relative">
                                <img
                                  src={passbookPreview}
                                  alt="Passbook Preview"
                                  className="w-full rounded-lg object-cover h-[200px]"
                                />
                                <Button
                                  variant="destructive"
                                  size="icon"
                                  className="absolute top-2 right-2 h-8 w-8 rounded-full"
                                  onClick={removePassbookFile}
                                >
                                  ✕
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <Button type="submit" className="w-full" disabled={isBankSubmitting}>
                          {isBankSubmitting ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Submitting...
                            </>
                          ) : (
                            'Submit Bank Verification'
                          )}
                        </Button>
                      </form>
                    </Form>
                  ) : (
                    <div className="space-y-4">
                      {/* Display Bank Information - Read Only */}
                      <div className="space-y-4">
                        <div className="grid gap-1">
                          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Account Number</p>
                          <p className="text-sm font-bold">
                            {verifyStatus.bank?.data?.accountNumber ? 
                              verifyStatus.bank.data.accountNumber.replace(/\d(?=\d{4})/g, "*") : 
                              'N/A'}
                          </p>
                        </div>
                        
                        <div className="grid gap-1">
                          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Account Holder Name</p>
                          <p className="text-sm font-bold">{verifyStatus.bank?.data?.accountName || 'N/A'}</p>
                        </div>
                        
                        <div className="grid gap-1">
                          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">IFSC Code</p>
                          <p className="text-sm font-bold">{verifyStatus.bank?.data?.ifscCode || 'N/A'}</p>
                        </div>
                        
                        {/* Rejected Status */}
                        {verifyStatus.bank?.status === "rejected" && (
                          <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md">
                            <p className="text-sm text-red-700 dark:text-red-300 font-medium">Verification Rejected</p>
                            <p className="text-xs text-red-600 dark:text-red-400 mt-1">
                              Reason: {verifyStatus.bank?.data?.rejectionReason || "Invalid bank details. Please resubmit."}
                            </p>
                            <Button 
                              variant="destructive" 
                              size="sm" 
                              className="mt-2"
                              onClick={() => {
                                // Reset the verification status to allow resubmission
                                setActiveTab("bank");
                              }}
                            >
                              Resubmit Verification
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Verification Status Summary */}
          <div className="mt-6 pt-6 border-t">
            <p className="text-base font-medium mb-2">Verification Status</p>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${isPanApproved ? 'bg-green-500' : isPanPending ? 'bg-amber-500' : 'bg-gray-300'}`}></div>
                <p className="text-sm">PAN Card: 
                  <span className={`ml-1 font-medium ${isPanApproved ? 'text-green-600' : isPanPending ? 'text-amber-600' : 'text-gray-500'}`}>
                    {isPanApproved ? 'Verified' : isPanPending ? 'Pending' : 'Not Submitted'}
                  </span>
                </p>
              </div>
              
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${hasUpiVerification ? 'bg-green-500' : isUpiPending ? 'bg-amber-500' : 'bg-gray-300'}`}></div>
                <p className="text-sm">UPI: 
                  <span className={`ml-1 font-medium ${hasUpiVerification ? 'text-green-600' : isUpiPending ? 'text-amber-600' : 'text-gray-500'}`}>
                    {hasUpiVerification ? 'Verified' : isUpiPending ? 'Pending' : 'Not Submitted'}
                  </span>
                </p>
              </div>
              
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${hasBankVerification ? 'bg-green-500' : isBankPending ? 'bg-amber-500' : 'bg-gray-300'}`}></div>
                <p className="text-sm">Bank Account: 
                  <span className={`ml-1 font-medium ${hasBankVerification ? 'text-green-600' : isBankPending ? 'text-amber-600' : 'text-gray-500'}`}>
                    {hasBankVerification ? 'Verified' : isBankPending ? 'Pending' : 'Not Submitted'}
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}