import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Match } from "@shared/schema";
import { Link } from "wouter";
import { Header } from "@/components/layout/header";
import { NavBar } from "@/components/layout/nav-bar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { MatchCard } from "@/components/cricket/match-card";
import { PullToRefresh } from "@/components/ui/pull-to-refresh";
import { useToast } from "@/hooks/use-toast";

export default function HomePage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const { data: matches, isLoading, error } = useQuery<Match[]>({
    queryKey: ['/api/matches'],
  });

  // Handle refresh function - without success toast
  const handleRefresh = async () => {
    try {
      // Refetch matches data
      await queryClient.refetchQueries({ queryKey: ['/api/matches'] });
      // Also refetch notification count
      await queryClient.refetchQueries({ queryKey: ['/api/get-notification-count'] });
      
      return true;
    } catch (error) {
      // Only show toast on error
      toast({
        title: "Refresh failed",
        description: "Couldn't refresh data. Please try again.",
        variant: "destructive",
      });
      return false;
    }
  };

  // Filter matches by status
  const upcomingMatches = matches?.filter(match => match.status === 'upcoming') || [];
  const liveMatches = matches?.filter(match => match.status === 'live') || [];
  const completedMatches = matches?.filter(match => match.status === 'completed') || [];

  return (
    <div className="min-h-screen flex flex-col pb-16">
      <Header 
        showNotification={true} 
        showWallet={true} 
      />
      
      <PullToRefresh onRefresh={handleRefresh}>
        <Tabs defaultValue="upcoming">
          <TabsList className="w-full border-b border-neutral-200 dark:border-dark-border rounded-none bg-transparent">
            <TabsTrigger
              value="upcoming"
              className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
            >
              Upcoming
            </TabsTrigger>
            <TabsTrigger
              value="live"
              className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
            >
              Live
            </TabsTrigger>
            <TabsTrigger
              value="completed"
              className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
            >
              Completed
            </TabsTrigger>
          </TabsList>

          <div className="flex-1 p-4 space-y-4">
            {/* Hero Banner */}
            <div className="rounded-xl overflow-hidden relative h-36 mb-6 bg-gradient-to-r from-primary to-primary-dark">
              <div className="absolute inset-0 p-4 flex flex-col justify-between">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-white font-semibold text-lg">Get ₹100 Bonus</h3>
                    <p className="text-white text-opacity-90 text-sm">Join your first contest today!</p>
                  </div>
                  <Button variant="secondary" className="bg-white text-primary px-3 py-1 h-8 text-sm rounded-full font-medium hover:bg-neutral-100">
                    Claim Now
                  </Button>
                </div>
                <div className="flex gap-2">
                  <div className="bg-white bg-opacity-20 backdrop-blur-sm rounded-lg p-2">
                    <p className="text-white text-xs">Refer a friend</p>
                    <p className="text-white font-semibold">Get ₹50 each</p>
                  </div>
                  <div className="bg-white bg-opacity-20 backdrop-blur-sm rounded-lg p-2">
                    <p className="text-white text-xs">Today's Leaderboard</p>
                    <p className="text-white font-semibold">Win up to ₹1000</p>
                  </div>
                </div>
              </div>
            </div>

            <TabsContent value="upcoming" className="mt-0 space-y-4">
              {isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : error ? (
                <div className="text-center py-8 text-red-500">
                  Failed to load matches. Please try again.
                </div>
              ) : upcomingMatches.length === 0 ? (
                <div className="text-center py-8 text-neutral-500">
                  No upcoming matches at the moment.
                </div>
              ) : (
                upcomingMatches.map((match) => (
                  <MatchCard key={match.id} match={match} />
                ))
              )}
            </TabsContent>

            <TabsContent value="live" className="mt-0 space-y-4">
              {isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : error ? (
                <div className="text-center py-8 text-red-500">
                  Failed to load matches. Please try again.
                </div>
              ) : liveMatches.length === 0 ? (
                <div className="text-center py-8 text-neutral-500">
                  No live matches at the moment.
                </div>
              ) : (
                liveMatches.map((match) => (
                  <MatchCard key={match.id} match={match} />
                ))
              )}
            </TabsContent>

            <TabsContent value="completed" className="mt-0 space-y-4">
              {isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : error ? (
                <div className="text-center py-8 text-red-500">
                  Failed to load matches. Please try again.
                </div>
              ) : completedMatches.length === 0 ? (
                <div className="text-center py-8 text-neutral-500">
                  No completed matches at the moment.
                </div>
              ) : (
                completedMatches.map((match) => (
                  <MatchCard key={match.id} match={match} />
                ))
              )}
            </TabsContent>
          </div>
        </Tabs>
      </PullToRefresh>

      <NavBar />
    </div>
  );
}