import { createRoot } from "react-dom/client";
import { QueryClientProvider } from "@tanstack/react-query";
// Removed ReactQueryDevtools import
import { queryClient } from "./lib/queryClient";
import App from "./App";
import "./index.css";
import { StrictMode } from "react";

// Simple root render without nesting providers
const root = createRoot(document.getElementById("root")!);

console.log("main.tsx: Rendering application with providers");

// Use QueryClientProvider at the root level with DevTools for debugging
root.render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </StrictMode>
);
