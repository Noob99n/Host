import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AvatarStack } from "@/components/ui/avatar-stack";
import { Link } from "wouter";
import { Match } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

type MatchCardProps = {
  match: Match;
};

export function MatchCard({ match }: MatchCardProps) {
  // Calculate time left until match starts
  const timeLeft = formatDistanceToNow(new Date(match.startTime), { addSuffix: false });
  
  // Mock data for avatar stack - in a real app this would come from the API
  const avatars = [
    {
      src: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=120&h=120&q=80",
      alt: "User 1",
      fallback: "U1",
    },
    {
      src: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=120&h=120&q=80",
      alt: "User 2",
      fallback: "U2",
    },
    {
      src: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=120&h=120&q=80",
      alt: "User 3",
      fallback: "U3",
    },
  ];
  
  return (
    <Card className="shadow-sm border border-neutral-200 dark:border-dark-border hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-3">
          <span className="text-xs font-medium bg-neutral-100 dark:bg-dark-bg text-neutral-600 dark:text-neutral-400 px-2 py-1 rounded">
            {match.format} • {new Date(match.startTime).toLocaleDateString('en-US', { day: 'numeric', month: 'long' })}, {new Date(match.startTime).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}
          </span>
          <div className="flex items-center gap-1">
            <span className="bg-green-500 rounded-full w-2 h-2"></span>
            <span className="text-xs text-green-500 font-medium">{timeLeft} left</span>
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <div className="flex flex-col items-center gap-2">
            <div className="w-12 h-12 rounded-full bg-neutral-100 dark:bg-dark-bg p-1">
              <img src={match.team1Logo} alt={match.team1} className="w-full h-full object-contain" />
            </div>
            <span className="font-semibold">{match.team1}</span>
          </div>
          <div className="text-center">
            <span className="text-neutral-500 dark:text-neutral-400 text-sm">vs</span>
          </div>
          <div className="flex flex-col items-center gap-2">
            <div className="w-12 h-12 rounded-full bg-neutral-100 dark:bg-dark-bg p-1">
              <img src={match.team2Logo} alt={match.team2} className="w-full h-full object-contain" />
            </div>
            <span className="font-semibold">{match.team2}</span>
          </div>
        </div>
        
        <div className="mt-4 flex gap-3">
          <div className="flex-1 bg-neutral-100 dark:bg-dark-bg rounded-lg p-3">
            <div className="flex justify-between items-center mb-1">
              <span className="text-xs text-neutral-600 dark:text-neutral-400">Prize Pool</span>
              <span className="text-xs text-green-500 font-medium">10,000 spots</span>
            </div>
            <span className="font-semibold">₹10 Lakhs</span>
          </div>
          <div className="flex-1 bg-neutral-100 dark:bg-dark-bg rounded-lg p-3">
            <div className="flex justify-between items-center mb-1">
              <span className="text-xs text-neutral-600 dark:text-neutral-400">Entry</span>
              <span className="text-xs text-primary font-medium">5 contests</span>
            </div>
            <span className="font-semibold">₹49 - ₹5999</span>
          </div>
        </div>
        
        <div className="mt-3 flex justify-between items-center">
          <AvatarStack 
            avatars={avatars} 
            max={3} 
            size={24} 
            label="playing"
          />
          <Link href={`/matches/${match.id}`}>
            <Button size="sm">
              Join
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
