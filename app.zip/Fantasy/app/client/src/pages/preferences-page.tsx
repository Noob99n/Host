import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BellRing, Moon, Sun, Globe, ChevronDown, ArrowLeft, Palette, Tv2, Home, BellOff } from 'lucide-react';
import { Loader2 } from 'lucide-react';
import BottomNav from '@/components/layout/bottom-nav';
import { useLocation } from 'wouter';

// Interface for user preferences
interface UserPreferences {
  id: number;
  userId: number;
  theme: 'light' | 'dark' | 'system';
  language: string;
  notificationsEnabled: boolean;
  matchNotifications: boolean;
  transactionNotifications: boolean;
  promotionalNotifications: boolean;
  contentPreferences: string;
  defaultView: string;
  createdAt: string;
  updatedAt: string;
}

export default function PreferencesPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  // Query user preferences
  const { 
    data: preferences, 
    isLoading, 
    error 
  } = useQuery<UserPreferences>({
    queryKey: ['/api/user-preferences'],
    enabled: !!user,
  });
  
  // Mutation for updating preferences
  const updatePreferencesMutation = useMutation({
    mutationFn: async (preferences: Partial<UserPreferences>) => {
      const res = await apiRequest('POST', '/api/user-preferences', preferences);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user-preferences'] });
      toast({
        title: 'Preferences Updated',
        description: 'Your preferences have been saved successfully.',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to Update Preferences',
        description: error.message || 'Please try again later.',
        variant: 'destructive',
      });
    },
  });
  
  const handleThemeChange = (theme: 'light' | 'dark' | 'system') => {
    updatePreferencesMutation.mutate({ theme });
    
    // Apply theme immediately for better user experience
    if (theme === 'system') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      document.documentElement.classList.toggle('dark', systemTheme === 'dark');
    } else {
      document.documentElement.classList.toggle('dark', theme === 'dark');
    }
  };
  
  const handleLanguageChange = (language: string) => {
    updatePreferencesMutation.mutate({ language });
  };
  
  const handleNotificationToggle = (field: keyof UserPreferences, value: boolean) => {
    updatePreferencesMutation.mutate({ [field]: value });
  };
  
  const handleDefaultViewChange = (defaultView: string) => {
    updatePreferencesMutation.mutate({ defaultView });
  };
  
  // If still loading preferences
  if (isLoading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
        <p className="mt-4 text-sm text-muted-foreground">Loading preferences...</p>
      </div>
    );
  }
  
  // If there was an error
  if (error) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center p-4">
        <div className="text-destructive">Failed to load preferences</div>
        <p className="mt-2 text-sm text-muted-foreground">{(error as Error).message}</p>
        <Button 
          className="mt-4" 
          variant="outline"
          onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/user-preferences'] })}
        >
          Try Again
        </Button>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <div className="sticky top-0 z-10 flex items-center h-14 px-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <Button 
          variant="ghost" 
          size="icon" 
          className="mr-1" 
          onClick={() => setLocation('/more')}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-lg font-semibold">Preferences</h1>
      </div>
      
      <div className="flex-1 container max-w-lg mx-auto p-4">
        <Tabs defaultValue="appearance">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="appearance">Appearance</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="general">General</TabsTrigger>
          </TabsList>
          
          {/* Appearance Tab */}
          <TabsContent value="appearance" className="space-y-4 pt-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5 text-primary" />
                  Theme
                </CardTitle>
                <CardDescription>
                  Customize how 11byChatGPT looks
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-3 gap-4">
                  <Button 
                    variant={preferences?.theme === 'light' ? 'default' : 'outline'} 
                    className="flex flex-col h-auto py-4"
                    onClick={() => handleThemeChange('light')}
                  >
                    <Sun className="h-5 w-5 mb-2" />
                    <span>Light</span>
                  </Button>
                  <Button 
                    variant={preferences?.theme === 'dark' ? 'default' : 'outline'} 
                    className="flex flex-col h-auto py-4"
                    onClick={() => handleThemeChange('dark')}
                  >
                    <Moon className="h-5 w-5 mb-2" />
                    <span>Dark</span>
                  </Button>
                  <Button 
                    variant={preferences?.theme === 'system' ? 'default' : 'outline'} 
                    className="flex flex-col h-auto py-4"
                    onClick={() => handleThemeChange('system')}
                  >
                    <Tv2 className="h-5 w-5 mb-2" />
                    <span>System</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-primary" />
                  Language
                </CardTitle>
                <CardDescription>
                  Change application language
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Select 
                  value={preferences?.language || 'en'} 
                  onValueChange={handleLanguageChange}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="hi">हिंदी (Hindi)</SelectItem>
                    <SelectItem value="bn">বাংলা (Bengali)</SelectItem>
                    <SelectItem value="te">తెలుగు (Telugu)</SelectItem>
                    <SelectItem value="ta">தமிழ் (Tamil)</SelectItem>
                    <SelectItem value="mr">मराठी (Marathi)</SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Notifications Tab */}
          <TabsContent value="notifications" className="space-y-4 pt-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BellRing className="h-5 w-5 text-primary" />
                  Notification Settings
                </CardTitle>
                <CardDescription>
                  Manage how you receive notifications
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">All Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Turn on/off all notifications
                    </p>
                  </div>
                  <Switch 
                    checked={preferences?.notificationsEnabled} 
                    onCheckedChange={(checked) => 
                      handleNotificationToggle('notificationsEnabled', checked)
                    }
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Match Updates</Label>
                    <p className="text-sm text-muted-foreground">
                      Get notified about match starts and results
                    </p>
                  </div>
                  <Switch 
                    checked={preferences?.matchNotifications} 
                    disabled={!preferences?.notificationsEnabled}
                    onCheckedChange={(checked) => 
                      handleNotificationToggle('matchNotifications', checked)
                    }
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Transaction Alerts</Label>
                    <p className="text-sm text-muted-foreground">
                      Get notified about deposits and withdrawals
                    </p>
                  </div>
                  <Switch 
                    checked={preferences?.transactionNotifications} 
                    disabled={!preferences?.notificationsEnabled}
                    onCheckedChange={(checked) => 
                      handleNotificationToggle('transactionNotifications', checked)
                    }
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Promotional Updates</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive offers, bonuses and news
                    </p>
                  </div>
                  <Switch 
                    checked={preferences?.promotionalNotifications} 
                    disabled={!preferences?.notificationsEnabled}
                    onCheckedChange={(checked) => 
                      handleNotificationToggle('promotionalNotifications', checked)
                    }
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* General Tab */}
          <TabsContent value="general" className="space-y-4 pt-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Home className="h-5 w-5 text-primary" />
                  Default View
                </CardTitle>
                <CardDescription>
                  Choose which page to show when you open the app
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Select 
                  value={preferences?.defaultView || 'matches'} 
                  onValueChange={handleDefaultViewChange}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Default View" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="matches">Matches</SelectItem>
                    <SelectItem value="myteams">My Teams</SelectItem>
                    <SelectItem value="wallet">Wallet</SelectItem>
                    <SelectItem value="more">More</SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      <BottomNav activeItem="more" />
    </div>
  );
}