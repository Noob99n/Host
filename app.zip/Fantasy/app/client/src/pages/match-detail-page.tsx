import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Match, Contest } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { NavBar } from "@/components/layout/nav-bar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Loader2, Plus } from "lucide-react";
import { ContestCard } from "@/components/cricket/contest-card";
import { formatDistanceToNow } from "date-fns";

export default function MatchDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  
  const matchId = parseInt(id);
  
  const { data: match, isLoading: isLoadingMatch } = useQuery<Match>({
    queryKey: [`/api/matches/${matchId}`],
  });
  
  const { data: contests, isLoading: isLoadingContests } = useQuery<Contest[]>({
    queryKey: [`/api/matches/${matchId}/contests`],
    enabled: !!matchId,
  });
  
  const handleCreateTeam = () => {
    setLocation(`/create-team/${matchId}`);
  };
  
  if (isLoadingMatch) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!match) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <p className="text-lg text-neutral-600 dark:text-neutral-400">Match not found</p>
        <Button onClick={() => setLocation("/")} className="mt-4">
          Back to Home
        </Button>
      </div>
    );
  }
  
  // Calculate time left
  const timeLeft = formatDistanceToNow(new Date(match.startTime), { addSuffix: false });

  return (
    <div className="min-h-screen flex flex-col pb-16">
      <Header 
        showBack={true}
        backUrl="/"
        title={`${match.team1} vs ${match.team2}`}
        showNotification={true}
      />
      
      {/* Match Info */}
      <div className="px-4 pb-4">
        <div className="flex justify-between items-center">
          <div className="flex flex-col items-center gap-2">
            <div className="w-12 h-12 rounded-full bg-neutral-100 dark:bg-dark-bg p-1">
              <img src={match.team1Logo} alt={match.team1} className="w-full h-full object-contain" />
            </div>
            <span className="font-semibold">{match.team1}</span>
          </div>
          <div className="text-center">
            <span className="text-xs font-medium bg-neutral-100 dark:bg-dark-bg text-neutral-600 dark:text-neutral-400 px-2 py-1 rounded block mb-1">
              {match.format} • {new Date(match.startTime).toLocaleDateString()}
            </span>
            <span className="text-green-500 text-sm font-medium">
              {timeLeft} left
            </span>
          </div>
          <div className="flex flex-col items-center gap-2">
            <div className="w-12 h-12 rounded-full bg-neutral-100 dark:bg-dark-bg p-1">
              <img src={match.team2Logo} alt={match.team2} className="w-full h-full object-contain" />
            </div>
            <span className="font-semibold">{match.team2}</span>
          </div>
        </div>
      </div>
      
      <Tabs defaultValue="contests">
        <TabsList className="w-full border-b border-neutral-200 dark:border-dark-border rounded-none bg-transparent">
          <TabsTrigger
            value="contests"
            className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
          >
            Contests
          </TabsTrigger>
          <TabsTrigger
            value="my-contests"
            className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
          >
            My Contests
          </TabsTrigger>
          <TabsTrigger
            value="my-teams"
            className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
          >
            My Teams
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="contests" className="flex-1 p-4 space-y-4">
          {isLoadingContests ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : !contests || contests.length === 0 ? (
            <div className="text-center py-8 text-neutral-500">
              No contests available for this match.
            </div>
          ) : (
            <div className="space-y-3">
              {contests.map((contest) => (
                <ContestCard key={contest.id} contest={contest} />
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="my-contests" className="flex-1 p-4">
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <p className="text-neutral-600 dark:text-neutral-400 mb-4">
              You haven't joined any contests for this match yet.
            </p>
            <Button onClick={() => document.getElementById('contests-tab')?.click()}>
              Browse Contests
            </Button>
          </div>
        </TabsContent>
        
        <TabsContent value="my-teams" className="flex-1 p-4">
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <p className="text-neutral-600 dark:text-neutral-400 mb-4">
              You haven't created any teams for this match yet.
            </p>
            <Button onClick={handleCreateTeam}>
              Create Team
            </Button>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Create Team FAB */}
      <div className="fixed bottom-20 right-4">
        <Button 
          onClick={handleCreateTeam}
          className="bg-primary h-14 w-14 rounded-full shadow-lg flex items-center justify-center p-0 hover:bg-primary-dark"
        >
          <Plus className="text-white text-2xl h-6 w-6" />
        </Button>
      </div>
      
      <NavBar />
    </div>
  );
}
