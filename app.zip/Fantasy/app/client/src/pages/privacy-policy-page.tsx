import { useState } from "react";
import { Header } from "@/components/layout/header";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Shield } from "lucide-react";

export default function PrivacyPolicyPage() {
  const goBack = () => {
    window.history.back();
  };
  
  return (
    <div className="pb-20 min-h-screen bg-gray-50 dark:bg-dark-bg">
      <Header
        title="Privacy Policy"
        showBack
        backUrl="javascript:void(0)"
        onBackClick={goBack}
        showWallet={false}
        showNotification={false}
        className="bg-primary text-white"
      />

      <div className="p-4 max-w-[480px] mx-auto">
        <ScrollArea className="h-[calc(100vh-115px)] pr-3">
          <div className="mb-8 space-y-6">
            <section className="space-y-3">
              <h1 className="text-2xl font-bold">Privacy Policy</h1>
              <p className="text-gray-700 dark:text-gray-300">
                Welcome to 11byChatGPT's Privacy Policy. As one of India's premier fantasy sports platforms, we allow sports enthusiasts to play every type of popular game including Cricket, Kabaddi, Football, Volleyball, Basketball, etc.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT is committed to protecting the privacy of its Users in every way and values their privacy. 11byChatGPT provides numerous services to its Users to provide a comprehensive and beneficial online experience.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                You can get more information about 11byChatGPT from our "About Us" section. You need to register on our platform to play games. 11byChatGPT collects user information from two sources: (i) data provided by the user and (ii) data automatically tracked when a user navigates on 11byChatGPT.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Your Agreement with Our Privacy Policy</h2>
              <p className="text-gray-700 dark:text-gray-300">
                To understand how we will handle your information, please read our Privacy Policy before submitting any data on the portal. By using the portal in any way, you consent to the collection, processing, and protection of your information, as well as its use, disclosure, and transfer for the purposes specified in this Privacy Policy. By using any part of the portal, you agree to the collection, use, and dissemination of your personal information in accordance with its terms regarding privacy.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">On Time Privacy Update Notifications</h2>
              <p className="text-gray-700 dark:text-gray-300">
                We reserve the right to evaluate and amend our Privacy Policy from time to time to reflect any changes deemed necessary in the future given the rapidly changing landscape of the Internet. We will inform you when things change. This page will be updated with any revisions to our privacy details so that you remain constantly aware of the data we collect, how we use it, store it, and when we share it.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Personal Data Collection</h2>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT collects some essential personal information to serve its users, including:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>Username</li>
                <li>Mobile number</li>
                <li>State</li>
                <li>Date of birth</li>
                <li>Email address</li>
                <li>Valid ID verification</li>
              </ul>
              <p className="text-gray-700 dark:text-gray-300">
                Additionally, you may permit us to collect and record information about your device, operating system, network, location, and other details while you are provided access to the services and features available through the portal, to authenticate your identity, and to secure your account details. You have the option to give us consent to collect data about the application so that we can enhance your portal experience and our services. It may also be necessary for you to provide other details such as your bank account number.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Data Sharing</h2>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT may share data about your use of services and participation in games, along with information you have provided, with its affiliates and group companies so they can contact you about products and/or services they offer.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                To better serve you, we may also share this information with external service providers with whom we have partnered for data analytics, storage, service improvements (including product upgrades), and other purposes. Affiliates, group companies, and third-party service providers (where applicable) with whom data is shared agree to take appropriate measures to comply with the same rules applicable to 11byChatGPT.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Our Cookie Policy</h2>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT uses "cookies" or other similar electronic tools to collect information to assign each visitor a unique random number called a user identification (user ID), so that we can capture your interests and enhance the effectiveness and usefulness of the portal for our users.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                Even if 11byChatGPT assigns a cookie to the user's device, 11byChatGPT will not be able to identify the user unless the user voluntarily identifies themselves (for example, through registration). Cookies are limited to storing only the information that the user provides. Data stored on the user's device's hard drive cannot be read by a cookie.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Security on 11byChatGPT</h2>
              <p className="text-gray-700 dark:text-gray-300">
                The 11byChatGPT-controlled database securely stores all collected data. The database is placed on firewall-protected servers; access to these servers is strictly limited to those with a legitimate need to know and is secured with strong passwords. We recognize that any security system, no matter how strong our defenses, is vulnerable. As a result, neither the security of our database nor the guarantee that the data you provide will not be intercepted during transmission over the Internet is guaranteed.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Disclaimer</h2>
              <p className="text-gray-700 dark:text-gray-300">
                Many fraudulent emails, websites, blogs, and other content claiming to be from or associated with 11byChatGPT may exist online ("Misleading Communications"). Our logo, images, content, links, and other information may be part of these misleading communications.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                Some fraudulent communications may involve calling the recipient and asking for login credentials, for example; declaring that the recipient has won a gift or prize; providing a way to perform an illegal or unauthorized conduct or act; demanding detailed personal data; or demanding any kind of money. 11byChatGPT has no connection with the source or content of these misleading communications or the resources that accompany them.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Law of Jurisdiction</h2>
              <p className="text-gray-700 dark:text-gray-300">
                By using this portal, you acknowledge that this Privacy Policy is governed by the laws of the Indian Government, without reference to its principles of conflict of laws. Any dispute arising from this Privacy Policy will be subject to the exclusive jurisdiction of the courts in Delhi, India.
              </p>
            </section>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}