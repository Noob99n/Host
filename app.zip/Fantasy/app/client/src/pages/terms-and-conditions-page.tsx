import { useState } from "react";
import { Header } from "@/components/layout/header";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FileTerminal } from "lucide-react";

export default function TermsAndConditionsPage() {
  const goBack = () => {
    window.history.back();
  };
  
  return (
    <div className="pb-20 min-h-screen bg-gray-50 dark:bg-dark-bg">
      <Header
        title="Terms & Conditions"
        showBack
        backUrl="javascript:void(0)"
        onBackClick={goBack}
        showWallet={false}
        showNotification={false}
        className="bg-primary text-white"
      />

      <div className="p-4 max-w-[480px] mx-auto">
        <ScrollArea className="h-[calc(100vh-115px)] pr-3">
          <div className="mb-8 space-y-6">
            <section className="space-y-3">
              <h1 className="text-2xl font-bold">Terms & Conditions</h1>
              <p className="text-gray-700 dark:text-gray-300">
                Welcome to 11byChatGPT's Terms and Conditions. These Terms and Conditions ("Terms") govern your access to and use of the 11byChatGPT website, mobile applications, and services (collectively, the "Services"). By accessing or using our Services, you agree to be bound by these Terms.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                Please read these Terms carefully before using our Services. If you do not agree to these Terms, you may not access or use the Services. Our Privacy Policy also governs your use of our Services and explains how we collect, safeguard and disclose information that results from your use of our web pages.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Acceptance of Terms</h2>
              <p className="text-gray-700 dark:text-gray-300">
                By creating an account on 11byChatGPT, you acknowledge that you have read, understood, and agree to be bound by these Terms. If you are using the Services on behalf of an organization, you are agreeing to these Terms for that organization and promising that you have the authority to bind that organization to these Terms.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Eligibility</h2>
              <p className="text-gray-700 dark:text-gray-300">
                You must be at least 18 years old to use the Services. By agreeing to these Terms, you represent and warrant that:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>You are at least 18 years of age</li>
                <li>You have the right, authority, and capacity to enter into these Terms</li>
                <li>You will use the Services in a manner consistent with any and all applicable laws and regulations</li>
              </ul>
              <p className="text-gray-700 dark:text-gray-300">
                If you are found to be under 18 years of age, 11byChatGPT reserves the right to terminate your account immediately without notice.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Account Registration and Security</h2>
              <p className="text-gray-700 dark:text-gray-300">
                To use certain features of the Services, you must register for an account. When you register, you will be required to provide accurate and complete information and to keep this information updated. You are solely responsible for the activity that occurs on your account, and you must keep your account password secure.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                You must notify 11byChatGPT immediately of any breach of security or unauthorized use of your account. 11byChatGPT will not be liable for any losses caused by any unauthorized use of your account.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">User Conduct</h2>
              <p className="text-gray-700 dark:text-gray-300">
                You agree not to engage in any of the following prohibited activities:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>Using the Services for any illegal purpose or in violation of any local, state, national, or international law</li>
                <li>Copying or storing any significant portion of the content for other than personal, non-commercial use</li>
                <li>Harassing, threatening, intimidating, or impersonating anyone</li>
                <li>Interfering with or disrupting the Services or servers or networks connected to the Services</li>
                <li>Attempting to gain unauthorized access to the Services, other accounts, or computer systems through hacking, password mining, or any other means</li>
                <li>Creating multiple accounts to take advantage of promotions</li>
                <li>Participating in contests from multiple accounts</li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Fantasy Games Rules</h2>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT offers fantasy sports games that are games of skill, as they require considerable knowledge of players, teams, and various other aspects to create a successful team. The following rules apply:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>Each user can create multiple teams for one match but can join a contest with only one team</li>
                <li>Each team consists of 11 players from both teams according to specific combinations</li>
                <li>Users earn points based on the actual performance of selected players in the real-life game</li>
                <li>Contests may be entered for free or by paying an entry fee</li>
                <li>Winnings are distributed according to the contest structure</li>
              </ul>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT reserves the right to modify these rules at any time. It is your responsibility to check for updates.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Payment Terms</h2>
              <p className="text-gray-700 dark:text-gray-300">
                To participate in paid contests, you must add funds to your 11byChatGPT wallet. By adding funds, you agree to the following:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>All transactions are final and non-refundable except as expressly provided in these Terms</li>
                <li>All payments are in Indian Rupees (INR)</li>
                <li>You are responsible for all charges, fees, taxes, and other costs related to deposits</li>
                <li>Winnings are subject to verification and may be withheld pending confirmation</li>
                <li>Withdrawals will be processed according to our withdrawal policy and applicable laws</li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Termination</h2>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT reserves the right to suspend or terminate your account and access to the Services at any time, without notice, for conduct that 11byChatGPT believes violates these Terms, or is harmful to other users, 11byChatGPT, third parties, or for any other reason at 11byChatGPT's sole discretion.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT also reserves the right to modify or discontinue, temporarily or permanently, the Services with or without notice. You agree that 11byChatGPT shall not be liable to you or any third party for any modification, suspension, or discontinuance of the Services.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Disclaimer of Warranties</h2>
              <p className="text-gray-700 dark:text-gray-300">
                The Services are provided "as is" and "as available" without warranty of any kind. 11byChatGPT disclaims all warranties, express or implied, including but not limited to the implied warranties of merchantability, fitness for a particular purpose, and non-infringement.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT does not warrant that the Services will be uninterrupted, secure, or error-free, or that defects will be corrected. You acknowledge that your use of the Services is at your sole risk.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Limitation of Liability</h2>
              <p className="text-gray-700 dark:text-gray-300">
                In no event shall 11byChatGPT be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>Your access to or use of or inability to access or use the Services</li>
                <li>Any conduct or content of any third party on the Services</li>
                <li>Any content obtained from the Services</li>
                <li>Unauthorized access, use, or alteration of your transmissions or content</li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Indemnification</h2>
              <p className="text-gray-700 dark:text-gray-300">
                You agree to defend, indemnify, and hold harmless 11byChatGPT and its officers, directors, employees, and agents, from and against any and all claims, damages, obligations, losses, liabilities, costs or debt, and expenses (including but not limited to attorney's fees) arising from:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>Your use of and access to the Services</li>
                <li>Your violation of any term of these Terms</li>
                <li>Your violation of any third-party right, including without limitation any copyright, property, or privacy right</li>
                <li>Any claim that your content caused damage to a third party</li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Governing Law</h2>
              <p className="text-gray-700 dark:text-gray-300">
                These Terms shall be governed by the laws of India, without respect to its conflict of laws principles. Any claim or dispute between you and 11byChatGPT that arises in whole or in part from the Services shall be decided exclusively by a court of competent jurisdiction located in Delhi, India.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Changes to Terms</h2>
              <p className="text-gray-700 dark:text-gray-300">
                11byChatGPT reserves the right, at its sole discretion, to modify or replace these Terms at any time. If a revision is material, 11byChatGPT will provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at 11byChatGPT's sole discretion.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                By continuing to access or use our Services after those revisions become effective, you agree to be bound by the revised terms. If you do not agree to the new terms, please stop using the Services.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Contact Us</h2>
              <p className="text-gray-700 dark:text-gray-300">
                If you have any questions about these Terms, please contact us at support@11bychatgpt.com.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                Last updated: April 11, 2025
              </p>
            </section>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}