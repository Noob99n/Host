import { cn } from "@/lib/utils";

type ProgressBarProps = {
  value: number;
  max: number;
  className?: string;
  fillClassName?: string;
  showLabel?: boolean;
  labelFormatter?: (value: number, max: number) => string;
};

export function ProgressBar({
  value,
  max,
  className,
  fillClassName,
  showLabel = false,
  labelFormatter,
}: ProgressBarProps) {
  const percentage = Math.min(100, Math.max(0, (value / max) * 100));

  return (
    <div className={cn("relative", className)}>
      <div
        className={cn(
          "h-1.5 rounded-sm bg-neutral-300 dark:bg-dark-border overflow-hidden",
          className
        )}
      >
        <div
          className={cn("h-full bg-primary", fillClassName)}
          style={{ width: `${percentage}%` }}
        />
      </div>
      
      {showLabel && (
        <div className="mt-1 text-xs flex justify-between">
          <span>
            {labelFormatter ? labelFormatter(value, max) : `${value} / ${max}`}
          </span>
          <span>{`${Math.round(percentage)}%`}</span>
        </div>
      )}
    </div>
  );
}
