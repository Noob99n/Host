import { useState } from "react";
import { Header } from "@/components/layout/header";
import { NavBar } from "@/components/layout/nav-bar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Medal, Award, Trophy } from "lucide-react";

// Mock leaderboard data - in a real app this would come from the API
const mockLeaderboard = [
  {
    rank: 1,
    name: "Rohit S.",
    points: 2450,
    prize: "₹10,000",
    avatarUrl: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-4.0.3",
  },
  {
    rank: 2,
    name: "Virat K.",
    points: 2120,
    prize: "₹5,000",
    avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3",
  },
  {
    rank: 3,
    name: "M.S. Dhoni",
    points: 1980,
    prize: "₹3,000",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3",
  },
  {
    rank: 4,
    name: "Hardik P.",
    points: 1850,
    prize: "₹1,000",
    avatarUrl: "https://images.unsplash.com/photo-1607746882042-944635dfe10e?ixlib=rb-4.0.3",
  },
  {
    rank: 5,
    name: "Jasprit B.",
    points: 1640,
    prize: "₹500",
    avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3",
  },
  {
    rank: 6,
    name: "K.L. Rahul",
    points: 1540,
    prize: "₹250",
    avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3",
  },
  {
    rank: 7,
    name: "Ravindra J.",
    points: 1480,
    prize: "₹100",
    avatarUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3",
  },
  {
    rank: 8,
    name: "Shikhar D.",
    points: 1230,
    prize: "₹50",
    avatarUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3",
  },
  {
    rank: 9,
    name: "Ravichandran A.",
    points: 1180,
    prize: "-",
    avatarUrl: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-4.0.3",
  },
  {
    rank: 10,
    name: "Rishabh P.",
    points: 1020,
    prize: "-",
    avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3",
  },
];

const currentUserRank = {
  rank: 42,
  name: "You",
  points: 580,
  prize: "-",
  avatarUrl: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-4.0.3",
};

export default function LeaderboardPage() {
  const [period, setPeriod] = useState<"daily" | "weekly" | "all-time">("daily");
  
  // Get top 3 users for the podium display
  const topThree = mockLeaderboard.slice(0, 3);
  
  return (
    <div className="min-h-screen flex flex-col pb-16">
      <Header
        title="Leaderboard"
        showWallet={true}
      />
      
      <Tabs defaultValue="daily" onValueChange={(value) => setPeriod(value as "daily" | "weekly" | "all-time")}>
        <TabsList className="w-full border-b border-neutral-200 dark:border-dark-border rounded-none bg-transparent">
          <TabsTrigger
            value="daily"
            className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
          >
            Daily
          </TabsTrigger>
          <TabsTrigger
            value="weekly"
            className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
          >
            Weekly
          </TabsTrigger>
          <TabsTrigger
            value="all-time"
            className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
          >
            All Time
          </TabsTrigger>
        </TabsList>
        
        <div className="p-4 space-y-6">
          {/* Podium display for top 3 */}
          <div className="flex justify-center items-end mb-8 h-40 pt-4">
            {/* 2nd place */}
            <div className="flex flex-col items-center mx-2">
              <Avatar className="w-14 h-14 mb-2 border-2 border-white shadow-lg">
                <AvatarImage src={topThree[1].avatarUrl} alt={topThree[1].name} />
                <AvatarFallback>{topThree[1].name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="w-20 h-24 bg-gray-100 dark:bg-dark-card rounded-t-lg relative flex flex-col items-center justify-end pb-2">
                <Medal className="h-5 w-5 text-gray-400 absolute top-2" />
                <p className="font-semibold text-sm">{topThree[1].name}</p>
                <p className="text-xs text-neutral-600 dark:text-neutral-400">{topThree[1].points} pts</p>
              </div>
            </div>
            
            {/* 1st place */}
            <div className="flex flex-col items-center mx-2">
              <Avatar className="w-16 h-16 mb-2 border-2 border-white shadow-lg">
                <AvatarImage src={topThree[0].avatarUrl} alt={topThree[0].name} />
                <AvatarFallback>{topThree[0].name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="w-20 h-32 bg-primary bg-opacity-10 dark:bg-primary dark:bg-opacity-20 rounded-t-lg relative flex flex-col items-center justify-end pb-2">
                <Trophy className="h-6 w-6 text-primary absolute top-2" />
                <p className="font-semibold text-sm">{topThree[0].name}</p>
                <p className="text-xs text-neutral-600 dark:text-neutral-400">{topThree[0].points} pts</p>
              </div>
            </div>
            
            {/* 3rd place */}
            <div className="flex flex-col items-center mx-2">
              <Avatar className="w-14 h-14 mb-2 border-2 border-white shadow-lg">
                <AvatarImage src={topThree[2].avatarUrl} alt={topThree[2].name} />
                <AvatarFallback>{topThree[2].name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="w-20 h-20 bg-amber-50 dark:bg-dark-card rounded-t-lg relative flex flex-col items-center justify-end pb-2">
                <Award className="h-5 w-5 text-amber-600 absolute top-2" />
                <p className="font-semibold text-sm">{topThree[2].name}</p>
                <p className="text-xs text-neutral-600 dark:text-neutral-400">{topThree[2].points} pts</p>
              </div>
            </div>
          </div>
          
          {/* Current user's rank */}
          <Card className="bg-primary text-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-primary font-bold text-sm mr-3">
                    {currentUserRank.rank}
                  </div>
                  <div className="flex items-center">
                    <Avatar className="w-8 h-8 mr-2">
                      <AvatarImage src={currentUserRank.avatarUrl} alt={currentUserRank.name} />
                      <AvatarFallback>YOU</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{currentUserRank.name}</p>
                      <p className="text-xs text-white text-opacity-80">{currentUserRank.points} pts</p>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs text-white text-opacity-80">Prize</p>
                  <p className="font-semibold">{currentUserRank.prize}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Full leaderboard list */}
          <Card>
            <CardHeader className="px-4 py-3 border-b">
              <div className="flex justify-between items-center">
                <CardTitle className="text-base font-medium">Leaderboard</CardTitle>
                <div className="text-xs text-neutral-600 dark:text-neutral-400">
                  {period === "daily" && "Today's Rankings"}
                  {period === "weekly" && "This Week's Rankings"}
                  {period === "all-time" && "All Time Rankings"}
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-neutral-200 dark:divide-dark-border">
                {mockLeaderboard.map((user) => (
                  <div key={user.rank} className="flex items-center justify-between p-4">
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-neutral-100 dark:bg-dark-bg flex items-center justify-center text-neutral-800 dark:text-neutral-200 font-semibold text-xs mr-3">
                        {user.rank}
                      </div>
                      <div className="flex items-center">
                        <Avatar className="w-8 h-8 mr-2">
                          <AvatarImage src={user.avatarUrl} alt={user.name} />
                          <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{user.name}</p>
                          <p className="text-xs text-neutral-600 dark:text-neutral-400">{user.points} pts</p>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-neutral-500">Prize</p>
                      <p className="font-medium text-sm">{user.prize}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </Tabs>
      
      <NavBar />
    </div>
  );
}
