import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import HomePage from "@/pages/home-page";
import MatchDetailPage from "@/pages/match-detail-page";
import CreateTeamPage from "@/pages/create-team-page";
import WalletPage from "@/pages/wallet-page";
import ReferPage from "@/pages/refer-page";
import MatchesPage from "@/pages/matches-page";
import MyTeamsPage from "@/pages/my-teams-page";
import LeaderboardPage from "@/pages/leaderboard-page";
import ProfilePage from "@/pages/profile-page";
import NotificationsPage from "@/pages/notifications-page";
import MorePage from "@/pages/more-page";
import VerifyAccountPage from "@/pages/verify-account-page";
import DownloadTDSPage from "@/pages/download-tds-page";
import FantasyPointsPage from "@/pages/fantasy-points-page";
import PrivacyPolicyPage from "@/pages/privacy-policy-page";
import TermsAndConditionsPage from "@/pages/terms-and-conditions-page";
import LegalityPage from "@/pages/legality-page";
import AboutUsPage from "@/pages/about-us-page";
import HowToPlayPage from "@/pages/how-to-play-page";
import HelpCenterPage from "@/pages/help-center-page";
import ResponsiblePlayPage from "@/pages/responsible-play-page";
import ContactUsPage from "@/pages/contact-us-page";
import PromoterAppPage from "@/pages/promoter-app-page";
import PreferencesPage from "@/pages/preferences-page";
import { ProtectedRoute } from "./lib/protected-route";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";

// Basic route without auth protection
const BasicRoute = ({
  path,
  component: Component,
}: {
  path: string;
  component: () => React.JSX.Element;
}) => <Route path={path} component={Component} />;

// Note: We're now using the imported ProtectedRoute from './lib/protected-route'

function Router() {
  return (
    <Switch>
      {/* User routes */}
      <BasicRoute path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={HomePage} />
      <ProtectedRoute path="/matches" component={MatchesPage} />
      <ProtectedRoute path="/matches/:id" component={MatchDetailPage} />
      <ProtectedRoute path="/create-team/:matchId" component={CreateTeamPage} />
      <ProtectedRoute path="/my-teams" component={MyTeamsPage} />
      <ProtectedRoute path="/leaderboard" component={LeaderboardPage} />
      <ProtectedRoute path="/wallet" component={WalletPage} />
      <ProtectedRoute path="/refer" component={ReferPage} />
      <ProtectedRoute path="/profile" component={ProfilePage} />
      <ProtectedRoute path="/notifications" component={NotificationsPage} />
      <ProtectedRoute path="/more" component={MorePage} />
      <ProtectedRoute path="/preferences" component={PreferencesPage} />
      <ProtectedRoute path="/verify-account" component={VerifyAccountPage} />
      <ProtectedRoute path="/download-tds" component={DownloadTDSPage} />
      <ProtectedRoute path="/fantasy-points" component={FantasyPointsPage} />
      <BasicRoute path="/privacy-policy" component={PrivacyPolicyPage} />
      <BasicRoute path="/terms-and-conditions" component={TermsAndConditionsPage} />
      <BasicRoute path="/legality" component={LegalityPage} />
      <BasicRoute path="/about-us" component={AboutUsPage} />
      <BasicRoute path="/how-to-play" component={HowToPlayPage} />
      <BasicRoute path="/help-center" component={HelpCenterPage} />
      <BasicRoute path="/responsible-play" component={ResponsiblePlayPage} />
      <BasicRoute path="/contact-us" component={ContactUsPage} />
      <ProtectedRoute path="/promoter-app" component={PromoterAppPage} />
      <BasicRoute path="*" component={NotFound} />
    </Switch>
  );
}

// Component to handle router with auth
import { AuthProvider } from "./hooks/use-auth";

const AppRoutes = () => {
  console.log("AppRoutes: Rendering routes with auth context");
  
  return (
    <AuthProvider>
      <Router />
    </AuthProvider>
  );
};

function App() {
  console.log("App: Rendering main application layout");
  
  // State to keep track of the theme and error handling
  const [currentTheme, setCurrentTheme] = useState<'light' | 'dark' | 'system'>('system');
  
  // Add global error handler to prevent overlay errors
  useEffect(() => {
    const originalConsoleError = console.error;
    
    // Override console.error to intercept Vite HMR errors
    console.error = function(...args) {
      // Filter out certain HMR and WebSocket errors
      const errorText = args.join(' ');
      if (
        errorText.includes('[vite]') || 
        errorText.includes('WebSocket') || 
        errorText.includes('aborted')
      ) {
        // Still log to console but without triggering the overlay
        console.log('Suppressed error:', ...args);
        return;
      }
      
      // Call original for other errors
      originalConsoleError.apply(console, args);
    };
    
    // Restore original on cleanup
    return () => {
      console.error = originalConsoleError;
    };
  }, []);
  
  // Query user preferences for theme
  const { data: preferences } = useQuery<any>({
    queryKey: ['/api/user-preferences'],
    enabled: true, // Always try to fetch, will return unauthorized for non-logged in users
    retry: false,
    staleTime: 60 * 1000, // 1 minute
  });
  
  // Handle error case
  useEffect(() => {
    if (!preferences) {
      applyTheme('system');
    }
  }, []);
  
  // Apply theme function with improved error handling
  const applyTheme = (theme: 'light' | 'dark' | 'system') => {
    try {
      setCurrentTheme(theme);
      
      if (theme === 'system') {
        const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        document.documentElement.classList.toggle('dark', systemTheme === 'dark');
      } else {
        document.documentElement.classList.toggle('dark', theme === 'dark');
      }
    } catch (error) {
      console.log('Theme application error:', error);
      // Fallback to light theme if there's an error
      document.documentElement.classList.remove('dark');
    }
  };
  
  // Apply theme from preferences
  useEffect(() => {
    if (preferences?.theme) {
      applyTheme(preferences.theme as 'light' | 'dark' | 'system');
    }
  }, [preferences]);
  
  // Listen for system theme changes
  useEffect(() => {
    if (currentTheme === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      
      const handleChange = (e: MediaQueryListEvent) => {
        document.documentElement.classList.toggle('dark', e.matches);
      };
      
      mediaQuery.addEventListener('change', handleChange);
      
      return () => {
        mediaQuery.removeEventListener('change', handleChange);
      };
    }
  }, [currentTheme]);
  
  // Periodic cache clearing to improve performance with better error handling
  useEffect(() => {
    // Function to clear the cache
    const clearAppCache = () => {
      try {
        // Clear React Query cache except for essential queries
        const queryCache = queryClient.getQueryCache();
        queryCache.getAll().forEach(query => {
          // Don't clear user data, preferences or verification status
          if (
            !query.queryKey.includes('/api/user-preferences') && 
            !query.queryKey.includes('/api/verify/status') &&
            !query.queryKey.includes('/api/user') &&
            !String(query.queryKey).includes('notification')
          ) {
            queryClient.removeQueries({ queryKey: query.queryKey });
          }
        });
        
        // Clear localStorage cache except essential items
        Object.keys(localStorage).forEach(key => {
          // Skip clearing certain essential items
          if (
            !key.includes('essential') && 
            !key.includes('verification-status') && 
            !key.includes('user-preferences') &&
            !key.includes('auth')
          ) {
            localStorage.removeItem(key);
          }
        });
        
        // Clear sessionStorage except for auth and preferences
        Object.keys(sessionStorage).forEach(key => {
          if (
            !key.includes('auth') && 
            !key.includes('preferences') && 
            !key.includes('user')
          ) {
            sessionStorage.removeItem(key);
          }
        });
        
        // Clear browser cache for fetch requests more safely
        if ('caches' in window) {
          caches.keys().then((names) => {
            names.forEach(name => {
              // Don't clear critical cache items
              if (!name.includes('critical') && !name.includes('user-data')) {
                caches.delete(name);
              }
            });
          });
        }
        
        console.log('App cache cleared for better performance');
      } catch (error) {
        console.log('Cache clearing error:', error);
      }
    };
    
    // Run the cache clearing every 5 minutes instead of every minute
    const cacheInterval = setInterval(clearAppCache, 300000); // 300000ms = 5 minutes
    
    // Clear on initial load
    clearAppCache();
    
    // Clear the interval on component unmount
    return () => clearInterval(cacheInterval);
  }, []);
  
  return (
    <div className="page-container transition-page shadow-xl mx-auto overflow-hidden relative">
      <AppRoutes />
      <Toaster />
    </div>
  );
}

export default App;
