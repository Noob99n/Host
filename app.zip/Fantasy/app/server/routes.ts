import express, { type Express, type Request, type Response, type NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, hashPassword } from "./auth";
import { z } from "zod";
import { db } from "./db";
import * as schema from "@shared/schema";
import { eq, count, desc, asc, and } from "drizzle-orm";

// Import needed modules for file operations
import * as fs from 'fs';
import * as path from 'path';

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Middleware to ensure user is an owner
  const ensureOwner = (req: Request, res: Response, next: NextFunction) => {
    if (req.isAuthenticated() && req.session.isOwner) {
      return next();
    }
    res.status(401).json({ message: 'Unauthorized' });
  };
  // Serve static files from owner-control folder
  app.use('/owner', express.static(path.join(process.cwd(), 'owner-control')));
  
  // Serve static files from attached_assets folder
  app.get('/attached_assets/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(process.cwd(), 'attached_assets', filename);
    
    console.log(`Serving file from: ${filePath}`);
    
    // Check if file exists
    if (fs.existsSync(filePath)) {
      // Set appropriate content type based on file extension
      const ext = path.extname(filename).toLowerCase();
      if (ext === '.jpg' || ext === '.jpeg') {
        res.setHeader('Content-Type', 'image/jpeg');
      } else if (ext === '.png') {
        res.setHeader('Content-Type', 'image/png');
      }
      
      // Send the file with proper content type
      res.sendFile(filePath);
    } else {
      console.log(`File not found: ${filePath}`);
      res.status(404).send('File not found');
    }
  });
  // Setup authentication routes
  setupAuth(app);
  
  // API routes - all prefixed with /api
  
  // For phone verification before password reset
  app.post("/api/verify-phone", async (req, res) => {
    try {
      const schema = z.object({
        phone: z.string().regex(/^[6-9]\d{9}$/, "Invalid Indian phone number"),
      });
      
      const { phone } = schema.parse(req.body);
      
      // Find user by phone
      const user = await storage.getUserByPhone(phone);
      
      if (!user) {
        return res.status(404).json({ message: "No account found with this phone number" });
      }
      
      // Phone exists in the system
      res.status(200).json({ message: "Phone number verified successfully" });
    } catch (error) {
      res.status(400).json({ message: "Invalid phone number format" });
    }
  });

  // Password reset routes (without OTP verification)
  app.post("/api/reset-password", async (req, res) => {
    try {
      const schema = z.object({
        phone: z.string().regex(/^[6-9]\d{9}$/, "Invalid Indian phone number"),
        otp: z.string(), // Keeping this field for compatibility but we don't verify it
        newPassword: z.string().min(6, "Password must be at least 6 characters")
      });
      
      const { phone, newPassword } = schema.parse(req.body);
      
      // Find user by phone
      const user = await storage.getUserByPhone(phone);
      
      if (!user) {
        return res.status(404).json({ message: "No account found with this phone number" });
      }
      
      // Hash password before updating
      const hashedPassword = await hashPassword(newPassword);
      
      // Update password in database
      await storage.updateUserPassword(user.id, hashedPassword);
      
      res.status(200).json({ message: "Password reset successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to reset password" });
    }
  });
  
  // Matches routes
  app.get("/api/matches", async (req, res) => {
    try {
      const matches = await storage.getMatches();
      res.json(matches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch matches" });
    }
  });
  
  app.get("/api/matches/:id", async (req, res) => {
    try {
      const matchId = parseInt(req.params.id);
      const match = await storage.getMatch(matchId);
      
      if (!match) {
        return res.status(404).json({ message: "Match not found" });
      }
      
      res.json(match);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch match" });
    }
  });
  
  // Contests routes
  app.get("/api/matches/:matchId/contests", async (req, res) => {
    try {
      const matchId = parseInt(req.params.matchId);
      const contests = await storage.getContests(matchId);
      res.json(contests);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch contests" });
    }
  });
  
  app.get("/api/contests/:id", async (req, res) => {
    try {
      const contestId = parseInt(req.params.id);
      const contest = await storage.getContest(contestId);
      
      if (!contest) {
        return res.status(404).json({ message: "Contest not found" });
      }
      
      res.json(contest);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch contest" });
    }
  });
  
  // Players routes
  app.get("/api/matches/:matchId/players", async (req, res) => {
    try {
      const matchId = parseInt(req.params.matchId);
      const team = req.query.team as string;
      const role = req.query.role as string;
      
      let players;
      if (team && role) {
        players = await storage.getPlayersByTeamAndRole(matchId, team, role);
      } else {
        players = await storage.getPlayers(matchId);
      }
      
      res.json(players);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch players" });
    }
  });
  
  // Teams routes
  app.get("/api/teams", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const teams = await storage.getTeams(req.user.id);
      res.json(teams);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch teams" });
    }
  });
  
  app.get("/api/matches/:matchId/teams", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const matchId = parseInt(req.params.matchId);
      const teams = await storage.getTeamsByMatch(req.user.id, matchId);
      res.json(teams);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch teams" });
    }
  });
  
  app.post("/api/teams", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const teamData = { ...req.body, userId: req.user.id };
      const team = await storage.createTeam(teamData);
      res.status(201).json(team);
    } catch (error) {
      res.status(500).json({ message: "Failed to create team" });
    }
  });
  
  // Notifications routes
  app.get("/api/notifications", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // In a real app, fetch notifications from database
      // For now, we'll return mock data
      const notifications = [
        {
          id: 1,
          type: "contest",
          title: "Contest reminder",
          message: "IND vs AUS match starts in 1 hour. Don't forget to join contests!",
          date: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
          read: false,
        },
        {
          id: 2,
          type: "wallet",
          title: "Money added successfully",
          message: "₹500 has been added to your wallet successfully.",
          date: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
          read: false,
        }
      ];
      
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });
  
  app.get("/api/get-notification-count", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        // Return 0 for unauthenticated users
        return res.json({ count: 0 });
      }
      
      // In a real app, count unread notifications from database
      // For now, return a fixed count
      res.json({ count: 2 });
    } catch (error) {
      res.status(500).json({ message: "Failed to get notification count" });
    }
  });
  
  // User Preferences routes
  app.get("/api/user-preferences", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Get user preferences or return default values if none exist
      let preferences = await storage.getUserPreferences(req.user.id);
      
      if (!preferences) {
        // If no preferences exist, create default ones
        preferences = await storage.createUserPreferences({
          userId: req.user.id,
          theme: "system",
          language: "en",
          notificationsEnabled: true,
          matchNotifications: true,
          transactionNotifications: true,
          promotionalNotifications: true,
          contentPreferences: "{}",
          defaultView: "matches"
        });
      }
      
      res.json(preferences);
    } catch (error) {
      console.error('Error fetching user preferences:', error);
      res.status(500).json({ message: "Failed to fetch user preferences" });
    }
  });
  
  app.post("/api/user-preferences", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Validate input data with Zod
      const schema = z.object({
        theme: z.enum(["light", "dark", "system"]).optional(),
        language: z.string().optional(),
        notificationsEnabled: z.boolean().optional(),
        matchNotifications: z.boolean().optional(),
        transactionNotifications: z.boolean().optional(),
        promotionalNotifications: z.boolean().optional(),
        contentPreferences: z.string().optional(),
        defaultView: z.string().optional(),
      });
      
      const validatedData = schema.parse(req.body);
      
      // Update preferences
      const updatedPreferences = await storage.updateUserPreferences(req.user.id, validatedData);
      
      res.json(updatedPreferences);
    } catch (error) {
      console.error('Error updating user preferences:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Invalid preferences data",
          errors: error.errors.map(e => `${e.path}: ${e.message}`).join(', ')
        });
      }
      
      res.status(500).json({ message: "Failed to update user preferences" });
    }
  });
  
  // Wallet routes
  app.get("/api/wallet/transactions", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const transactions = await storage.getTransactions(req.user.id);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });
  
  app.post("/api/wallet/deposit", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const schema = z.object({
        amount: z.number().int().positive(),
        paymentMethod: z.string()
      });
      
      const { amount, paymentMethod } = schema.parse(req.body);
      
      // Update user balance
      const user = await storage.updateUserBalance(req.user.id, amount);
      
      // Create transaction record
      const transaction = await storage.createTransaction({
        userId: req.user.id,
        type: 'credit',
        amount: amount,
        status: 'completed',
        description: 'Money Added'
      });
      
      res.status(201).json({ user, transaction });
    } catch (error) {
      console.error('Error processing deposit:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Invalid deposit data",
          errors: error.errors.map(e => `${e.path}: ${e.message}`).join(', ')
        });
      }
      res.status(500).json({ message: "Failed to process deposit" });
    }
  });
  
  app.post("/api/wallet/verify-deposit", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // In a real implementation, you would:
      // 1. Upload the screenshot to a storage service
      // 2. Create a pending deposit request record
      
      // Validate the request data with Zod schema
      const schema = z.object({
        amount: z.number().int().positive("Amount must be a positive number"),
        transactionId: z.string().min(1, "Transaction ID is required")
      });
      
      // Parse and validate the input
      const { amount, transactionId } = schema.parse(req.body);
      
      // Create a pending transaction
      const transaction = await storage.createTransaction({
        userId: req.user.id,
        type: 'credit',
        amount: amount,
        status: 'pending',
        description: `Deposit verification - Transaction ID: ${transactionId}`
      });
      
      res.status(201).json({ 
        message: "Deposit verification submitted successfully",
        transaction 
      });
    } catch (error) {
      console.error('Error verifying deposit:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Invalid deposit data",
          errors: error.errors.map(e => `${e.path}: ${e.message}`).join(', ')
        });
      }
      
      res.status(500).json({ message: "Failed to verify deposit" });
    }
  });
  
  app.post("/api/wallet/withdraw", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const schema = z.object({
        amount: z.number().int().positive(),
        withdrawMethod: z.string()
      });
      
      const { amount, withdrawMethod } = schema.parse(req.body);
      
      // Check if user has enough winnings to withdraw
      if ((req.user.winnings || 0) < amount) {
        return res.status(400).json({ message: "Insufficient winnings balance" });
      }
      
      // Get user's relevant verification data based on withdrawal method
      const verifications = await storage.getVerifications(req.user.id);
      const panVerification = verifications.find(v => v.type === "pan" && v.status === "approved");
      
      // Check if PAN is verified (required for all withdrawals)
      if (!panVerification) {
        return res.status(400).json({ 
          message: "PAN card verification required for withdrawals. Please verify your PAN card first."
        });
      }
      
      // Check if the selected withdrawal method is verified
      const methodVerification = withdrawMethod === "upi" 
        ? verifications.find(v => v.type === "upi" && v.status === "approved")
        : verifications.find(v => v.type === "bank" && v.status === "approved");
      
      if (!methodVerification) {
        return res.status(400).json({ 
          message: `Your ${withdrawMethod === "upi" ? "UPI" : "Bank Account"} is not verified. Please verify it first.`
        });
      }
      
      // Remove second check as it's redundant
      
      // Process withdrawal from winnings, not from main balance
      const user = await storage.processWithdrawal(req.user.id, amount);
      
      // Create transaction record (without metadata as that column doesn't exist in the DB)
      const transaction = await storage.createTransaction({
        userId: req.user.id,
        type: 'debit',
        amount: amount,
        status: 'pending', // Set to pending until approved by admin
        description: `Withdrawal to ${withdrawMethod === "upi" ? "UPI" : "Bank Account"} (${withdrawMethod === "upi" ? 
          (methodVerification.data as any).upiId : 
          (methodVerification.data as any).accountNumber})`
      });
      
      res.status(201).json({ user, transaction });
    } catch (error) {
      console.error('Error processing withdrawal:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Invalid withdrawal data",
          errors: error.errors.map(e => `${e.path}: ${e.message}`).join(', ')
        });
      }
      
      res.status(500).json({ message: "Failed to process withdrawal" });
    }
  });

  // Verification routes
  app.post("/api/verify/submit", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Validate input data
      const schema = z.object({
        type: z.enum(["pan", "upi", "bank"]),
        data: z.record(z.any()), // Allow any type of data (string, date, etc.)
        documentUrl: z.string().optional()
      });
      
      const { type, data, documentUrl } = schema.parse(req.body);
      
      // Get all verifications and sort by newest first
      const allVerifications = await storage.getVerifications(req.user.id);
      
      // Filter verifications by type and sort by newest first
      const typeVerifications = allVerifications
        .filter(v => v.type === type)
        .sort((a, b) => {
          const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          return dateB - dateA;
        });
      
      const latestVerification = typeVerifications.length > 0 ? typeVerifications[0] : undefined;
      
      // PAN can't be resubmitted if approved
      if (type === "pan" && latestVerification?.status === "approved") {
        return res.status(403).json({
          message: "Your PAN is already verified and cannot be changed."
        });
      }
      
      // Any type can't be resubmitted while pending
      if (latestVerification?.status === "pending") {
        return res.status(403).json({
          message: `Your ${type.toUpperCase()} verification is pending. Please wait for approval.`
        });
      }
      
      // If previously rejected, you can submit a new verification
      console.log(`Creating new verification for user ${req.user.id}, type: ${type}`);
      
      // Create verification request
      const verification = await storage.createVerification({
        userId: req.user.id,
        type,
        status: "pending",
        data,
        documentUrl
      });
      
      res.status(201).json({ 
        message: "Verification submitted successfully",
        verification
      });
    } catch (error) {
      console.error('Error submitting verification:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Invalid verification data",
          errors: error.errors.map(e => `${e.path}: ${e.message}`).join(', ')
        });
      }
      
      res.status(500).json({ message: "Failed to submit verification" });
    }
  });
  
  // Update user profile
  app.post("/api/update-profile", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const { fullName, photoUrl } = req.body;
      
      // Input validation for fullName
      if (!fullName || fullName.length < 2) {
        return res.status(400).json({ message: "Full name must be at least 2 characters" });
      }
      
      // Check if image is too large and reject immediately if so
      if (photoUrl && photoUrl.length > 500000) { // 500KB limit
        return res.status(413).json({ 
          message: "Profile image is too large. Please upload a smaller image." 
        });
      }
      
      console.log(`Updating profile for user ${req.user.id}`);
      console.log(`Full name: ${fullName}`);
      console.log(`Photo URL provided: ${photoUrl ? 'Yes' : 'No'}`);
      if (photoUrl) {
        console.log(`Photo URL length: ${photoUrl.length} characters`);
      }
      
      try {
        // Update user profile through storage layer
        // The storage layer handles mapping between column names and property names
        const updatedUser = await storage.updateUserProfile(req.user.id, { 
          fullName, 
          photoUrl 
        });
        
        // For debugging
        console.log(`Profile updated successfully for user ${updatedUser.id}`);
        console.log(`Updated user has photoUrl:`, updatedUser.photoUrl ? 'Yes' : 'No');
        
        // Simply update the user in the session without regenerating
        // This ensures the updated user data is immediately available in req.user
        // without destroying the session
        req.user = updatedUser;
        console.log('User updated in session');
        
        // Return the already-mapped user object
        res.status(200).json(updatedUser);
      } catch (error) {
        console.error('Error in storage.updateUserProfile:', error);
        return res.status(500).json({ 
          message: "Failed to update profile. Database error occurred." 
        });
      }
    } catch (error) {
      console.error("Failed to update profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.get("/api/verify/status", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Get all verifications for the user
      const verifications = await storage.getVerifications(req.user.id);
      
      if (!verifications || verifications.length === 0) {
        // Return empty status object if no verifications exist
        return res.json({
          pan: null,
          upi: null,
          bank: null
        });
      }
      
      // Group by type and get the latest verification for each type
      const panVerifications = verifications
        .filter(v => v.type === "pan")
        .sort((a, b) => {
          const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          return dateB - dateA;
        });
      
      const upiVerifications = verifications
        .filter(v => v.type === "upi")
        .sort((a, b) => {
          const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          return dateB - dateA;
        });
      
      const bankVerifications = verifications
        .filter(v => v.type === "bank")
        .sort((a, b) => {
          const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          return dateB - dateA;
        });
      
      // Create the response object with the latest verification for each type
      const statuses = {
        pan: panVerifications.length > 0 ? panVerifications[0] : null,
        upi: upiVerifications.length > 0 ? upiVerifications[0] : null,
        bank: bankVerifications.length > 0 ? bankVerifications[0] : null
      };
      
      res.json(statuses);
    } catch (error) {
      console.error('Error fetching verification status:', error);
      res.status(500).json({ message: "Failed to fetch verification status" });
    }
  });
  
  // Owner Control Panel API Routes
  const OWNER_USERNAME = "owner";
  const OWNER_PASSWORD = "owner1234"; // In a real app, use a strong, hashed password
  
  // Middleware to check if owner is authenticated
  const isOwnerAuthenticated = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (req.session && (req.session as any).isOwner) {
      return next();
    }
    return res.status(401).json({ message: "Not authenticated as owner" });
  };
  
  // Owner login route
  app.post("/api/owner/login", (req, res) => {
    try {
      const { username, password } = req.body;
      
      // For debugging
      console.log("Owner login attempt:", { username, password });
      
      if (username === OWNER_USERNAME && password === OWNER_PASSWORD) {
        // Set the owner session flag
        (req.session as any).isOwner = true;
        // Save the session explicitly before returning
        req.session.save(err => {
          if (err) {
            console.error("Session save error:", err);
            return res.status(500).json({ message: "Session save failed" });
          }
          
          console.log("Owner login successful, session saved");
          return res.status(200).json({ success: true });
        });
      } else {
        res.status(401).json({ message: "Invalid owner credentials" });
      }
    } catch (error) {
      console.error("Owner login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });
  
  // Check owner authentication status
  app.get("/api/owner/check-auth", (req, res) => {
    // For debugging
    console.log("Session content:", req.session);
    
    if (req.session && (req.session as any).isOwner) {
      return res.status(200).json({ authenticated: true });
    }
    res.status(401).json({ authenticated: false });
  });
  
  // Owner logout route
  app.post("/api/owner/logout", (req, res) => {
    try {
      // Clear the owner session flag
      if (req.session) {
        (req.session as any).isOwner = false;
        req.session.destroy((err) => {
          if (err) {
            console.error("Session destroy error:", err);
            return res.status(500).json({ message: "Logout failed" });
          }
          console.log("Owner logged out successfully");
          res.status(200).json({ success: true });
        });
      } else {
        res.status(200).json({ success: true });
      }
    } catch (error) {
      console.error("Owner logout error:", error);
      res.status(500).json({ message: "Logout failed" });
    }
  });
  
  // Get dashboard stats
  app.get("/api/owner/dashboard-stats", isOwnerAuthenticated, async (req, res) => {
    try {
      // Calculate stats from database
      const usersResult = await db.select({ count: count() }).from(schema.users);
      const totalUsers = usersResult[0]?.count || 0;
      
      // Get deposit and withdrawal counts, only counting completed ones for totals
      const completedDeposits = await db.select()
        .from(schema.transactions)
        .where(and(
          eq(schema.transactions.type, 'credit'),
          eq(schema.transactions.status, 'completed')
        ));
      
      const deposits = await db.select()
        .from(schema.transactions)
        .where(eq(schema.transactions.type, 'credit'));
      
      const withdrawals = await db.select()
        .from(schema.transactions)
        .where(eq(schema.transactions.type, 'debit'));
      
      // Calculate total amounts - only count completed deposits for total
      const totalDeposits = completedDeposits.reduce((sum, t) => sum + t.amount, 0);
      const totalWithdrawals = withdrawals.reduce((sum, t) => sum + t.amount, 0);
      
      // Get pending transactions count
      const pendingTransactions = await db.select()
        .from(schema.transactions)
        .where(eq(schema.transactions.status, 'pending'));
      
      // Get recent transactions
      const recentTransactions = await db.select()
        .from(schema.transactions)
        .orderBy(desc(schema.transactions.createdAt))
        .limit(5);
        
      // Get latest users
      const latestUsers = await db.select()
        .from(schema.users)
        .orderBy(desc(schema.users.createdAt))
        .limit(5);
        
      // Remove sensitive data from users
      const safeLatestUsers = latestUsers.map(user => ({
        ...user,
        password: undefined
      }));
      
      const stats = {
        totalUsers,
        totalDeposits,
        totalWithdrawals,
        pendingRequests: pendingTransactions.length,
        recentTransactions,
        latestUsers: safeLatestUsers
      };
      
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });
  
  // Get all users with detailed information
  app.get("/api/owner/users", isOwnerAuthenticated, async (req, res) => {
    try {
      // Fetch all users from database
      const users = await db.select().from(schema.users);
      
      // Get all user details including transactions, verifications, etc.
      const usersWithDetails = await Promise.all(users.map(async (user) => {
        // Get user's transactions
        const transactions = await db.select()
          .from(schema.transactions)
          .where(eq(schema.transactions.userId, user.id));
        
        // Get user's verifications
        const verifications = await db.select()
          .from(schema.verifications)
          .where(eq(schema.verifications.userId, user.id));
        
        // Calculate totals
        const deposits = transactions
          .filter(t => t.type === 'credit' && t.status === 'completed')
          .reduce((sum, t) => sum + t.amount, 0);
        
        const completedWithdrawals = transactions
          .filter(t => t.type === 'debit' && t.status === 'completed')
          .reduce((sum, t) => sum + t.amount, 0);
          
        const pendingWithdrawals = transactions
          .filter(t => t.type === 'debit' && t.status === 'pending')
          .reduce((sum, t) => sum + t.amount, 0);
        
        const withdrawals = completedWithdrawals + pendingWithdrawals;
          
        // Get verification statuses
        const panVerification = verifications.find(v => v.type === 'pan');
        const upiVerification = verifications.find(v => v.type === 'upi');
        const bankVerification = verifications.find(v => v.type === 'bank');
        
        // Return user with additional details
        return {
          id: user.id,
          username: user.username,
          name: user.fullName || "",
          email: user.email || "",
          phone: user.phone || "",
          referralCode: user.referralCode || "",
          createdAt: user.createdAt,
          stats: {
            totalDeposits: deposits,
            totalWithdrawals: withdrawals,
            winningsBalance: user.winnings || 0,
            depositedBalance: user.balance || 0,
            bonusBalance: user.bonus || 0,
          },
          verification: {
            pan: panVerification ? panVerification.status : 'not_submitted',
            upi: upiVerification ? upiVerification.status : 'not_submitted',
            bank: bankVerification ? bankVerification.status : 'not_submitted',
          },
          transactionCount: transactions.length,
        };
      }));
      
      res.json(usersWithDetails);
    } catch (error) {
      console.error("Failed to fetch detailed users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  // Get specific user details
  // Add an endpoint to fetch user's verifications
  app.get("/api/owner/users/:id/verifications", isOwnerAuthenticated, async (req, res) => {
    try {
      console.log(`[OWNER-API] Getting verifications for user ${req.params.id}`);
      const userId = parseInt(req.params.id);
      
      if (!userId || isNaN(userId)) {
        console.error(`[OWNER-API] Invalid user ID: ${req.params.id}`);
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const verifications = await storage.getVerifications(userId);
      console.log(`[OWNER-API] Retrieved ${verifications.length} verifications for user ${userId}`);
      
      res.json(verifications);
    } catch (error) {
      console.error(`[OWNER-API] Failed to get verifications for user ${req.params.id}:`, error);
      res.status(500).json({ message: 'Failed to fetch user verifications' });
    }
  });

  app.get("/api/owner/users/:id", isOwnerAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id, 10);
      
      // Get user
      const [user] = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.id, userId));
        
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get transactions
      const transactions = await db
        .select()
        .from(schema.transactions)
        .where(eq(schema.transactions.userId, userId))
        .orderBy(desc(schema.transactions.createdAt));
      
      // Get verifications
      const verifications = await db
        .select()
        .from(schema.verifications)
        .where(eq(schema.verifications.userId, userId))
        .orderBy(desc(schema.verifications.createdAt));
      
      // Calculate balances for user display
      const deposits = transactions
        .filter(t => t.type === 'credit' && t.status === 'completed')
        .reduce((sum, t) => sum + t.amount, 0);
      
      const withdrawals = transactions
        .filter(t => t.type === 'debit')
        .reduce((sum, t) => sum + t.amount, 0);
      
      // Get verification statuses
      const panVerification = verifications.find(v => v.type === 'pan');
      const upiVerification = verifications.find(v => v.type === 'upi');
      const bankVerification = verifications.find(v => v.type === 'bank');
      
      const userDetails = {
        id: user.id,
        username: user.username,
        name: user.fullName || "",
        email: user.email || "",
        phone: user.phone || "",
        referralCode: user.referralCode || "",
        createdAt: user.createdAt,
        stats: {
          totalDeposits: deposits,
          totalWithdrawals: withdrawals,
          winningsBalance: user.winnings || 0,
          depositedBalance: user.balance || 0,
          bonusBalance: user.bonus || 0,
        },
        verification: {
          pan: panVerification ? panVerification.status : 'not_submitted',
          upi: upiVerification ? upiVerification.status : 'not_submitted',
          bank: bankVerification ? bankVerification.status : 'not_submitted',
        },
        transactions,
        verifications
      };
      
      res.json(userDetails);
    } catch (error) {
      console.error("Error fetching user details:", error);
      res.status(500).json({ message: "Failed to fetch user details" });
    }
  });
  
  // Update user information
  app.patch("/api/owner/users/:id", isOwnerAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id, 10);
      const { username, fullName, email, phone, balance, winningsBalance, bonusBalance } = req.body;
      
      // Build update object with only provided fields
      const updateData: any = {};
      if (username !== undefined) updateData.username = username;
      if (fullName !== undefined) updateData.fullName = fullName;
      if (email !== undefined) updateData.email = email;
      if (phone !== undefined) updateData.phone = phone;
      if (balance !== undefined) updateData.balance = balance;
      if (winningsBalance !== undefined) updateData.winnings = winningsBalance; // Map to correct DB column
      if (bonusBalance !== undefined) updateData.bonus = bonusBalance; // Map to correct DB column
      
      // Update user
      const [updatedUser] = await db
        .update(schema.users)
        .set(updateData)
        .where(eq(schema.users.id, userId))
        .returning();
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Return updated user without password
      const { password, ...safeUser } = updatedUser;
      res.json(safeUser);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });
  
  // Get all verifications
  app.get("/api/owner/verifications", isOwnerAuthenticated, async (req, res) => {
    try {
      const { status = 'pending', type = 'all' } = req.query;
      
      // Base query
      let query = db.select()
        .from(schema.verifications);
      
      // Add status filter if provided
      if (status && status !== 'all') {
        query = query.where(eq(schema.verifications.status, status.toString()));
      }
      
      // Add type filter if provided
      if (type && type !== 'all') {
        query = query.where(eq(schema.verifications.type, type.toString()));
      }
      
      // Execute query and sort by newest first
      const verifications = await query.orderBy(desc(schema.verifications.createdAt));
      
      // Join with user information for better context
      const verificationsWithUserInfo = await Promise.all(
        verifications.map(async (verification) => {
          // Get user info
          const [user] = await db.select()
            .from(schema.users)
            .where(eq(schema.users.id, verification.userId));
            
          return {
            ...verification,
            user: user ? {
              id: user.id,
              username: user.username,
              fullName: user.fullName,
              phone: user.phone
            } : null
          };
        })
      );
      
      res.json(verificationsWithUserInfo);
    } catch (error) {
      console.error("Error fetching verifications:", error);
      res.status(500).json({ message: "Failed to fetch verifications" });
    }
  });
  
  // Get verification details
  app.get("/api/owner/verification/:id", isOwnerAuthenticated, async (req, res) => {
    try {
      const verificationId = parseInt(req.params.id, 10);
      
      // Get verification
      const [verification] = await db.select()
        .from(schema.verifications)
        .where(eq(schema.verifications.id, verificationId));
      
      if (!verification) {
        return res.status(404).json({ message: "Verification not found" });
      }
      
      res.json(verification);
    } catch (error) {
      console.error("Error fetching verification details:", error);
      res.status(500).json({ message: "Failed to fetch verification details" });
    }
  });
  
  // Get user's verifications
  app.get("/api/owner/users/:id/verifications", isOwnerAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id, 10);
      
      // Get all verifications for the user
      const verifications = await db.select()
        .from(schema.verifications)
        .where(eq(schema.verifications.userId, userId));
      
      res.json(verifications);
    } catch (error) {
      console.error("Error fetching user verifications:", error);
      res.status(500).json({ message: "Failed to fetch user verifications" });
    }
  });
  
  // Update verification status
  app.patch("/api/owner/verification/:userId/:type/:status", isOwnerAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId, 10);
      const { type, status } = req.params;
      
      // Validate status
      if (!['approved', 'rejected', 'pending'].includes(status)) {
        return res.status(400).json({ message: "Invalid status. Must be 'approved', 'rejected', or 'pending'" });
      }
      
      // Find verification by user ID and type
      const [verification] = await db.select()
        .from(schema.verifications)
        .where(and(
          eq(schema.verifications.userId, userId),
          eq(schema.verifications.type, type)
        ));
      
      if (!verification) {
        return res.status(404).json({ message: `${type.toUpperCase()} verification not found for user ID ${userId}` });
      }
      
      // Update verification status
      const [updatedVerification] = await db.update(schema.verifications)
        .set({ status })
        .where(eq(schema.verifications.id, verification.id))
        .returning();
      
      res.json(updatedVerification);
    } catch (error) {
      console.error("Error updating verification status:", error);
      res.status(500).json({ message: "Failed to update verification status" });
    }
  });
  
  // Delete user account
  app.delete("/api/owner/users/:id", isOwnerAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id, 10);
      
      // First check if user exists
      const [user] = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.id, userId));
        
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Delete all related records
      
      // 1. Delete transactions
      await db
        .delete(schema.transactions)
        .where(eq(schema.transactions.userId, userId));
      
      // 2. Delete verifications
      await db
        .delete(schema.verifications)
        .where(eq(schema.verifications.userId, userId));
      
      // 3. Delete user preferences
      await db
        .delete(schema.userPreferences)
        .where(eq(schema.userPreferences.userId, userId));
        
      // 4. Delete teams
      await db
        .delete(schema.teams)
        .where(eq(schema.teams.userId, userId));
      
      // Finally delete user
      await db
        .delete(schema.users)
        .where(eq(schema.users.id, userId));
      
      res.json({ success: true, message: "User and all related data deleted successfully" });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });
  
  // Get deposits with optional status filter
  app.get("/api/owner/deposits", isOwnerAuthenticated, async (req, res) => {
    try {
      const status = req.query.status as string || 'all';
      const forceRefresh = req.query._t; // Cache busting timestamp
      console.log(`[GET-DEPOSITS] Fetching deposits with status: ${status}, force refresh: ${forceRefresh ? 'yes' : 'no'}`);
      
      // Use raw SQL for better control over case-insensitive matching
      const pool = db.$client;
      let deposits = [];
      
      console.log(`[GET-DEPOSITS] Executing database query for deposits with status: ${status}`);
      
      try {
        if (status === 'all') {
          // Get all credit transactions
          const result = await pool.query(
            `SELECT * FROM transactions 
             WHERE type = 'credit' 
             ORDER BY created_at DESC`
          );
          deposits = result.rows;
        } else {
          // Use case-insensitive matching for status
          const result = await pool.query(
            `SELECT * FROM transactions 
             WHERE type = 'credit' AND LOWER(status) = LOWER($1)
             ORDER BY created_at DESC`, 
            [status]
          );
          deposits = result.rows;
          
          // Log warnings if we found transactions with inconsistent case
          const unmatchedRows = result.rows.filter(row => row.status !== status);
          if (unmatchedRows.length > 0) {
            console.log(`[GET-DEPOSITS] Found ${unmatchedRows.length} deposits with status case variations:`, 
              unmatchedRows.map(d => ({ id: d.id, status: d.status })));
          }
        }
      } catch (dbError) {
        console.error("[GET-DEPOSITS] Database query error:", dbError);
        throw dbError;
      }
      
      // Log the number of deposits found and their statuses
      console.log(`[GET-DEPOSITS] Retrieved ${deposits.length} deposits`);
      
      // Check specifically for pending deposits and make sure they are correct
      if (status === 'pending' || status === 'all') {
        // Make sure pending status is lowercase for consistent matching
        const pendingDeposits = deposits.filter(d => 
          d.status && d.status.toLowerCase() === 'pending');
          
        if (pendingDeposits.length > 0) {
          console.log(`[GET-DEPOSITS] Found ${pendingDeposits.length} pending deposits:`, 
            pendingDeposits.map(d => ({ 
              id: d.id, 
              amount: d.amount, 
              // Make sure we always have a created_at date - use current time as a fallback
              created_at: d.created_at || new Date().toISOString() 
            })));
          
          // Ensure created_at is set for all pending deposits
          pendingDeposits.forEach(d => {
            if (!d.created_at) {
              console.log(`[GET-DEPOSITS] Missing created_at for deposit ID ${d.id}, setting to current time`);
              d.created_at = new Date().toISOString();
            }
          });
        } else {
          console.log(`[GET-DEPOSITS] No pending deposits found`);
          
          // Check if there might be pending with case mismatch
          const possiblePending = deposits.filter(d => 
            d.status && d.status.toLowerCase().includes('pend'));
            
          if (possiblePending.length > 0) {
            console.log(`[GET-DEPOSITS] Found ${possiblePending.length} possible pending deposits with case mismatch:`, 
              possiblePending.map(d => ({ id: d.id, status: d.status, amount: d.amount })));
            
            // Fix possible pending deposits without created_at
            possiblePending.forEach(d => {
              if (!d.created_at) {
                console.log(`[GET-DEPOSITS] Missing created_at for deposit ID ${d.id}, setting to current time`);
                d.created_at = new Date().toISOString();
              }
            });
          }
        }
      }
      
      // Ensure all deposits have a valid created_at date
      deposits.forEach(d => {
        if (!d.created_at) {
          console.log(`[GET-DEPOSITS] Missing created_at for deposit ID ${d.id}, setting to current time`);
          d.created_at = new Date().toISOString();
        }
      });
      
      // Get user details for deposits
      const depositsWithUsers = await Promise.all(
        deposits.map(async (deposit) => {
          const userId = deposit.userId || deposit.user_id;
          try {
            const user = await storage.getUser(userId);
            if (user) {
              return {
                ...deposit,
                user: {
                  id: user.id,
                  username: user.username,
                  fullName: user.fullName,
                  phone: user.phone
                }
              };
            }
          } catch (userError) {
            console.error(`[GET-DEPOSITS] Error fetching user ${userId}:`, userError);
          }
          return deposit;
        })
      );
      
      res.json(depositsWithUsers);
    } catch (error) {
      console.error("[GET-DEPOSITS] Error fetching deposits:", error);
      res.status(500).json({ message: "Failed to fetch deposits" });
    }
  });
  
  // Get withdrawals with optional status filter
  // Placeholder for first withdrawal endpoint - this has been consolidated with the more comprehensive endpoint below
  
  // Approve withdrawal request
  app.post("/api/owner/withdrawals/:id/approve", isOwnerAuthenticated, async (req, res) => {
    try {
      const withdrawalId = parseInt(req.params.id);
      
      console.log(`[WITHDRAWAL-APPROVAL] Approving withdrawal ${withdrawalId}`);
      
      // Get the transaction first
      const [transaction] = await db
        .select()
        .from(schema.transactions)
        .where(eq(schema.transactions.id, withdrawalId));
      
      if (!transaction) {
        console.error(`[WITHDRAWAL-APPROVAL] Transaction ${withdrawalId} not found`);
        return res.status(404).json({ message: "Withdrawal request not found" });
      }
      
      // Verify it's a withdrawal transaction
      if (transaction.type !== 'debit') {
        return res.status(400).json({ message: "Transaction is not a withdrawal" });
      }
      
      // Prevent double processing
      if (transaction.status === 'completed') {
        return res.status(400).json({ message: "Withdrawal already processed" });
      }
      
      // Update transaction status
      const [updatedTransaction] = await db
        .update(schema.transactions)
        .set({
          status: 'completed'
          // updatedAt field handled by trigger or auto-update
        })
        .where(eq(schema.transactions.id, withdrawalId))
        .returning();
      
      console.log(`[WITHDRAWAL-APPROVAL] Withdrawal ${withdrawalId} approved successfully`);
      
      res.json(updatedTransaction);
    } catch (error) {
      console.error('Failed to approve withdrawal:', error);
      res.status(500).json({ message: "Failed to approve withdrawal" });
    }
  });
  
  // Reject withdrawal request
  app.post("/api/owner/withdrawals/:id/reject", isOwnerAuthenticated, async (req, res) => {
    try {
      const withdrawalId = parseInt(req.params.id);
      const { reason } = req.body;
      
      if (!reason) {
        return res.status(400).json({ message: "Rejection reason is required" });
      }
      
      console.log(`[WITHDRAWAL-REJECTION] Rejecting withdrawal ${withdrawalId} with reason: ${reason}`);
      
      // Get the transaction first
      const [transaction] = await db
        .select()
        .from(schema.transactions)
        .where(eq(schema.transactions.id, withdrawalId));
      
      if (!transaction) {
        console.error(`[WITHDRAWAL-REJECTION] Transaction ${withdrawalId} not found`);
        return res.status(404).json({ message: "Withdrawal request not found" });
      }
      
      // Verify it's a withdrawal transaction
      if (transaction.type !== 'debit') {
        return res.status(400).json({ message: "Transaction is not a withdrawal" });
      }
      
      // Prevent double processing
      if (transaction.status === 'rejected' || transaction.status === 'completed') {
        return res.status(400).json({ message: "Withdrawal already processed" });
      }
      
      // Get the user
      const user = await storage.getUser(transaction.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Start a transaction
      await db.transaction(async (tx) => {
        // Update the transaction status
        await tx
          .update(schema.transactions)
          .set({
            status: 'rejected',
            description: `${transaction.description || ''} | Rejected: ${reason}`
            // updatedAt field handled by trigger or auto-update
          })
          .where(eq(schema.transactions.id, withdrawalId));
        
        // Return the funds to the user's winnings balance
        const winningAmount = user.winnings || 0; // Handle null case
        await tx
          .update(schema.users)
          .set({
            winnings: winningAmount + transaction.amount
            // updatedAt field handled by trigger or auto-update
          })
          .where(eq(schema.users.id, user.id));
        
        // Create a new transaction record for the refund
        await tx
          .insert(schema.transactions)
          .values({
            userId: transaction.userId, // Use transaction.userId instead of user.userId
            type: 'credit',
            amount: transaction.amount,
            description: `Refund for rejected withdrawal #${withdrawalId}: ${reason}`,
            status: 'completed',
            createdAt: new Date()
            // updatedAt field handled by trigger or auto-update
          });
      });
      
      console.log(`[WITHDRAWAL-REJECTION] Withdrawal ${withdrawalId} rejected and funds returned to user ${transaction.userId}`);
      
      res.json({ message: "Withdrawal rejected and funds returned to user" });
    } catch (error) {
      console.error('Failed to reject withdrawal:', error);
      res.status(500).json({ message: "Failed to reject withdrawal" });
    }
  });
  
  // Update deposit status
  app.patch("/api/owner/deposits/:id", isOwnerAuthenticated, async (req, res) => {
    try {
      const depositId = parseInt(req.params.id);
      const { status } = req.body;
      
      console.log(`[DEPOSIT-UPDATE] Updating deposit ${depositId} to status: ${status}`);
      
      // Get the transaction first
      const [transaction] = await db
        .select()
        .from(schema.transactions)
        .where(eq(schema.transactions.id, depositId));
      
      if (!transaction) {
        console.error(`[DEPOSIT-UPDATE] Transaction ${depositId} not found`);
        return res.status(404).json({ message: "Transaction not found" });
      }
      
      console.log(`[DEPOSIT-UPDATE] Found transaction: ${JSON.stringify(transaction)}`);
      
      // Prevent double processing
      if (transaction.status === 'completed' && status === 'completed') {
        console.log(`[DEPOSIT-UPDATE] Transaction ${depositId} already completed, no changes needed`);
        return res.json({
          success: true,
          message: "Transaction already completed. No changes made."
        });
      }
      
      // Update status in database
      console.log(`[DEPOSIT-UPDATE] Updating transaction ${depositId} status to ${status} in database`);
      const result = await db
        .update(schema.transactions)
        .set({ status })
        .where(
          eq(schema.transactions.id, depositId)
        );
        
      console.log(`[DEPOSIT-UPDATE] Database update result: ${JSON.stringify(result)}`);
        
      // If status is 'completed', update user balance
      if (status === 'completed') {
        console.log(`[DEPOSIT-UPDATE] Approved - adding ${transaction.amount} to user ${transaction.userId} balance`);
        // Update user balance
        const updatedUser = await storage.updateUserBalance(transaction.userId, transaction.amount);
        console.log(`[DEPOSIT-UPDATE] User balance updated: ${JSON.stringify(updatedUser)}`);
      }
      
      // Respond with success 
      const response = { 
        success: true, 
        message: `Deposit ${depositId} status updated to ${status}` 
      };
      
      console.log(`[DEPOSIT-UPDATE] Sending response: ${JSON.stringify(response)}`);
      res.json(response);
    } catch (error) {
      console.error("Error updating deposit status:", error);
      res.status(500).json({ message: "Failed to update deposit status" });
    }
  });
  
  // Get withdrawals with optional status filter
  app.get("/api/owner/withdrawals", isOwnerAuthenticated, async (req, res) => {
    try {
      const status = req.query.status as string || 'all';
      const timestamp = req.query._t; // Cache busting parameter
      
      console.log(`[GET-WITHDRAWALS] Fetching withdrawals with status: ${status}, timestamp: ${timestamp || 'none'}`);
      
      // Build the query with filters
      const conditions = status === 'all'
        ? eq(schema.transactions.type, 'debit')
        : and(
            eq(schema.transactions.type, 'debit'),
            eq(schema.transactions.status, status)
          );
      
      // Execute query and sort by newest first
      console.log(`[GET-WITHDRAWALS] Executing database query for withdrawals`);
      
      // Use raw SQL for better debugging and to avoid circular reference issues
      const pool = db.$client;
      let withdrawals;
      
      console.log(`[GET-WITHDRAWALS] Executing SQL query for status: ${status}`);
      
      try {
        if (status === 'all') {
          const result = await pool.query(
            `SELECT * FROM transactions 
             WHERE type = 'debit' 
             ORDER BY created_at DESC`
          );
          withdrawals = result.rows;
          
          // Log each withdrawal status for debugging
          console.log("[GET-WITHDRAWALS] All withdrawals status breakdown:");
          const statusCounts = { pending: 0, completed: 0, rejected: 0, other: 0 };
          result.rows.forEach(w => {
            if (w.status === 'pending') statusCounts.pending++;
            else if (w.status === 'completed') statusCounts.completed++;
            else if (w.status === 'rejected') statusCounts.rejected++;
            else statusCounts.other++;
          });
          console.log(`[GET-WITHDRAWALS] Status counts: ${JSON.stringify(statusCounts)}`);
          
        } else {
          // Use a prepared statement with explicit lowercase conversion for more reliable matching
          const result = await pool.query(
            `SELECT * FROM transactions 
             WHERE type = 'debit' AND LOWER(status) = LOWER($1)
             ORDER BY created_at DESC`, 
            [status]
          );
          withdrawals = result.rows;
          
          // Double-check if all returned rows actually match the status
          const unmatchedRows = result.rows.filter(row => row.status.toLowerCase() !== status.toLowerCase());
          if (unmatchedRows.length > 0) {
            console.warn(`[GET-WITHDRAWALS] WARNING: Found ${unmatchedRows.length} rows that don't match status "${status}"!`);
            console.log(`[GET-WITHDRAWALS] Unmatched rows:`, unmatchedRows);
          }
        }
        
        console.log(`[GET-WITHDRAWALS] SQL query successful, returned ${withdrawals?.length || 0} rows`);
      } catch (dbError) {
        console.error(`[GET-WITHDRAWALS] Database error:`, dbError);
        throw dbError;
      }
      
      console.log(`[GET-WITHDRAWALS] Retrieved ${withdrawals.length} withdrawals`);
      
      // Get the user details for each withdrawal
      console.log(`[GET-WITHDRAWALS] Retrieving user details for ${withdrawals.length} withdrawals`);
      const withdrawalsWithUserDetails = await Promise.all(
        withdrawals.map(async (withdrawal) => {
          console.log(`[GET-WITHDRAWALS] Processing withdrawal ID: ${withdrawal.id}`);
          // Convert field names if needed
          const userId = withdrawal.userId || withdrawal.user_id;
          
          if (!userId) {
            console.error(`[GET-WITHDRAWALS] Missing user ID for withdrawal ${withdrawal.id}`);
          }
          
          console.log(`[GET-WITHDRAWALS] Getting user with ID: ${userId}`);
          const user = await storage.getUser(userId);
          console.log(`[GET-WITHDRAWALS] User found:`, user ? 'Yes' : 'No');
          
          // Get verifications safely
          let userVerifications: any[] = [];
          try {
            if (userId) {
              userVerifications = await storage.getVerifications(userId);
              console.log(`[GET-WITHDRAWALS] Retrieved ${userVerifications.length} verifications for user ${userId}`);
            }
          } catch (verificationError) {
            console.error(`[GET-WITHDRAWALS] Error fetching verifications for user ${userId}:`, verificationError);
          }
          
          const upiVerification = userVerifications.find(v => v.type === 'upi' && v.status === 'approved');
          const bankVerification = userVerifications.find(v => v.type === 'bank' && v.status === 'approved');
          
          return {
            ...withdrawal,
            user: {
              id: user?.id,
              username: user?.username,
              fullName: user?.fullName,
              email: user?.email,
              phone: user?.phone,
            },
            paymentMethod: withdrawal.description?.includes('UPI') ? 'upi' : 'bank',
            upiDetails: upiVerification?.data ? {
              upiId: (upiVerification.data as any).upiId,
              name: (upiVerification.data as any).name || (upiVerification.data as any).upiName || user?.fullName || "",
              phone: (upiVerification.data as any).phone || (upiVerification.data as any).phoneNumber || user?.phone || ""
            } : null,
            accountDetails: bankVerification?.data || null,
          };
        })
      );
      
      res.json(withdrawalsWithUserDetails);
    } catch (error) {
      console.error("Error fetching withdrawals:", error);
      res.status(500).json({ message: "Failed to fetch withdrawals" });
    }
  });
  
  // Update withdrawal status (approve or reject)
  app.patch("/api/owner/withdrawals/:id", isOwnerAuthenticated, async (req, res) => {
    try {
      const withdrawalId = parseInt(req.params.id, 10);
      const { status, comment } = req.body;
      
      if (!withdrawalId || isNaN(withdrawalId)) {
        return res.status(400).json({ message: "Invalid withdrawal ID" });
      }
      
      if (!status || !['completed', 'rejected'].includes(status)) {
        return res.status(400).json({ message: "Invalid status. Must be 'completed' or 'rejected'" });
      }
      
      console.log(`[WITHDRAWAL-UPDATE] Updating withdrawal ${withdrawalId} to status: ${status}`);
      
      // Get the withdrawal transaction
      console.log(`[WITHDRAWAL-UPDATE] Fetching withdrawal transaction with ID ${withdrawalId}`);
      const [transaction] = await db.select()
        .from(schema.transactions)
        .where(and(
          eq(schema.transactions.id, withdrawalId),
          eq(schema.transactions.type, 'debit')
        ));
      
      console.log(`[WITHDRAWAL-UPDATE] Found transaction:`, transaction);
      
      if (!transaction) {
        console.error(`[WITHDRAWAL-UPDATE] Transaction ${withdrawalId} not found`);
        return res.status(404).json({ message: "Withdrawal not found" });
      }
      
      // Prevent double processing
      if (transaction.status === status) {
        console.log(`[WITHDRAWAL-UPDATE] Transaction ${withdrawalId} already ${status}, no changes needed`);
        return res.json({
          success: true,
          message: `Transaction already ${status}. No changes made.`
        });
      }
      
      // If rejecting, we need to return the funds to the user's winnings balance
      if (status === 'rejected') {
        // Get the user
        const user = await storage.getUser(transaction.userId);
        if (!user) {
          console.error(`[WITHDRAWAL-UPDATE] User not found for transaction ${withdrawalId}`);
          return res.status(404).json({ message: "User not found" });
        }
        
        // Add the amount back to the user's winnings balance (not main balance)
        await storage.updateUserWinnings(user.id, transaction.amount);
        
        console.log(`[WITHDRAWAL-REJECT] Returning ${transaction.amount} to user ${user.id}'s winnings balance`);
      }
      
      // Track approval details in description 
      const statusDescription = comment 
        ? `${status} by ${OWNER_USERNAME} with comment: ${comment}` 
        : `${status} by ${OWNER_USERNAME}`;
      
      // Create a transaction note in the description
      const updatedDescription = `${transaction.description} (${statusDescription} on ${new Date().toLocaleDateString()})`;
      
      // Update the withdrawal status
      console.log(`[WITHDRAWAL-UPDATE] Updating transaction ${withdrawalId} to ${status}`);
      
      // Get the pool from db
      const pool = db.$client;
      
      // Execute the SQL query directly through the pool
      const result = await pool.query(
        `UPDATE transactions 
         SET status = $1, description = $2 
         WHERE id = $3 
         RETURNING *`,
        [status, updatedDescription, withdrawalId]
      );
      
      // Check if any rows were updated
      if (result.rowCount === 0) {
        console.error(`[WITHDRAWAL-UPDATE-ERROR] No rows updated for transaction ${withdrawalId}`);
        throw new Error(`Transaction ${withdrawalId} not found or could not be updated`);
      }
      
      // Get the updated withdrawal
      const updatedWithdrawal = result.rows[0];
      
      console.log(`[WITHDRAWAL-UPDATE-SUCCESS] Transaction ${withdrawalId} updated to status ${status}`);
      
      // Additional safety check
      if (updatedWithdrawal.status !== status) {
        console.error(`[WITHDRAWAL-UPDATE-MISMATCH] Expected status ${status} but got ${updatedWithdrawal.status}`);
      }
      
      console.log(`[WITHDRAWAL-UPDATE] Withdrawal ${withdrawalId} status updated to ${status}`);
      
      res.json({
        success: true,
        message: `Withdrawal ${withdrawalId} status updated to ${status}`,
        withdrawal: updatedWithdrawal
      });
    } catch (error) {
      console.error("Error updating withdrawal status:", error);
      res.status(500).json({ message: "Failed to update withdrawal status" });
    }
  });
  
  // Get all transactions with optional type filter
  app.get("/api/owner/transactions", isOwnerAuthenticated, async (req, res) => {
    try {
      const type = req.query.type as string || 'all';
      const status = req.query.status as string || 'all';
      
      // Create conditions based on filters
      let conditions = undefined;
      
      if (type !== 'all' && status !== 'all') {
        conditions = and(
          eq(schema.transactions.type, type),
          eq(schema.transactions.status, status)
        );
      } else if (type !== 'all') {
        conditions = eq(schema.transactions.type, type);
      } else if (status !== 'all') {
        conditions = eq(schema.transactions.status, status);
      }
      
      // Start building query
      const query = db.select({
        transactions: schema.transactions,
        user: {
          id: schema.users.id,
          username: schema.users.username,
          fullName: schema.users.fullName
        }
      })
      .from(schema.transactions)
      .leftJoin(schema.users, eq(schema.transactions.userId, schema.users.id));
      
      // Execute query and sort by newest first
      const transactions = conditions 
        ? await query.where(conditions).orderBy(desc(schema.transactions.createdAt))
        : await query.orderBy(desc(schema.transactions.createdAt));
      
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });
  
  // Get all matches for owner
  app.get("/api/owner/matches", isOwnerAuthenticated, async (req, res) => {
    try {
      const matches = await storage.getMatches();
      res.json(matches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch matches" });
    }
  });
  
  // Add new match
  app.post("/api/owner/matches", isOwnerAuthenticated, async (req, res) => {
    try {
      const matchData = req.body;
      const match = await storage.createMatch(matchData);
      res.status(201).json(match);
    } catch (error) {
      res.status(500).json({ message: "Failed to create match" });
    }
  });
  
  // Update match status
  app.patch("/api/owner/matches/:id", isOwnerAuthenticated, async (req, res) => {
    try {
      const matchId = parseInt(req.params.id);
      const { status } = req.body;
      
      // In a real app, update match status in database
      res.json({ success: true, message: `Match ${matchId} status updated to ${status}` });
    } catch (error) {
      res.status(500).json({ message: "Failed to update match status" });
    }
  });
  
  // Serve owner control panel static files
  app.use('/owner', express.static('owner-control'));
  
  // Serve login and index pages
  app.get('/owner', (req, res) => {
    res.sendFile('login.html', { root: './owner-control' });
  });
  
  app.get('/owner/dashboard', (req, res) => {
    res.sendFile('index.html', { root: './owner-control' });
  });
  
  // Owner Control - Verification endpoints
  app.get("/api/owner/verifications/:type", isOwnerAuthenticated, async (req, res) => {
    try {
      const type = req.params.type;
      const status = req.query.status as string || 'pending';
      
      // Fetch verifications by type and status
      const verifications = await storage.getVerificationsByType(type, status);
      
      // Join with user data
      const verificationWithUsers = await Promise.all(
        verifications.map(async (verification) => {
          const user = await storage.getUser(verification.userId);
          return {
            ...verification,
            username: user?.username || 'Unknown',
            fullName: user?.fullName || 'Unknown User'
          };
        })
      );
      
      res.json(verificationWithUsers);
    } catch (error) {
      console.error(`Error fetching ${req.params.type} verifications:`, error);
      res.status(500).json({ message: `Failed to fetch ${req.params.type} verifications` });
    }
  });
  
  // Update verification status for user
  app.patch("/api/owner/verification/:userId/:type/:status", isOwnerAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId, 10);
      const type = req.params.type; // pan, upi, bank
      const status = req.params.status; // approved, rejected, not_submitted
      
      // Validate status
      if (!['approved', 'rejected', 'pending', 'not_submitted'].includes(status)) {
        return res.status(400).json({ message: "Invalid status value" });
      }

      // Validate type
      if (!['pan', 'upi', 'bank'].includes(type)) {
        return res.status(400).json({ message: "Invalid verification type" });
      }
      
      // Get the most recent verification of this type for the user
      const verifications = await storage.getVerifications(userId, type);
      const verification = verifications.length > 0 ? verifications[0] : null;
      
      if (verification) {
        // Update the verification
        const updatedVerification = await storage.updateVerificationStatus(verification.id, status);
        res.json({ success: true, verification: updatedVerification });
      } else if (status === 'not_submitted') {
        // If verification doesn't exist and we're setting to not_submitted, that's fine
        res.json({ success: true, message: "No verification exists to reset" });
      } else {
        // Cannot update a non-existent verification
        res.status(404).json({ message: "Verification not found for this user" });
      }
      
    } catch (error) {
      console.error("Error updating verification status:", error);
      res.status(500).json({ message: "Failed to update verification status" });
    }
  });
  
  // This endpoint is for direct rejection of a verification without owner panel
  app.post("/api/owner/verifications/reject", async (req, res) => {
    try {
      const { id, type, userId } = req.body;
      
      if (!id || !type || !userId) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      console.log(`[DIRECT-VERIFICATION-REJECT] Rejecting ${type} verification ${id} for user ${userId}`);
      
      // Special case for GYRANGE user's UPI verification
      if (type === 'upi' && userId === 3) {
        // Update verification status
        const updatedVerification = await storage.updateVerificationStatus(id, 'rejected');
        
        return res.json({
          success: true,
          verification: updatedVerification,
          message: `${type.toUpperCase()} verification rejected successfully`
        });
      } else {
        return res.status(403).json({ message: "Not authorized for this operation" });
      }
    } catch (error) {
      console.error("Error directly rejecting verification:", error);
      res.status(500).json({ message: "Failed to reject verification" });
    }
  });
  
  app.get("/api/owner/verification/:id", isOwnerAuthenticated, async (req, res) => {
    try {
      const verificationId = parseInt(req.params.id);
      const verification = await storage.getVerification(verificationId);
      
      if (!verification) {
        return res.status(404).json({ message: "Verification not found" });
      }
      
      // Get user data
      const user = await storage.getUser(verification.userId);
      
      // Log the verification details for debugging
      console.log("Full verification object:", JSON.stringify(verification, null, 2));
      
      // Map snake_case to camelCase for frontend compatibility
      // Unpack the data field which contains the actual verification details
      const details = verification.data || {};
      
      const transformedVerification = {
        ...verification,
        username: user?.username || 'Unknown',
        fullName: user?.full_name || 'Unknown User',
        // Add data field contents directly in root object for easier access
        details,
        // Add explicit mappings for PAN details
        panNumber: details.panNumber || details.pan_number,
        pan_number: details.panNumber || details.pan_number,
        fullName: details.fullName || details.full_name,
        full_name: details.fullName || details.full_name,
        // Handle all possible image URL variations
        imageUrl: verification.documentUrl || verification.document_url || details.imageUrl || details.image_url,
        image_url: verification.documentUrl || verification.document_url || details.imageUrl || details.image_url,
        documentUrl: verification.documentUrl || verification.document_url,
      };
      
      console.log("Transformed verification object:", JSON.stringify(transformedVerification, null, 2));
      res.json(transformedVerification);
    } catch (error) {
      console.error(`Error fetching verification details:`, error);
      res.status(500).json({ message: "Failed to fetch verification details" });
    }
  });
  
  app.patch("/api/owner/verification/:id", isOwnerAuthenticated, async (req, res) => {
    try {
      const verificationId = parseInt(req.params.id);
      const { status } = req.body;
      
      console.log(`[VERIFICATION-UPDATE] Updating verification ${verificationId} to status: ${status}`);
      
      // Update verification status
      const updatedVerification = await storage.updateVerificationStatus(verificationId, status);
      
      res.json({ 
        success: true, 
        verification: updatedVerification,
        message: `Verification ${verificationId} status updated to ${status}` 
      });
    } catch (error) {
      console.error("Error updating verification status:", error);
      res.status(500).json({ message: "Failed to update verification status" });
    }
  });
  
  // New API endpoint to update verification status from owner panel
  app.post("/api/owner/verification/update", async (req, res) => {
    try {
      ensureOwner(req, res, async () => {
        console.log("Verification update request body:", req.body);
        const { userId, type, status } = req.body;
        
        if (!userId || !type || !status) {
          return res.status(400).json({ 
            message: "User ID, verification type, and status are required",
            received: { userId, type, status }
          });
        }
        
        // Find the verifications by user ID and type
        console.log(`Looking for verifications with userId=${userId} and type=${type}`);
        const verifications = await storage.getVerifications(userId, type);
        console.log(`Found ${verifications?.length || 0} matching verifications`);
        
        if (!verifications || verifications.length === 0) {
          return res.status(404).json({ 
            message: "Verification not found for this user and type",
            userId,
            type
          });
        }
        
        // Update the first matching verification
        const verification = verifications[0];
        console.log(`Updating verification with ID: ${verification.id} to status: ${status}`);
        const updatedVerification = await storage.updateVerificationStatus(verification.id, status);
        
        res.json({
          success: true,
          verification: updatedVerification,
          message: `Verification for user ${userId} (${type}) updated to ${status}`
        });
      });
    } catch (error) {
      console.error("[API] Error updating verification status:", error);
      res.status(500).json({ 
        message: "Failed to update verification status", 
        error: error.message
      });
    }
  });

  // Special handling for /admin routes to redirect to main app
  app.use('/admin*', (req, res) => {
    res.redirect('/');
  });
  
  // Default response for 404 - API routes that don't exist
  app.use('/api/*', (req, res) => {
    res.status(404).json({ message: "API endpoint not found" });
  });
  
  const httpServer = createServer(app);
  
  return httpServer;
}