import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/use-auth";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Loader2 } from "lucide-react";
import { ForgotPasswordModal } from "@/components/modals/forgot-password-modal";

export default function AuthPage() {
  const { user, loginMutation, registerMutation, isLoading } = useAuth();
  const [, navigate] = useLocation();
  const [showLogin, setShowLogin] = useState(true);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [agreeToTerms, setAgreeToTerms] = useState(false);

  // State for our form inputs
  const [loginForm, setLoginForm] = useState({ username: "", password: "" });
  const [registerForm, setRegisterForm] = useState({ 
    full_name: "", // Using snake_case to match backend schema
    email: "", 
    phone: "", // Added phone field for Indian numbers
    username: "", 
    password: "", 
    referred_by: "" // Using snake_case to match backend schema
  });
  
  // Check if user is logged in
  useEffect(() => {
    console.log("AuthPage: Checking user status", user);
    if (user) {
      console.log("AuthPage: User found, redirecting to homepage");
      navigate("/");
    }
  }, [user, navigate]);
  
  // Form handlers
  const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLoginForm({ ...loginForm, [e.target.name]: e.target.value });
  };
  
  const handleRegisterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRegisterForm({ ...registerForm, [e.target.name]: e.target.value });
  };
  
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreeToTerms) {
      alert("Please confirm that you are 18+ and agree to the Terms and Conditions");
      return;
    }
    // Email is now being used as username for backend compatibility
    loginMutation.mutate(loginForm);
  };
  
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreeToTerms) {
      alert("Please confirm that you are 18+ and agree to the Terms and Conditions");
      return;
    }
    registerMutation.mutate(registerForm);
  };
  
  // Toggle between login and register
  const toggleForm = () => {
    setShowLogin(!showLogin);
  };
  
  // If loading user data, show a loader
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <header className="flex justify-between items-center p-4">
        <div></div>
        {/* Theme toggle removed as per user request */}
      </header>

      {showLogin ? (
        <div className="mt-6 flex-1 flex flex-col justify-center px-6">
          <div className="sm:mx-auto sm:w-full sm:max-w-sm">
            <div className="flex justify-center">
              <img src="/images/uploaded/app-logo-new.png" alt="11byChatGPT" className="w-28 h-28" />
            </div>
            <h2 className="mt-6 text-center text-2xl font-bold leading-9 tracking-tight text-gray-900">
              Sign in 11byChatGPT
            </h2>
          </div>

          <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
            <form className="space-y-6" onSubmit={handleLoginSubmit}>
              <div>
                <label htmlFor="username" className="block text-sm font-medium leading-6 text-gray-900">
                  Email
                </label>
                <div className="mt-2">
                  <Input
                    id="username"
                    name="username"
                    value={loginForm.username}
                    onChange={handleLoginChange}
                    type="email"
                    autoComplete="email"
                    required
                    className="p-2 block w-full rounded-md border border-gray-300"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <label htmlFor="password" className="block text-sm font-medium leading-6 text-gray-900">
                    Password
                  </label>
                  <div className="text-sm">
                    <button 
                      onClick={(e) => {
                        e.preventDefault();
                        setShowForgotPassword(true);
                      }}
                      className="font-semibold text-primary hover:text-primary/80 bg-transparent border-none p-0"
                    >
                      Forgot password?
                    </button>
                  </div>
                </div>
                <div className="mt-2">
                  <Input
                    id="password"
                    name="password"
                    value={loginForm.password}
                    onChange={handleLoginChange}
                    type="password"
                    autoComplete="current-password"
                    required
                    className="p-2 block w-full rounded-md border border-gray-300"
                  />
                </div>
              </div>

              <div className="flex items-start mb-4">
                <div className="flex items-center h-5">
                  <input
                    id="terms"
                    type="checkbox"
                    checked={agreeToTerms}
                    onChange={(e) => setAgreeToTerms(e.target.checked)}
                    className="w-4 h-4 border border-gray-300 rounded bg-gray-50 focus:ring-3 focus:ring-primary"
                  />
                </div>
                <div className="ml-3 text-sm">
                  <label htmlFor="terms" className="text-sm font-bold">
                    <span className="text-red-600 font-extrabold">I am 18+ and agree to the</span> <a href="/terms-and-conditions" className="text-primary underline font-bold hover:text-primary-dark">Terms and Conditions</a>
                  </label>
                </div>
              </div>
              
              <div>
                <Button
                  type="submit"
                  className="w-full py-2"
                  disabled={loginMutation.isPending || !agreeToTerms}
                >
                  {loginMutation.isPending ? "Signing in..." : "Sign in"}
                </Button>
              </div>
            </form>

            <p className="mt-6 text-center text-sm text-gray-500">
              Not a member?{' '}
              <button 
                onClick={toggleForm}
                className="font-semibold text-primary hover:text-primary/80 px-0 py-0 bg-transparent hover:bg-transparent"
              >
                Register now
              </button>
            </p>
          </div>
        </div>
      ) : (
        <div className="mt-6 flex-1 flex flex-col justify-center px-6">
          <div className="sm:mx-auto sm:w-full sm:max-w-sm">
            <div className="flex justify-center">
              <img src="/images/uploaded/app-logo-new.png" alt="11byChatGPT" className="w-28 h-28" />
            </div>
            <h2 className="mt-6 text-center text-2xl font-bold leading-9 tracking-tight text-gray-900">
              Create your 11byChatGPT account
            </h2>
            <p className="mt-2 text-center text-sm text-gray-600">
              Join the exciting world of fantasy cricket
            </p>
          </div>

          <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
            <form className="space-y-6" onSubmit={handleRegisterSubmit}>
              <div>
                <label htmlFor="full_name" className="block text-sm font-medium leading-6 text-gray-900">
                  Full Name
                </label>
                <div className="mt-2">
                  <Input
                    id="full_name"
                    name="full_name"
                    value={registerForm.full_name}
                    onChange={handleRegisterChange}
                    type="text"
                    required
                    className="p-2 block w-full rounded-md border border-gray-300"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium leading-6 text-gray-900">
                  Email
                </label>
                <div className="mt-2">
                  <Input
                    id="email"
                    name="email"
                    value={registerForm.email}
                    onChange={handleRegisterChange}
                    type="email"
                    autoComplete="email"
                    required
                    className="p-2 block w-full rounded-md border border-gray-300"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="phone" className="block text-sm font-medium leading-6 text-gray-900">
                  Phone (For OTP Verification)
                </label>
                <div className="mt-2 relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <span className="text-gray-500">+91</span>
                  </div>
                  <Input
                    id="phone"
                    name="phone"
                    value={registerForm.phone}
                    onChange={handleRegisterChange}
                    type="tel"
                    pattern="[0-9]{10}"
                    maxLength={10}
                    placeholder="10-digit mobile number"
                    required
                    className="p-2 pl-12 block w-full rounded-md border border-gray-300"
                  />
                </div>
                <p className="mt-1 text-xs text-gray-500">Enter 10-digit Indian mobile number</p>
              </div>
              
              <div>
                <label htmlFor="reg-username" className="block text-sm font-medium leading-6 text-gray-900">
                  Username
                </label>
                <div className="mt-2">
                  <Input
                    id="reg-username"
                    name="username"
                    value={registerForm.username}
                    onChange={handleRegisterChange}
                    type="text"
                    required
                    className="p-2 block w-full rounded-md border border-gray-300"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="reg-password" className="block text-sm font-medium leading-6 text-gray-900">
                  Password
                </label>
                <div className="mt-2">
                  <Input
                    id="reg-password"
                    name="password"
                    value={registerForm.password}
                    onChange={handleRegisterChange}
                    type="password"
                    required
                    className="p-2 block w-full rounded-md border border-gray-300"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="referred_by" className="block text-sm font-medium leading-6 text-gray-900">
                  Referral Code (Optional)
                </label>
                <div className="mt-2">
                  <Input
                    id="referred_by"
                    name="referred_by"
                    value={registerForm.referred_by}
                    onChange={handleRegisterChange}
                    type="text"
                    className="p-2 block w-full rounded-md border border-gray-300"
                  />
                </div>
              </div>

              <div className="flex items-start mb-4">
                <div className="flex items-center h-5">
                  <input
                    id="register-terms"
                    type="checkbox"
                    checked={agreeToTerms}
                    onChange={(e) => setAgreeToTerms(e.target.checked)}
                    className="w-4 h-4 border border-gray-300 rounded bg-gray-50 focus:ring-3 focus:ring-primary"
                  />
                </div>
                <div className="ml-3 text-sm">
                  <label htmlFor="register-terms" className="text-sm font-bold">
                    <span className="text-red-600 font-extrabold">I am 18+ and agree to the</span> <a href="/terms-and-conditions" className="text-primary underline font-bold hover:text-primary-dark">Terms and Conditions</a>
                  </label>
                </div>
              </div>
              
              <div>
                <Button
                  type="submit"
                  className="w-full py-2"
                  disabled={registerMutation.isPending || !agreeToTerms}
                >
                  {registerMutation.isPending ? "Creating account..." : "Create account"}
                </Button>
              </div>
            </form>
            
            <p className="mt-6 text-center text-sm text-gray-500">
              Already have an account?{' '}
              <button
                onClick={toggleForm}
                className="font-semibold text-primary hover:text-primary/80 px-0 py-0 bg-transparent hover:bg-transparent"
              >
                Sign in
              </button>
            </p>
          </div>
        </div>
      )}
      
      {/* Forgot Password Modal */}
      <ForgotPasswordModal 
        isOpen={showForgotPassword} 
        onClose={() => setShowForgotPassword(false)} 
      />
    </div>
  );
}