import React, { useState, useEffect, ReactNode } from 'react';
import { Loader2, RefreshCw } from 'lucide-react';

interface PullToRefreshProps {
  children: ReactNode;
  onRefresh: () => Promise<any>;
  pullDownThreshold?: number;
  maxPullDownDistance?: number;
  backgroundColor?: string;
  showRefreshButton?: boolean;
}

export function PullToRefresh({
  children,
  onRefresh,
  pullDownThreshold = 80,
  maxPullDownDistance = 120,
  backgroundColor = 'var(--background)',
  showRefreshButton = false
}: PullToRefreshProps) {
  const [isPulling, setIsPulling] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const [startY, setStartY] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Start pulling tracking
  const handleTouchStart = (e: React.TouchEvent | TouchEvent) => {
    // Only trigger if at top of the page
    if (window.scrollY <= 0) {
      setStartY(e.touches[0].clientY);
      setIsPulling(true);
    }
  };

  // Track pull movement
  const handleTouchMove = (e: React.TouchEvent | TouchEvent) => {
    if (!isPulling) return;
    
    const currentY = e.touches[0].clientY;
    const newPullDistance = Math.max(0, Math.min(currentY - startY, maxPullDownDistance));
    setPullDistance(newPullDistance);
    
    // Prevent default scrolling if user is pulling down
    if (newPullDistance > 0 && window.scrollY <= 0) {
      e.preventDefault();
    }
  };

  // End pulling and check if should refresh
  const handleTouchEnd = async () => {
    if (!isPulling) return;
    
    if (pullDistance >= pullDownThreshold) {
      try {
        setIsRefreshing(true);
        // Execute refresh callback
        await onRefresh();
      } catch (error) {
        console.error("Error refreshing:", error);
      } finally {
        setIsRefreshing(false);
      }
    }
    
    // Reset pull state
    setPullDistance(0);
    setIsPulling(false);
  };

  // Add touch event listeners
  useEffect(() => {
    document.addEventListener('touchstart', handleTouchStart, { passive: false });
    document.addEventListener('touchmove', handleTouchMove, { passive: false });
    document.addEventListener('touchend', handleTouchEnd, { passive: false });
    
    return () => {
      document.removeEventListener('touchstart', handleTouchStart);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleTouchEnd);
    };
  }, [isPulling, pullDistance, startY]);

  // Calculate indicator opacity (0-1) based on pull distance
  const indicatorOpacity = Math.min(pullDistance / pullDownThreshold, 1);
  
  // Handle manual refresh button click
  const handleManualRefresh = async () => {
    if (isRefreshing) return;
    
    try {
      setIsRefreshing(true);
      await onRefresh();
    } catch (error) {
      console.error("Error on manual refresh:", error);
    } finally {
      setIsRefreshing(false);
    }
  };
  
  return (
    <div className="relative w-full h-full overflow-hidden">
      {/* Pull Indicator */}
      <div 
        className="absolute top-0 left-0 w-full flex justify-center items-center transition-transform z-40"
        style={{ 
          transform: `translateY(${Math.min(pullDistance / 2.5, maxPullDownDistance / 2.5) - 40}px)`,
          opacity: isRefreshing ? 1 : indicatorOpacity,
          height: '40px'
        }}
      >
        <div className="flex items-center space-x-2">
          <Loader2 
            className={`h-6 w-6 text-primary ${isRefreshing ? 'animate-spin' : ''}`} 
            style={{ 
              transform: isRefreshing ? 'rotate(0deg)' : `rotate(${pullDistance * 3}deg)` 
            }}
          />
          <span className="text-sm text-primary font-medium">
            {isRefreshing ? "Refreshing..." : pullDistance >= pullDownThreshold ? "Release to refresh" : "Pull down to refresh"}
          </span>
        </div>
      </div>
      
      {/* Content Container */}
      <div 
        className="w-full transition-transform" 
        style={{ 
          transform: isRefreshing 
            ? 'translateY(60px)' 
            : `translateY(${pullDistance / 2.5}px)`,
          transition: isPulling ? 'none' : 'transform 0.2s ease'
        }}
      >
        {/* Refresh Button */}
        {showRefreshButton && (
          <div className="fixed bottom-20 right-4 z-50">
            <button 
              onClick={handleManualRefresh}
              disabled={isRefreshing}
              className="bg-primary text-white p-3 rounded-full shadow-lg hover:bg-primary-dark transition-colors"
              aria-label="Refresh"
            >
              <RefreshCw className={`h-5 w-5 ${isRefreshing ? 'animate-spin' : ''}`} />
            </button>
          </div>
        )}
        
        {children}
      </div>
    </div>
  );
}