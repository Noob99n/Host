import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Transaction } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { NavBar } from "@/components/layout/nav-bar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Wallet, Trophy, Gift, ArrowDownCircle, ArrowUpCircle } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { TransactionItem } from "@/components/wallet/transaction-item";
import { DepositModal } from "@/components/modals/deposit-modal";
import { WithdrawModal } from "@/components/modals/withdraw-modal";
import { PullToRefresh } from "@/components/ui/pull-to-refresh";
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription 
} from "@/components/ui/dialog";

export default function WalletPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [showBalanceDetailsModal, setShowBalanceDetailsModal] = useState(false);
  const [showAllTransactionsModal, setShowAllTransactionsModal] = useState(false);
  
  const { data: transactions, isLoading } = useQuery<Transaction[]>({
    queryKey: ['/api/wallet/transactions'],
    enabled: !!user, // Only fetch if user is logged in
    staleTime: 1000 * 2, // Consider data fresh for just 2 seconds
    refetchInterval: 1000 * 5, // Auto-refresh every 5 seconds to quickly show status changes
  });

  // Handle refresh function - without toast notification
  const handleRefresh = async () => {
    try {
      // Refetch user data for updated balance
      await queryClient.refetchQueries({ queryKey: ['/api/user'] });
      // Refetch transaction history
      await queryClient.refetchQueries({ queryKey: ['/api/wallet/transactions'] });
      
      return true;
    } catch (error) {
      // Only show toast on error
      toast({
        title: "Refresh failed",
        description: "Couldn't refresh wallet data. Please try again.",
        variant: "destructive",
      });
      return false;
    }
  };
  
  const totalBalance = (user?.balance || 0) + (user?.winnings || 0) + (user?.bonus || 0);
  
  return (
    <div className="min-h-screen flex flex-col pb-16">
      <Header 
        showBack={true}
        backUrl="/"
        title="My Wallet"
      />
      
      <PullToRefresh onRefresh={handleRefresh}>
        <div className="flex-1 p-4 space-y-6">
          {/* Balance Card */}
          <div className="bg-gradient-to-r from-primary to-primary-dark rounded-xl p-5 text-white">
            <h2 className="text-sm opacity-90 mb-1">Total Balance</h2>
            <div className="flex justify-between items-center">
              <h1 className="text-3xl font-semibold">₹{totalBalance}</h1>
              <Button 
                variant="outline" 
                className="bg-white bg-opacity-20 text-white hover:bg-white hover:bg-opacity-30 hover:text-white border-0"
                onClick={() => setShowBalanceDetailsModal(true)}
              >
                View Details
              </Button>
            </div>
            <div className="flex mt-5 gap-3">
              <Button 
                variant="secondary"
                className="flex-1 bg-white text-primary hover:bg-neutral-100"
                onClick={() => setShowDepositModal(true)}
              >
                Add Money
              </Button>
              <Button 
                variant="outline"
                className="flex-1 bg-white bg-opacity-20 text-white hover:bg-white hover:bg-opacity-30 hover:text-white border-0"
                onClick={() => setShowWithdrawModal(true)}
              >
                Withdraw
              </Button>
            </div>
          </div>
          
          {/* Balance Breakdown */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-medium">Balance Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-primary bg-opacity-10 flex items-center justify-center">
                    <Wallet className="h-4 w-4 text-primary" />
                  </div>
                  <span>Deposited</span>
                </div>
                <span className="font-medium">₹{user?.balance || 0}</span>
              </div>
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-green-500 bg-opacity-10 flex items-center justify-center">
                    <Trophy className="h-4 w-4 text-green-500" />
                  </div>
                  <span>Winnings</span>
                </div>
                <span className="font-medium">₹{user?.winnings || 0}</span>
              </div>
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-accent bg-opacity-10 flex items-center justify-center">
                    <Gift className="h-4 w-4 text-accent" />
                  </div>
                  <span>Bonus</span>
                </div>
                <span className="font-medium">₹{user?.bonus || 0}</span>
              </div>
            </CardContent>
          </Card>
          
          {/* Recent Transactions */}
          <Card>
            <CardHeader className="pb-2 flex flex-row items-center justify-between">
              <CardTitle className="text-base font-medium">Recent Transactions</CardTitle>
              <Button 
                variant="link" 
                className="text-primary p-0 h-auto"
                onClick={() => setShowAllTransactionsModal(true)}
              >
                View All
              </Button>
            </CardHeader>
            <CardContent className="pt-0">
              {isLoading ? (
                <div className="flex justify-center py-4">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                </div>
              ) : !transactions || transactions.length === 0 ? (
                <div className="text-center py-4 text-neutral-500">
                  No transactions yet.
                </div>
              ) : (
                <div className="space-y-4">
                  {transactions.slice(0, 3).map((transaction) => (
                    <TransactionItem key={transaction.id} transaction={transaction} />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </PullToRefresh>
      
      <NavBar />
      
      {/* Modals */}
      <DepositModal 
        isOpen={showDepositModal} 
        onClose={() => setShowDepositModal(false)} 
      />
      
      <WithdrawModal 
        isOpen={showWithdrawModal} 
        onClose={() => setShowWithdrawModal(false)} 
        maxAmount={user?.winnings || 0}
      />

      {/* Balance Details Modal */}
      <Dialog open={showBalanceDetailsModal} onOpenChange={setShowBalanceDetailsModal}>
        <DialogContent className="max-w-[90%] rounded-lg">
          <DialogHeader>
            <DialogTitle className="text-center">Balance Details</DialogTitle>
            <DialogDescription className="text-center">
              Detailed breakdown of your wallet balance
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <Card className="overflow-hidden">
              <div className="bg-primary text-white p-4">
                <h3 className="text-center font-bold text-lg">Total Balance</h3>
                <p className="text-center text-3xl font-bold mt-2">₹{totalBalance}</p>
              </div>
            </Card>
            
            <div className="space-y-3">
              <div className="bg-white dark:bg-dark-card rounded-lg p-4 border border-gray-100 dark:border-gray-800">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary bg-opacity-10 flex items-center justify-center">
                      <Wallet className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">Deposited Balance</h4>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400">Available for contests</p>
                    </div>
                  </div>
                  <span className="font-bold text-lg">₹{user?.balance || 0}</span>
                </div>
              </div>
              
              <div className="bg-white dark:bg-dark-card rounded-lg p-4 border border-gray-100 dark:border-gray-800">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-green-500 bg-opacity-10 flex items-center justify-center">
                      <Trophy className="h-5 w-5 text-green-500" />
                    </div>
                    <div>
                      <h4 className="font-medium">Winnings</h4>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400">Can be withdrawn or used</p>
                    </div>
                  </div>
                  <span className="font-bold text-lg">₹{user?.winnings || 0}</span>
                </div>
              </div>
              
              <div className="bg-white dark:bg-dark-card rounded-lg p-4 border border-gray-100 dark:border-gray-800">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-accent bg-opacity-10 flex items-center justify-center">
                      <Gift className="h-5 w-5 text-accent" />
                    </div>
                    <div>
                      <h4 className="font-medium">Bonus</h4>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400">Use for contest entry fees</p>
                    </div>
                  </div>
                  <span className="font-bold text-lg">₹{user?.bonus || 0}</span>
                </div>
              </div>
            </div>
            
            <div className="mt-4 space-y-3">
              <h3 className="font-medium text-sm text-gray-500 dark:text-gray-400">How Balance Works</h3>
              <ul className="space-y-2 text-sm">
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span>You can use your deposited balance to join any contest</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span>Winnings can be withdrawn to your bank account</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span>Bonus amount can only be used for contest entry (up to 10% of entry fee)</span>
                </li>
              </ul>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* All Transactions Modal */}
      <Dialog open={showAllTransactionsModal} onOpenChange={setShowAllTransactionsModal}>
        <DialogContent className="max-w-[90%] rounded-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-center">All Transactions</DialogTitle>
            <DialogDescription className="text-center">
              Complete history of your wallet transactions
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-2">
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : !transactions || transactions.length === 0 ? (
              <div className="text-center py-8 text-neutral-500">
                No transactions yet.
              </div>
            ) : (
              <div className="space-y-4">
                {transactions.map((transaction) => (
                  <TransactionItem key={transaction.id} transaction={transaction} />
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}