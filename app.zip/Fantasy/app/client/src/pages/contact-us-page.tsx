import { Header } from "@/components/layout/header";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Phone, Mail, Clock, MessageSquare, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function ContactUsPage() {
  const { toast } = useToast();
  
  const goBack = () => {
    window.history.back();
  };
  
  const copyEmail = (email: string) => {
    navigator.clipboard.writeText(email);
    toast({
      title: "Email Copied",
      description: "Email address has been copied to clipboard",
    });
  };
  
  return (
    <div className="pb-20 min-h-screen bg-gray-50 dark:bg-dark-bg">
      <Header
        title="Contact Us"
        showBack
        backUrl="javascript:void(0)"
        onBackClick={goBack}
        showWallet={false}
        showNotification={false}
        className="bg-primary text-white"
      />

      <div className="p-4 max-w-[480px] mx-auto">
        <ScrollArea className="h-[calc(100vh-115px)] pr-3">
          <div className="mb-8 space-y-6">
            <section className="space-y-3">
              <div className="flex items-center gap-2">
                <Phone className="h-6 w-6 text-primary" />
                <h1 className="text-2xl font-bold">Contact Us</h1>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                We're here to help! If you have any questions, concerns, or feedback about 11byChatGPT, our team is ready to assist you.
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-xl font-bold">Email Support</h2>
              <p className="text-gray-700 dark:text-gray-300 mb-3">
                Our dedicated support team is available to assist you via email. Simply send your queries to the appropriate email address below.
              </p>
              <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-4 border border-gray-100 dark:border-gray-800">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">support@11bychatgpt.com</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">General Support</p>
                    </div>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => copyEmail("support@11bychatgpt.com")}
                  >
                    Copy
                  </Button>
                </div>
              </div>

              <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-4 border border-gray-100 dark:border-gray-800 mt-3">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">payments@11bychatgpt.com</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Payment Issues</p>
                    </div>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => copyEmail("payments@11bychatgpt.com")}
                  >
                    Copy
                  </Button>
                </div>
              </div>

              <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-4 border border-gray-100 dark:border-gray-800 mt-3">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">verification@11bychatgpt.com</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Account Verification</p>
                    </div>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => copyEmail("verification@11bychatgpt.com")}
                  >
                    Copy
                  </Button>
                </div>
              </div>
            </section>

            <section className="space-y-3 mt-6">
              <h2 className="text-xl font-bold">Raise a Support Ticket</h2>
              <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-lg border border-amber-200 dark:border-amber-900/30">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-medium text-amber-800 dark:text-amber-400">Coming Soon</p>
                    <p className="text-gray-700 dark:text-gray-300 mt-1">
                      Our support ticket system is currently under development. This feature will allow you to create, track, and manage support requests directly from your account.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-4 border border-gray-100 dark:border-gray-800 mt-4">
                <div className="flex items-center justify-center py-4 px-2">
                  <MessageSquare className="h-16 w-16 text-gray-300 dark:text-gray-600" />
                </div>
                <p className="text-center text-gray-500 dark:text-gray-400">
                  Support ticket system launching soon!
                </p>
                <p className="text-center text-sm text-gray-400 dark:text-gray-500 mt-1">
                  Please use email support in the meantime
                </p>
              </div>
            </section>

            <section className="space-y-3 mt-6">
              <h2 className="text-xl font-bold">Response Times</h2>
              <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-4 border border-gray-100 dark:border-gray-800">
                <div className="flex items-start gap-3">
                  <Clock className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-medium">Standard Email Response Times</p>
                    <ul className="mt-2 space-y-2">
                      <li className="flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-green-500"></div>
                        <p className="text-sm text-gray-700 dark:text-gray-300">General Inquiries: Within 24 hours</p>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-amber-500"></div>
                        <p className="text-sm text-gray-700 dark:text-gray-300">Payment Issues: Within 12 hours</p>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-red-500"></div>
                        <p className="text-sm text-gray-700 dark:text-gray-300">Account Security: Within 4 hours</p>
                      </li>
                    </ul>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-3">
                      Our support team is available 7 days a week from 9:00 AM to 6:00 PM IST.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            <section className="space-y-3 mt-6">
              <h2 className="text-xl font-bold">Frequently Asked Questions</h2>
              <p className="text-gray-700 dark:text-gray-300">
                Before contacting us, you might find your answer in our documentation:
              </p>
              <div className="space-y-2 mt-2">
                <Button variant="outline" className="w-full justify-start" onClick={() => window.location.href = "/how-to-play"}>
                  <span className="mr-2">🎮</span> How to Play
                </Button>
                <Button variant="outline" className="w-full justify-start" onClick={() => window.location.href = "/fantasy-points"}>
                  <span className="mr-2">📊</span> Fantasy Point System
                </Button>
                <Button variant="outline" className="w-full justify-start" onClick={() => window.location.href = "/legality"}>
                  <span className="mr-2">⚖️</span> Legality Information
                </Button>
              </div>
            </section>


          </div>
        </ScrollArea>
      </div>
    </div>
  );
}