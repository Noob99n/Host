import { useQuery } from "@tanstack/react-query";
import { Match } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { NavBar } from "@/components/layout/nav-bar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";
import { MatchCard } from "@/components/cricket/match-card";

export default function MatchesPage() {
  const { data: matches, isLoading, error } = useQuery<Match[]>({
    queryKey: ['/api/matches'],
  });

  // Filter matches by status
  const upcomingMatches = matches?.filter(match => match.status === 'upcoming') || [];
  const liveMatches = matches?.filter(match => match.status === 'live') || [];
  const completedMatches = matches?.filter(match => match.status === 'completed') || [];

  return (
    <div className="min-h-screen flex flex-col pb-16">
      <Header 
        title="Matches"
        showNotification={true}
        showWallet={true}
      />

      <Tabs defaultValue="upcoming">
        <TabsList className="w-full border-b border-neutral-200 dark:border-dark-border rounded-none bg-transparent">
          <TabsTrigger
            value="upcoming"
            className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
          >
            Upcoming
          </TabsTrigger>
          <TabsTrigger
            value="live"
            className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
          >
            Live
          </TabsTrigger>
          <TabsTrigger
            value="completed"
            className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
          >
            Completed
          </TabsTrigger>
        </TabsList>

        <div className="flex-1 p-4 space-y-4">
          <TabsContent value="upcoming" className="mt-0 space-y-4">
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : error ? (
              <div className="text-center py-8 text-red-500">
                Failed to load matches. Please try again.
              </div>
            ) : upcomingMatches.length === 0 ? (
              <div className="text-center py-8 text-neutral-500">
                No upcoming matches at the moment.
              </div>
            ) : (
              upcomingMatches.map((match) => (
                <MatchCard key={match.id} match={match} />
              ))
            )}
          </TabsContent>

          <TabsContent value="live" className="mt-0 space-y-4">
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : error ? (
              <div className="text-center py-8 text-red-500">
                Failed to load matches. Please try again.
              </div>
            ) : liveMatches.length === 0 ? (
              <div className="text-center py-8 text-neutral-500">
                No live matches at the moment.
              </div>
            ) : (
              liveMatches.map((match) => (
                <MatchCard key={match.id} match={match} />
              ))
            )}
          </TabsContent>

          <TabsContent value="completed" className="mt-0 space-y-4">
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : error ? (
              <div className="text-center py-8 text-red-500">
                Failed to load matches. Please try again.
              </div>
            ) : completedMatches.length === 0 ? (
              <div className="text-center py-8 text-neutral-500">
                No completed matches at the moment.
              </div>
            ) : (
              completedMatches.map((match) => (
                <MatchCard key={match.id} match={match} />
              ))
            )}
          </TabsContent>
        </div>
      </Tabs>

      <NavBar />
    </div>
  );
}
