import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Match, Player } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { NavBar } from "@/components/layout/nav-bar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { PlayerCard } from "@/components/cricket/player-card";
import { ProgressBar } from "@/components/ui/progress-bar";

export default function CreateTeamPage() {
  const { matchId } = useParams<{ matchId: string }>();
  const [, setLocation] = useLocation();
  const [selectedPlayers, setSelectedPlayers] = useState<Player[]>([]);
  const [activeRole, setActiveRole] = useState<string>("WK");
  
  const matchIdNum = parseInt(matchId);
  
  const { data: match, isLoading: isLoadingMatch } = useQuery<Match>({
    queryKey: [`/api/matches/${matchIdNum}`],
  });
  
  const { data: players, isLoading: isLoadingPlayers } = useQuery<Player[]>({
    queryKey: [`/api/matches/${matchIdNum}/players`, { team: null, role: activeRole }],
    enabled: !!matchIdNum,
  });
  
  const filterPlayersByRole = (role: string) => {
    setActiveRole(role);
  };
  
  const togglePlayerSelection = (player: Player) => {
    const isSelected = selectedPlayers.some(p => p.id === player.id);
    
    if (isSelected) {
      setSelectedPlayers(selectedPlayers.filter(p => p.id !== player.id));
    } else {
      // Check if max team players reached (11)
      if (selectedPlayers.length >= 11) {
        return; // Max reached
      }
      
      // Check role limits
      const roleCount = {
        WK: selectedPlayers.filter(p => p.role.includes("WK")).length,
        BAT: selectedPlayers.filter(p => p.role === "BAT").length,
        AR: selectedPlayers.filter(p => p.role === "AR").length,
        BOWL: selectedPlayers.filter(p => p.role === "BOWL").length,
      };
      
      const maxRoleLimits = { WK: 4, BAT: 6, AR: 4, BOWL: 6 };
      
      // If player's role has reached its limit
      if (player.role.includes("WK") && roleCount.WK >= maxRoleLimits.WK) {
        return;
      } else if (player.role === "BAT" && roleCount.BAT >= maxRoleLimits.BAT) {
        return;
      } else if (player.role === "AR" && roleCount.AR >= maxRoleLimits.AR) {
        return;
      } else if (player.role === "BOWL" && roleCount.BOWL >= maxRoleLimits.BOWL) {
        return;
      }
      
      setSelectedPlayers([...selectedPlayers, player]);
    }
  };
  
  if (isLoadingMatch) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!match) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <p className="text-lg text-neutral-600 dark:text-neutral-400">Match not found</p>
        <Button onClick={() => setLocation("/")} className="mt-4">
          Back to Home
        </Button>
      </div>
    );
  }
  
  // Calculate credits used
  const creditsUsed = selectedPlayers.reduce((sum, player) => sum + player.credits, 0);
  const creditsLeft = 100 - creditsUsed;
  
  // Count players by team
  const team1Count = selectedPlayers.filter(p => p.team === match.team1).length;
  const team2Count = selectedPlayers.filter(p => p.team === match.team2).length;
  
  // Count players by role
  const wkCount = selectedPlayers.filter(p => p.role.includes("WK")).length;
  const batCount = selectedPlayers.filter(p => p.role === "BAT").length;
  const arCount = selectedPlayers.filter(p => p.role === "AR").length;
  const bowlCount = selectedPlayers.filter(p => p.role === "BOWL").length;
  
  return (
    <div className="min-h-screen flex flex-col pb-16">
      <Header 
        showBack={true}
        backUrl={`/matches/${matchId}`}
        title="Create Team"
      />
      
      {/* Match Info Compact */}
      <div className="px-4 pb-2 flex justify-center">
        <div className="flex items-center gap-3">
          <span className="font-medium">{match.team1}</span>
          <span className="text-xs bg-neutral-100 dark:bg-dark-bg text-neutral-600 dark:text-neutral-400 px-2 py-1 rounded">vs</span>
          <span className="font-medium">{match.team2}</span>
        </div>
      </div>
      
      {/* Player Selection Info */}
      <div className="px-4 pb-3">
        <div className="flex justify-between text-sm mb-2">
          <span>Players Selected: <span className="font-medium text-primary">{selectedPlayers.length}/11</span></span>
          <span>Credits Left: <span className="font-medium">{creditsLeft.toFixed(1)}</span></span>
        </div>
        <ProgressBar value={selectedPlayers.length} max={11} className="mb-3" />
        <div className="flex justify-between gap-2 text-xs">
          <span className="bg-green-500 text-white px-2 py-0.5 rounded">{match.team1}: {team1Count}</span>
          <span className="bg-yellow-500 text-white px-2 py-0.5 rounded">{match.team2}: {team2Count}</span>
          <span>WK: {wkCount}/4</span>
          <span>BAT: {batCount}/6</span>
          <span>AR: {arCount}/4</span>
          <span>BOWL: {bowlCount}/6</span>
        </div>
      </div>
      
      <Tabs defaultValue="WK" onValueChange={filterPlayersByRole}>
        <TabsList className="w-full border-b border-neutral-200 dark:border-dark-border rounded-none bg-transparent">
          <TabsTrigger
            value="WK"
            className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
          >
            WK
          </TabsTrigger>
          <TabsTrigger
            value="BAT"
            className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
          >
            BAT
          </TabsTrigger>
          <TabsTrigger
            value="AR"
            className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
          >
            AR
          </TabsTrigger>
          <TabsTrigger
            value="BOWL"
            className="flex-1 py-3 data-[state=active]:tab-active data-[state=active]:shadow-none rounded-none data-[state=active]:bg-transparent"
          >
            BOWL
          </TabsTrigger>
        </TabsList>
        
        <div className="flex-1 p-4 space-y-3">
          {isLoadingPlayers ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : !players || players.length === 0 ? (
            <div className="text-center py-8 text-neutral-500">
              No players available for this role.
            </div>
          ) : (
            players.map((player) => (
              <PlayerCard 
                key={player.id} 
                player={player} 
                isSelected={selectedPlayers.some(p => p.id === player.id)}
                onToggle={() => togglePlayerSelection(player)}
              />
            ))
          )}
        </div>
      </Tabs>
      
      {/* Continue Button */}
      <div className="fixed bottom-20 left-0 right-0 p-4 max-w-[480px] mx-auto">
        <Button 
          disabled={selectedPlayers.length < 11} 
          className="w-full py-3 disabled:bg-neutral-300 disabled:text-neutral-500"
        >
          Continue
        </Button>
      </div>
      
      <NavBar />
    </div>
  );
}
