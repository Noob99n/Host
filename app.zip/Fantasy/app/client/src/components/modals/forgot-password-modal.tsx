import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

type ForgotPasswordModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

export function ForgotPasswordModal({ isOpen, onClose }: ForgotPasswordModalProps) {
  const { resetPasswordMutation, verifyPhoneMutation } = useAuth();
  
  // Step can be 'enter-phone' or 'set-password'
  const [step, setStep] = useState<'enter-phone' | 'set-password'>('enter-phone');
  const [phone, setPhone] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");

  // Handle phone verification
  const handleVerifyPhone = async () => {
    setError("");
    if (!phone.match(/^[6-9]\d{9}$/)) {
      setError("Please enter a valid 10-digit Indian mobile number");
      return;
    }

    try {
      // Verify if the phone number is registered
      await verifyPhoneMutation.mutateAsync({ phone });
      
      // If verification successful, proceed to next step
      setStep('set-password');
    } catch (error: any) {
      // Handle specific error for unregistered phone
      setError(error.message || "This phone number is not registered");
    }
  };

  // Handle password reset
  const handleResetPassword = async () => {
    setError("");
    
    // Validate passwords
    if (newPassword.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }
    
    if (newPassword !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    try {
      await resetPasswordMutation.mutateAsync({
        phone,
        otp: "000000", // Dummy OTP since we're not using OTP verification
        newPassword
      });
      
      // Close the modal after successful reset
      onClose();
      
      // Reset state for next time
      setStep('enter-phone');
      setPhone("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (error: any) {
      // Show the error from the server
      setError(error.message || "Failed to reset password");
      console.error("Failed to reset password:", error);
    }
  };

  const isPending = resetPasswordMutation.isPending || verifyPhoneMutation.isPending;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Reset Your Password</DialogTitle>
          <DialogDescription>
            {step === 'enter-phone' && "Enter your registered phone number to reset password."}
            {step === 'set-password' && "Create a new password for your account."}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          {error && (
            <div className="p-3 text-sm toast-message rounded-md">
              {error}
            </div>
          )}

          {/* Phone Input Step */}
          {step === 'enter-phone' && (
            <div className="space-y-2">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <span className="text-gray-500 dark:text-gray-400">+91</span>
                </div>
                <Input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  type="tel"
                  pattern="[0-9]{10}"
                  maxLength={10}
                  placeholder="10-digit mobile number"
                  className="pl-12"
                  disabled={isPending}
                />
              </div>
              <p className="text-xs text-muted-foreground">Enter your registered phone number</p>
            </div>
          )}

          {/* New Password Step */}
          {step === 'set-password' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="new-password" className="text-sm font-medium">
                  New Password
                </label>
                <Input
                  id="new-password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  type="password"
                  placeholder="New password"
                  disabled={isPending}
                />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="confirm-password" className="text-sm font-medium">
                  Confirm Password
                </label>
                <Input
                  id="confirm-password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  type="password"
                  placeholder="Confirm password"
                  disabled={isPending}
                />
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          {step === 'enter-phone' && (
            <Button onClick={handleVerifyPhone} disabled={isPending || !phone}>
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Verifying...
                </>
              ) : (
                "Continue"
              )}
            </Button>
          )}
          
          {step === 'set-password' && (
            <Button onClick={handleResetPassword} disabled={isPending || !newPassword || !confirmPassword}>
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Resetting...
                </>
              ) : (
                "Reset Password"
              )}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}