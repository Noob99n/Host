import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { formatDistanceToNow } from "date-fns";

type Referral = {
  id: number;
  name: string;
  joinedAt: Date;
  amount: number;
  avatarUrl: string;
};

type ReferralItemProps = {
  referral: Referral;
};

export function ReferralItem({ referral }: ReferralItemProps) {
  // Format the joined date
  const joinedDate = formatDistanceToNow(new Date(referral.joinedAt), { addSuffix: true });
  
  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    return name.split(" ").map(n => n[0]).join("").toUpperCase();
  };
  
  return (
    <div className="flex items-center justify-between p-3 border border-neutral-200 dark:border-dark-border rounded-lg">
      <div className="flex items-center">
        <Avatar className="w-10 h-10 mr-3">
          <AvatarImage src={referral.avatarUrl} alt={referral.name} />
          <AvatarFallback>{getInitials(referral.name)}</AvatarFallback>
        </Avatar>
        <div>
          <h4 className="font-medium">{referral.name}</h4>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            Joined {joinedDate}
          </p>
        </div>
      </div>
      <span className="text-green-500 font-medium">+₹{referral.amount}</span>
    </div>
  );
}
