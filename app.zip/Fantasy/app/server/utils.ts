/**
 * Generates a unique referral code based on user's name
 */
export function generateReferralCode(name: string): string {
  // Get first 2 characters of name (uppercase)
  const prefix = name.substring(0, 2).toUpperCase();
  
  // Generate random alphanumeric string (4 characters)
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let randomPart = '';
  
  for (let i = 0; i < 4; i++) {
    randomPart += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  
  // Add timestamp suffix (last 3 digits)
  const timestamp = Date.now().toString().slice(-3);
  
  return `${prefix}${randomPart}${timestamp}`;
}
