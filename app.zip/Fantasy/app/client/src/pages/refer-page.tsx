import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { NavBar } from "@/components/layout/nav-bar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Gift, Copy } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { ReferralItem } from "@/components/refer/referral-item";

export default function ReferPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Mock data for referrals - in a real app this would come from an API
  const referrals = [
    {
      id: 1,
      name: "Rahul S.",
      joinedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
      amount: 10,
      avatarUrl: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=120&h=120&q=80",
    },
    {
      id: 2,
      name: "Amit P.",
      joinedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
      amount: 10,
      avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=120&h=120&q=80",
    },
    {
      id: 3,
      name: "Priya M.",
      joinedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 1 week ago
      amount: 10,
      avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=120&h=120&q=80",
    },
  ];
  
  const copyReferralCode = () => {
    if (user?.referralCode) {
      navigator.clipboard.writeText(user.referralCode);
      toast({
        title: "Copied to clipboard",
        description: "Referral code copied to clipboard",
      });
    }
  };
  
  const shareReferralCode = () => {
    if (navigator.share && user?.referralCode) {
      navigator.share({
        title: "Join 11byChatGPT",
        text: `Join me on 11byChatGPT Fantasy Cricket and get ₹10 bonus! Use my referral code: ${user.referralCode}`,
        url: window.location.origin,
      }).catch(error => {
        console.log("Error sharing:", error);
      });
    } else {
      copyReferralCode();
      toast({
        title: "Share",
        description: "Copy the code and share it with your friends!",
      });
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col pb-16">
      <Header 
        showBack={true}
        backUrl="/"
        title="Refer & Earn"
      />
      
      <div className="flex-1 p-4 space-y-6">
        {/* Hero Section */}
        <div className="bg-gradient-to-b from-accent-light to-accent rounded-xl text-center p-6 text-white">
          <div className="w-16 h-16 bg-white bg-opacity-20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-3">
            <Gift className="text-white h-8 w-8" />
          </div>
          <h2 className="text-2xl font-semibold mb-1">Invite Friends & Earn</h2>
          <p className="opacity-90 mb-4">Get ₹10 for each friend who joins</p>
          <div className="bg-white bg-opacity-20 backdrop-blur-sm rounded-lg p-4 mb-4">
            <p className="text-sm mb-2">Your Referral Code</p>
            <div className="flex items-center justify-center">
              <span className="text-xl font-bold tracking-widest">{user?.referralCode || "LOADING"}</span>
              <Button 
                variant="outline" 
                size="icon" 
                className="ml-3 p-1.5 bg-white rounded-full text-accent hover:bg-neutral-100 hover:text-accent-dark border-0"
                onClick={copyReferralCode}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <Button 
            onClick={shareReferralCode}
            className="w-full bg-white text-accent hover:bg-neutral-100 hover:text-accent-dark"
          >
            Share Now
          </Button>
        </div>
        
        {/* How It Works */}
        <Card>
          <CardHeader>
            <CardTitle>How It Works</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="flex items-start">
              <div className="w-8 h-8 rounded-full bg-primary bg-opacity-10 flex items-center justify-center flex-shrink-0 mr-3">
                <span className="text-primary font-medium">1</span>
              </div>
              <div>
                <h4 className="font-medium mb-1">Share your code</h4>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  Share your unique referral code with friends via WhatsApp, SMS, or email
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="w-8 h-8 rounded-full bg-primary bg-opacity-10 flex items-center justify-center flex-shrink-0 mr-3">
                <span className="text-primary font-medium">2</span>
              </div>
              <div>
                <h4 className="font-medium mb-1">Friend joins using your code</h4>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  They sign up and enter your referral code during registration
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="w-8 h-8 rounded-full bg-primary bg-opacity-10 flex items-center justify-center flex-shrink-0 mr-3">
                <span className="text-primary font-medium">3</span>
              </div>
              <div>
                <h4 className="font-medium mb-1">Both of you get rewarded</h4>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  You get ₹10 in your wallet and your friend gets ₹10 bonus cash
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Referral Stats */}
        <Card>
          <CardHeader>
            <CardTitle>Your Referrals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="bg-neutral-100 dark:bg-dark-bg rounded-lg p-3 text-center">
                <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-1">Total Invited</p>
                <p className="text-xl font-semibold">{referrals.length}</p>
              </div>
              <div className="bg-neutral-100 dark:bg-dark-bg rounded-lg p-3 text-center">
                <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-1">Total Earned</p>
                <p className="text-xl font-semibold">₹{referrals.reduce((sum, r) => sum + r.amount, 0)}</p>
              </div>
            </div>
            
            <div className="space-y-3">
              {referrals.map((referral) => (
                <ReferralItem key={referral.id} referral={referral} />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
      
      <NavBar />
    </div>
  );
}
