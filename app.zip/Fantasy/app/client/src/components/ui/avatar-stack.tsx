import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

type AvatarStackProps = {
  avatars: {
    src: string;
    alt: string;
    fallback: string;
  }[];
  max?: number;
  size?: number;
  className?: string;
  label?: string;
};

export function AvatarStack({
  avatars,
  max = 3,
  size = 24,
  className = "",
  label,
}: AvatarStackProps) {
  const displayAvatars = avatars.slice(0, max);
  const remainingCount = avatars.length - max;

  return (
    <div className="flex items-center">
      <div className={`flex ${className}`} style={{ marginRight: `${size / 2.4}px` }}>
        {displayAvatars.map((avatar, index) => (
          <Avatar
            key={index}
            className="border-2 border-white dark:border-dark-card"
            style={{
              width: `${size}px`,
              height: `${size}px`,
              marginLeft: index > 0 ? `-${size * 0.4}px` : "0",
              zIndex: displayAvatars.length - index,
            }}
          >
            <AvatarImage src={avatar.src} alt={avatar.alt} />
            <AvatarFallback>{avatar.fallback}</AvatarFallback>
          </Avatar>
        ))}
      </div>
      {remainingCount > 0 && (
        <span className="text-xs text-neutral-600 dark:text-neutral-400">
          +{remainingCount} {label || ""}
        </span>
      )}
    </div>
  );
}
