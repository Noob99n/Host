import { Link, useLocation } from "wouter";
import { LoaderPinwheel, Home, Trophy, Users, BarChart3, MoreHorizontal } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { path: "/", icon: Home, label: "Home" },
  { path: "/matches", icon: Trophy, label: "Matches" },
  { path: "/my-teams", icon: Users, label: "My Teams" },
  { path: "/leaderboard", icon: BarChart3, label: "Leaderboard" },
  { path: "/more", icon: MoreHorizontal, label: "More" },
];

export function NavBar() {
  const [location] = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-dark-card border-t border-neutral-200 dark:border-dark-border flex justify-around p-2 max-w-[480px] mx-auto z-10">
      {navItems.map((item) => {
        const isActive = item.path === location || 
          (item.path === "/matches" && location.startsWith("/matches/")) ||
          (item.path === "/my-teams" && location.startsWith("/create-team/"));
        
        return (
          <Link 
            key={item.path} 
            href={item.path}
            className={cn(
              "p-2 flex flex-col items-center",
              isActive 
                ? "nav-item active" 
                : "nav-item text-neutral-600 dark:text-neutral-400"
            )}
          >
            <item.icon className="text-xl h-6 w-6" />
            <span className="nav-text text-xs mt-1">{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
