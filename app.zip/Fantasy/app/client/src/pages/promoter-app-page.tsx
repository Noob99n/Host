import { Header } from "@/components/layout/header";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Shield, Download, Trophy, Gift, Users, Smartphone, CreditCard, Zap } from "lucide-react";
import { AlertTriangle } from "lucide-react";

export default function PromoterAppPage() {
  const goBack = () => {
    window.history.back();
  };
  
  return (
    <div className="pb-20 min-h-screen bg-gray-50 dark:bg-dark-bg">
      <Header
        title="Promoter App"
        showBack
        backUrl="javascript:void(0)"
        onBackClick={goBack}
        showWallet={false}
        showNotification={false}
        className="bg-primary text-white"
      />

      <div className="p-4 max-w-[480px] mx-auto">
        <ScrollArea className="h-[calc(100vh-115px)] pr-3">
          <div className="mb-8 space-y-6">
            <section className="space-y-3">
              <div className="flex items-center gap-2">
                <Megaphone className="h-6 w-6 text-primary" />
                <h1 className="text-2xl font-bold">Promoter App</h1>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                Become a promoter for 11byChatGPT and earn rewards by inviting new users to the platform. Our promoter app provides you with all the tools you need to successfully promote our fantasy cricket platform.
              </p>
            </section>

            {/* Coming Soon Notice */}
            <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-lg border border-amber-200 dark:border-amber-900/30">
              <div className="flex items-start gap-3">
                <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-amber-800 dark:text-amber-400">Coming Soon</p>
                  <p className="text-gray-700 dark:text-gray-300 mt-1">
                    Our dedicated Promoter App is currently under development. This separate application will provide enhanced tools for our promoters to maximize their earnings.
                  </p>
                </div>
              </div>
            </div>

            {/* Download Buttons (Coming Soon) */}
            <section className="space-y-3 mt-6">
              <h2 className="text-xl font-bold">Download The App</h2>
              <p className="text-gray-700 dark:text-gray-300 mb-3">
                The Promoter App will be available soon on Android and iOS platforms.
              </p>
              
              <div className="grid grid-cols-2 gap-3">
                <Button disabled className="bg-gray-200 hover:bg-gray-200 text-gray-500 py-6">
                  <div className="flex flex-col items-center">
                    <Download className="h-6 w-6 mb-1" />
                    <span>Android</span>
                    <span className="text-xs mt-1">Coming Soon</span>
                  </div>
                </Button>
                
                <Button disabled className="bg-gray-200 hover:bg-gray-200 text-gray-500 py-6">
                  <div className="flex flex-col items-center">
                    <Download className="h-6 w-6 mb-1" />
                    <span>iOS</span>
                    <span className="text-xs mt-1">Coming Soon</span>
                  </div>
                </Button>
              </div>
            </section>

            {/* Benefits */}
            <section className="space-y-3 mt-6">
              <h2 className="text-xl font-bold">Promoter Benefits</h2>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-4 border border-gray-100 dark:border-gray-800">
                  <div className="flex flex-col items-center text-center">
                    <CreditCard className="h-10 w-10 text-primary mb-2" />
                    <p className="font-medium">Commission</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Earn up to 5% on every deposit
                    </p>
                  </div>
                </div>
                
                <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-4 border border-gray-100 dark:border-gray-800">
                  <div className="flex flex-col items-center text-center">
                    <Trophy className="h-10 w-10 text-primary mb-2" />
                    <p className="font-medium">Bonuses</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Monthly rewards for top promoters
                    </p>
                  </div>
                </div>
                
                <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-4 border border-gray-100 dark:border-gray-800">
                  <div className="flex flex-col items-center text-center">
                    <Users className="h-10 w-10 text-primary mb-2" />
                    <p className="font-medium">Network</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Build your referral network
                    </p>
                  </div>
                </div>
                
                <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-4 border border-gray-100 dark:border-gray-800">
                  <div className="flex flex-col items-center text-center">
                    <Zap className="h-10 w-10 text-primary mb-2" />
                    <p className="font-medium">Fast Payouts</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Weekly commission transfers
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* How It Works */}
            <section className="space-y-3 mt-6">
              <h2 className="text-xl font-bold">How It Works</h2>
              <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-4 border border-gray-100 dark:border-gray-800">
                <ol className="space-y-4 relative before:absolute before:top-2 before:bottom-2 before:left-3 before:w-0.5 before:bg-gray-200 dark:before:bg-gray-700">
                  <li className="relative pl-8">
                    <div className="absolute left-0 flex items-center justify-center w-6 h-6 rounded-full bg-primary text-white text-xs font-bold">1</div>
                    <p className="font-medium">Register as a Promoter</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Download the app and complete the registration process
                    </p>
                  </li>
                  
                  <li className="relative pl-8">
                    <div className="absolute left-0 flex items-center justify-center w-6 h-6 rounded-full bg-primary text-white text-xs font-bold">2</div>
                    <p className="font-medium">Get Your Referral Code</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Receive a unique code and promotional materials
                    </p>
                  </li>
                  
                  <li className="relative pl-8">
                    <div className="absolute left-0 flex items-center justify-center w-6 h-6 rounded-full bg-primary text-white text-xs font-bold">3</div>
                    <p className="font-medium">Invite Players</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Share your code with potential players
                    </p>
                  </li>
                  
                  <li className="relative pl-8">
                    <div className="absolute left-0 flex items-center justify-center w-6 h-6 rounded-full bg-primary text-white text-xs font-bold">4</div>
                    <p className="font-medium">Earn Commissions</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      Get paid when your referrals make deposits
                    </p>
                  </li>
                </ol>
              </div>
            </section>

            {/* Requirements */}
            <section className="space-y-3 mt-6">
              <h2 className="text-xl font-bold">Requirements</h2>
              <div className="bg-white dark:bg-dark-card rounded-lg shadow-sm p-4 border border-gray-100 dark:border-gray-800">
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <Shield className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Minimum Age</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        You must be at least 18 years old
                      </p>
                    </div>
                  </li>
                  
                  <li className="flex items-start gap-3">
                    <Shield className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Bank Account</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Valid bank account for commission payments
                      </p>
                    </div>
                  </li>
                  
                  <li className="flex items-start gap-3">
                    <Shield className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Identification</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Government-issued ID for verification
                      </p>
                    </div>
                  </li>
                  
                  <li className="flex items-start gap-3">
                    <Shield className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Smart Phone</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Android or iOS device to use the app
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            </section>

            {/* Join Waitlist */}
            <section className="space-y-3 mt-6">
              <h2 className="text-xl font-bold">Join the Waitlist</h2>
              <p className="text-gray-700 dark:text-gray-300">
                Be among the first to access our Promoter App when it launches. Join our waitlist today!
              </p>
              <Button className="w-full py-6 bg-primary hover:bg-primary/90 mt-2">
                Join Waitlist
              </Button>
            </section>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}

// Add Megaphone icon for the main title
function Megaphone({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M3 11l18-5v12L3 14v-3z"></path>
      <path d="M11.6 16.8a3 3 0 11-5.8-1.6"></path>
    </svg>
  );
}