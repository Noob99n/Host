import { Header } from "@/components/layout/header";
import { ScrollArea } from "@/components/ui/scroll-area";
import { HelpCircle, Users, Trophy, Zap, Clock, ShieldCheck } from "lucide-react";

export default function HowToPlayPage() {
  const goBack = () => {
    window.history.back();
  };
  
  return (
    <div className="pb-20 min-h-screen bg-gray-50 dark:bg-dark-bg">
      <Header
        title="How To Play"
        showBack
        backUrl="javascript:void(0)"
        onBackClick={goBack}
        showWallet={false}
        showNotification={false}
        className="bg-primary text-white"
      />

      <div className="p-4 max-w-[480px] mx-auto">
        <ScrollArea className="h-[calc(100vh-115px)] pr-3">
          <div className="mb-8 space-y-6">
            <section className="space-y-3">
              <div className="flex items-center gap-2">
                <HelpCircle className="h-6 w-6 text-primary" />
                <h1 className="text-2xl font-bold">How To Play</h1>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                Welcome to 11byChatGPT, your ultimate fantasy cricket platform! This guide will walk you through the process of playing fantasy cricket on our platform and help you get started with creating your own fantasy teams.
              </p>
            </section>

            <section className="space-y-3 border-l-4 border-primary pl-4">
              <div className="flex items-center gap-2">
                <div className="bg-primary text-white rounded-full h-6 w-6 flex items-center justify-center font-bold">1</div>
                <h2 className="text-xl font-bold">Register & Login</h2>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                Start by creating an account on 11byChatGPT. You can register using your email address and creating a password. Once registered, verify your account and log in to access all features.
              </p>
              <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg">
                <p className="text-sm text-gray-700 dark:text-gray-300 font-medium">Tips:</p>
                <ul className="list-disc pl-5 text-sm text-gray-700 dark:text-gray-300">
                  <li>Make sure to verify your email for account security</li>
                  <li>Complete your profile to unlock all features</li>
                </ul>
              </div>
            </section>

            <section className="space-y-3 border-l-4 border-primary pl-4">
              <div className="flex items-center gap-2">
                <div className="bg-primary text-white rounded-full h-6 w-6 flex items-center justify-center font-bold">2</div>
                <h2 className="text-xl font-bold">Select a Match</h2>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                Browse upcoming cricket matches on the home page or matches section. Select a match that you want to create a fantasy team for. You'll see details including match time, venue, and the teams playing.
              </p>
              <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg">
                <p className="text-sm text-gray-700 dark:text-gray-300 font-medium">Remember:</p>
                <ul className="list-disc pl-5 text-sm text-gray-700 dark:text-gray-300">
                  <li>Team creation remains open until the match starts</li>
                  <li>Matches are categorized by format (T20, ODI, Test)</li>
                </ul>
              </div>
            </section>

            <section className="space-y-3 border-l-4 border-primary pl-4">
              <div className="flex items-center gap-2">
                <div className="bg-primary text-white rounded-full h-6 w-6 flex items-center justify-center font-bold">3</div>
                <h2 className="text-xl font-bold">Create Your Team</h2>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                After selecting a match, tap on "Create Team" to build your fantasy cricket team. You need to select 11 players within a 100 credit budget while following these composition rules:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>1-4 Wicket-keepers</li>
                <li>3-6 Batsmen</li>
                <li>1-4 All-rounders</li>
                <li>3-6 Bowlers</li>
              </ul>
              <p className="text-gray-700 dark:text-gray-300">
                You can select a maximum of 7 players from one team. Each player has a credit value based on their performance and popularity.
              </p>
              <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg">
                <p className="text-sm text-gray-700 dark:text-gray-300 font-medium">Strategy Tips:</p>
                <ul className="list-disc pl-5 text-sm text-gray-700 dark:text-gray-300">
                  <li>Balance your team with players from both sides</li>
                  <li>Consider pitch conditions and player form</li>
                  <li>Don't spend all credits on star players</li>
                </ul>
              </div>
            </section>

            <section className="space-y-3 border-l-4 border-primary pl-4">
              <div className="flex items-center gap-2">
                <div className="bg-primary text-white rounded-full h-6 w-6 flex items-center justify-center font-bold">4</div>
                <h2 className="text-xl font-bold">Select Captain & Vice Captain</h2>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                After selecting your 11 players, you need to choose a Captain and Vice Captain:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li><strong>Captain:</strong> Gets 2x points for their performance</li>
                <li><strong>Vice Captain:</strong> Gets 1.5x points for their performance</li>
              </ul>
              <p className="text-gray-700 dark:text-gray-300">
                This is a crucial strategic decision as it can significantly impact your total points.
              </p>
              <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg">
                <p className="text-sm text-gray-700 dark:text-gray-300 font-medium">Pro Tip:</p>
                <p className="text-sm text-gray-700 dark:text-gray-300">
                  Choose players who are likely to be involved throughout the match (all-rounders or top-order batsmen) as your Captain or Vice Captain for maximum points.
                </p>
              </div>
            </section>

            <section className="space-y-3 border-l-4 border-primary pl-4">
              <div className="flex items-center gap-2">
                <div className="bg-primary text-white rounded-full h-6 w-6 flex items-center justify-center font-bold">5</div>
                <h2 className="text-xl font-bold">Join Contests</h2>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                After creating your team, you can join various contests:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li><strong>Mega Contests:</strong> Large prize pools with thousands of participants</li>
                <li><strong>Small Contests:</strong> Fewer participants with better winning odds</li>
                <li><strong>Head-to-Head:</strong> Compete directly against one opponent</li>
                <li><strong>Free Contests:</strong> No entry fee, perfect for beginners</li>
              </ul>
              <p className="text-gray-700 dark:text-gray-300">
                Each contest has different entry fees and prize structures. You can join multiple contests with the same team.
              </p>
              <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg">
                <p className="text-sm text-gray-700 dark:text-gray-300 font-medium">Tip:</p>
                <p className="text-sm text-gray-700 dark:text-gray-300">
                  Start with free or low-entry contests to gain experience before joining high-value contests.
                </p>
              </div>
            </section>

            <section className="space-y-3 border-l-4 border-primary pl-4">
              <div className="flex items-center gap-2">
                <div className="bg-primary text-white rounded-full h-6 w-6 flex items-center justify-center font-bold">6</div>
                <h2 className="text-xl font-bold">Earn Points During the Match</h2>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                During the actual cricket match, your selected players earn points based on their real-life performance. Points are awarded for:
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>Runs scored</li>
                <li>Wickets taken</li>
                <li>Catches & stumpings</li>
                <li>Run-outs</li>
                <li>Economy rate (for bowlers)</li>
                <li>Strike rate (for batsmen)</li>
                <li>Bonus points for exceptional performances</li>
              </ul>
              <p className="text-gray-700 dark:text-gray-300">
                You can track your team's performance and standing in real-time during the match.
              </p>
              <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg">
                <p className="text-sm text-gray-700 dark:text-gray-300 font-medium">Note:</p>
                <p className="text-sm text-gray-700 dark:text-gray-300">
                  See our detailed "Fantasy Point System" page for complete information on how points are calculated.
                </p>
              </div>
            </section>

            <section className="space-y-3 border-l-4 border-primary pl-4">
              <div className="flex items-center gap-2">
                <div className="bg-primary text-white rounded-full h-6 w-6 flex items-center justify-center font-bold">7</div>
                <h2 className="text-xl font-bold">Winning & Withdrawals</h2>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                At the end of the match, final rankings are determined based on total points scored. If your team ranks within the prize pool, winnings are credited to your 11byChatGPT wallet.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                You can withdraw your winnings to your bank account through the wallet section. Verification of your account with PAN card and bank details is required for withdrawals.
              </p>
              <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg">
                <p className="text-sm text-gray-700 dark:text-gray-300 font-medium">Important:</p>
                <ul className="list-disc pl-5 text-sm text-gray-700 dark:text-gray-300">
                  <li>TDS (30%) is applicable on winnings above ₹10,000</li>
                  <li>Verify your account to enable withdrawals</li>
                  <li>Minimum withdrawal amount is ₹200</li>
                </ul>
              </div>
            </section>

            <section className="space-y-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-6 w-6 text-green-600" />
                <h2 className="text-xl font-bold">Responsible Gaming</h2>
              </div>
              <p className="text-gray-700 dark:text-gray-300">
                At 11byChatGPT, we encourage responsible gaming. Fantasy cricket is a game of skill that requires knowledge of cricket, strategic thinking, and careful team selection.
              </p>
              <ul className="list-disc pl-5 text-gray-700 dark:text-gray-300 space-y-1">
                <li>Set a budget for contest entries</li>
                <li>Play within your means</li>
                <li>Remember it's a form of entertainment</li>
                <li>Use our deposit limit tools if needed</li>
              </ul>
            </section>

            <section className="bg-primary/10 p-4 rounded-lg border border-primary/20">
              <h2 className="text-lg font-bold mb-2">Ready to Play?</h2>
              <p className="text-gray-700 dark:text-gray-300">
                Now that you know how to play fantasy cricket on 11byChatGPT, explore upcoming matches and start creating your winning teams! Remember, the more you know about cricket and the players, the better your chances of winning.
              </p>
              <p className="text-gray-700 dark:text-gray-300 mt-2">
                Good luck and enjoy the game!
              </p>
            </section>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}