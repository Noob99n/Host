import { useState, useEffect } from "react";
import { Header } from "@/components/layout/header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, Trophy, Gift, User, Info, CheckCircle, Calendar, Megaphone } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useQuery, useQueryClient } from "@tanstack/react-query";

// Mock notification data - in a real app this would come from the API
const mockNotifications = [
  {
    id: 1,
    type: "contest",
    title: "Contest reminder",
    message: "IND vs AUS match starts in 1 hour. Don't forget to join contests!",
    date: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
    read: false,
  },
  {
    id: 2,
    type: "wallet",
    title: "Money added successfully",
    message: "₹500 has been added to your wallet successfully.",
    date: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
    read: false,
  },
  {
    id: 3,
    type: "referral",
    title: "Referral bonus received",
    message: "You received ₹50 bonus as your friend Amit P. joined using your referral code.",
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
    read: true,
  },
  {
    id: 4,
    type: "match",
    title: "New match added",
    message: "ENG vs SA T20 match has been added. Create your team now!",
    date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
    read: true,
  },
  {
    id: 5,
    type: "promo",
    title: "Weekend Special Offer",
    message: "Use code WEEKEND50 to get 50% bonus on your first deposit this weekend!",
    date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
    read: true,
  },
];

type NotificationType = "contest" | "wallet" | "referral" | "match" | "promo";

function getNotificationIcon(type: NotificationType) {
  switch (type) {
    case "contest":
      return <Trophy className="h-5 w-5 text-primary" />;
    case "wallet":
      return <CheckCircle className="h-5 w-5 text-green-500" />;
    case "referral":
      return <Gift className="h-5 w-5 text-accent" />;
    case "match":
      return <Calendar className="h-5 w-5 text-blue-500" />;
    case "promo":
      return <Megaphone className="h-5 w-5 text-purple-500" />;
    default:
      return <Info className="h-5 w-5 text-neutral-500" />;
  }
}

export default function NotificationsPage() {
  const queryClient = useQueryClient();
  
  // Fetch notifications from API
  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/notifications"],
    queryFn: async () => {
      const res = await fetch("/api/notifications");
      if (!res.ok) {
        throw new Error("Failed to fetch notifications");
      }
      return res.json();
    },
    // Fallback to empty array if error occurs
    initialData: [],
  });
  
  // Manage local state for notifications (to handle read/unread status changes)
  const [notifications, setNotifications] = useState<any[]>([]);
  
  // Update local state when API data changes
  useEffect(() => {
    if (data && data.length > 0) {
      setNotifications(data);
    } else {
      // Fallback to mock data if API returns empty 
      setNotifications(mockNotifications);
    }
  }, [data]);
  
  // Filter notifications
  const unreadNotifications = notifications.filter(n => !n.read);
  const allNotifications = notifications;
  
  // Mark all notifications as read
  const markAllAsRead = () => {
    setNotifications(
      notifications.map(notification => ({
        ...notification,
        read: true
      }))
    );
    
    // Update notification count in the header
    queryClient.setQueryData(["/api/get-notification-count"], { count: 0 });
    
    // In a real app, you would make an API call to update notification status on the server
    // fetch("/api/notifications/mark-all-read", { method: "POST" });
  };
  
  // Mark a single notification as read
  const markAsRead = (id: number) => {
    // Find if this was previously unread
    const wasUnread = notifications.find(n => n.id === id && !n.read);
    
    // Update local state
    setNotifications(
      notifications.map(notification => 
        notification.id === id
          ? { ...notification, read: true }
          : notification
      )
    );
    
    // If it was unread, update notification count in the header
    if (wasUnread) {
      const currentCount = (queryClient.getQueryData(["/api/get-notification-count"]) as any)?.count || 0;
      if (currentCount > 0) {
        queryClient.setQueryData(["/api/get-notification-count"], { count: currentCount - 1 });
      }
    }
    
    // In a real app, you would make an API call to update notification status on the server
    // fetch(`/api/notifications/${id}/mark-read`, { method: "POST" });
  };
  
  // Clear all notifications
  const clearAll = () => {
    setNotifications([]);
    
    // Also update notification count in the header
    queryClient.setQueryData(["/api/get-notification-count"], { count: 0 });
    
    // In a real app, you would make an API call to clear notifications on the server
    // fetch("/api/notifications/clear-all", { method: "POST" });
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header 
        showBack={true}
        backUrl="/"
        title="Notifications"
      />
      
      <Tabs defaultValue="all">
        <div className="flex justify-between items-center px-4 py-2 border-b border-neutral-200 dark:border-dark-border">
          <TabsList className="bg-transparent p-0">
            <TabsTrigger
              value="all"
              className="data-[state=active]:bg-transparent data-[state=active]:shadow-none rounded-none px-2 py-1"
            >
              All
            </TabsTrigger>
            <TabsTrigger
              value="unread"
              className="data-[state=active]:bg-transparent data-[state=active]:shadow-none rounded-none px-2 py-1"
            >
              Unread ({unreadNotifications.length})
            </TabsTrigger>
          </TabsList>
          
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={markAllAsRead}>
              Mark all read
            </Button>
            <Button variant="ghost" size="sm" onClick={clearAll}>
              Clear all
            </Button>
          </div>
        </div>
        
        <TabsContent value="all" className="p-4 space-y-3 mt-0">
          {allNotifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="w-16 h-16 bg-neutral-100 dark:bg-dark-bg rounded-full flex items-center justify-center mb-4">
                <Bell className="h-8 w-8 text-neutral-500" />
              </div>
              <h3 className="text-lg font-medium mb-2">No Notifications</h3>
              <p className="text-neutral-600 dark:text-neutral-400 max-w-xs">
                You're all caught up! We'll notify you when there's something new.
              </p>
            </div>
          ) : (
            allNotifications.map((notification) => (
              <Card 
                key={notification.id} 
                className={`cursor-pointer ${!notification.read ? 'border-l-4 border-l-primary' : ''}`}
                onClick={() => markAsRead(notification.id)}
              >
                <CardContent className="p-3 flex">
                  <div className="w-10 h-10 rounded-full bg-neutral-100 dark:bg-dark-bg flex items-center justify-center mr-3 flex-shrink-0">
                    {getNotificationIcon(notification.type as NotificationType)}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <h3 className={`font-medium ${!notification.read ? 'text-primary' : ''}`}>
                        {notification.title}
                      </h3>
                      <span className="text-xs text-neutral-500 dark:text-neutral-400 ml-2">
                        {formatDistanceToNow(new Date(notification.date), { addSuffix: true })}
                      </span>
                    </div>
                    <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-1">
                      {notification.message}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
        
        <TabsContent value="unread" className="p-4 space-y-3 mt-0">
          {unreadNotifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="w-16 h-16 bg-neutral-100 dark:bg-dark-bg rounded-full flex items-center justify-center mb-4">
                <CheckCircle className="h-8 w-8 text-green-500" />
              </div>
              <h3 className="text-lg font-medium mb-2">All Caught Up!</h3>
              <p className="text-neutral-600 dark:text-neutral-400 max-w-xs">
                You have no unread notifications at the moment.
              </p>
            </div>
          ) : (
            unreadNotifications.map((notification) => (
              <Card 
                key={notification.id} 
                className="border-l-4 border-l-primary cursor-pointer"
                onClick={() => markAsRead(notification.id)}
              >
                <CardContent className="p-3 flex">
                  <div className="w-10 h-10 rounded-full bg-neutral-100 dark:bg-dark-bg flex items-center justify-center mr-3 flex-shrink-0">
                    {getNotificationIcon(notification.type as NotificationType)}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <h3 className="font-medium text-primary">
                        {notification.title}
                      </h3>
                      <span className="text-xs text-neutral-500 dark:text-neutral-400 ml-2">
                        {formatDistanceToNow(new Date(notification.date), { addSuffix: true })}
                      </span>
                    </div>
                    <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-1">
                      {notification.message}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
