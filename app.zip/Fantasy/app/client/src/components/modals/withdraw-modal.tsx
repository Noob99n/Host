import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Building, BadgeIndianRupee } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type WithdrawModalProps = {
  isOpen: boolean;
  onClose: () => void;
  maxAmount: number;
};

export function WithdrawModal({ isOpen, onClose, maxAmount }: WithdrawModalProps) {
  const [amount, setAmount] = useState(maxAmount.toString());
  const [withdrawMethod, setWithdrawMethod] = useState("bank");
  const { toast } = useToast();

  const withdrawMutation = useMutation({
    mutationFn: async ({ amount, withdrawMethod }: { amount: number; withdrawMethod: string }) => {
      const res = await apiRequest("POST", "/api/wallet/withdraw", {
        amount,
        withdrawMethod,
      });
      return await res.json();
    },
    onSuccess: (data) => {
      // Immediately update the cache with the new user data
      queryClient.setQueryData(['/api/user'], data.user);
      
      // Also update transaction data
      const existingTransactions = queryClient.getQueryData<any[]>(['/api/wallet/transactions']) || [];
      queryClient.setQueryData(['/api/wallet/transactions'], [data.transaction, ...existingTransactions]);
      
      toast({
        title: "Withdraw request successful",
        description: `Your withdrawal of ₹${amount} has been initiated.`,
      });
      
      onClose();
      
      // Force page reload to prevent any possible glitch
      setTimeout(() => {
        window.location.reload();
      }, 1000); // Reload after 1 second to allow toast to be shown
    },
    onError: (error: Error) => {
      toast({
        title: "Withdraw failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleWithdraw = () => {
    const amountNum = parseInt(amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }

    if (amountNum > maxAmount) {
      toast({
        title: "Insufficient balance",
        description: `Maximum amount available for withdrawal is ₹${maxAmount}`,
        variant: "destructive",
      });
      return;
    }

    // Get verification status to check if user has the required verifications
    const verifications = queryClient.getQueryData<any>(['/api/verify/status']);
    
    // Ensure PAN Card and at least one of UPI or bank account is verified
    const isPanVerified = verifications?.pan?.status === "approved";
    const isUpiVerified = verifications?.upi?.status === "approved";
    const isBankVerified = verifications?.bank?.status === "approved";

    // User must have PAN and either UPI or Bank verified
    const isFullyVerified = isPanVerified && (isUpiVerified || isBankVerified);
    
    // Only redirect if verification status data exists and user is not fully verified
    if (verifications && !isFullyVerified) {
      // Check which requirement is missing
      let missingVerification = "";
      if (!isPanVerified) missingVerification += "PAN card";
      if (!isUpiVerified && !isBankVerified) {
        missingVerification += missingVerification ? " and UPI/Bank Account" : "UPI or Bank Account";
      }
      
      toast({
        title: "Account verification required",
        description: `Please verify your ${missingVerification} before withdrawing money`,
        variant: "destructive",
      });
      onClose();
      window.location.href = '/verify-account';
      return;
    }

    withdrawMutation.mutate({ amount: amountNum, withdrawMethod });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium">Withdraw Money</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 pt-2">
          <div className="bg-neutral-100 dark:bg-dark-bg rounded-lg p-3 mb-4">
            <p className="text-sm text-neutral-600 dark:text-neutral-400">Available for withdrawal</p>
            <p className="font-semibold text-lg">₹{maxAmount}</p>
            <p className="text-xs text-neutral-500 dark:text-neutral-400">Only winnings can be withdrawn</p>
          </div>

          <div>
            <Label htmlFor="amount" className="text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
              Amount
            </Label>
            <Input
              id="amount"
              type="text"
              inputMode="numeric"
              className="w-full p-3 rounded-lg border border-neutral-300 dark:border-dark-border bg-white dark:bg-dark-bg"
              placeholder="Enter amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
              Withdraw To
            </Label>
            <RadioGroup
              value={withdrawMethod}
              onValueChange={setWithdrawMethod}
              className="space-y-2"
            >
              <div className="flex items-center space-x-2 border border-neutral-300 dark:border-dark-border rounded-lg p-3 bg-white dark:bg-dark-bg">
                <RadioGroupItem value="bank" id="bank" />
                <Label htmlFor="bank" className="flex-1">Bank Account</Label>
                <Building className="h-4 w-4 mr-1" />
              </div>
              <div className="flex items-center space-x-2 border border-neutral-300 dark:border-dark-border rounded-lg p-3 bg-white dark:bg-dark-bg">
                <RadioGroupItem value="upi" id="upi_withdraw" />
                <Label htmlFor="upi_withdraw" className="flex-1">UPI</Label>
                <BadgeIndianRupee className="h-4 w-4 mr-1" />
              </div>
            </RadioGroup>
          </div>
        </div>

        <DialogFooter className="pt-2">
          <Button
            className="w-full"
            onClick={handleWithdraw}
            disabled={withdrawMutation.isPending || maxAmount <= 0}
          >
            {withdrawMutation.isPending ? "Processing..." : "Withdraw"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
