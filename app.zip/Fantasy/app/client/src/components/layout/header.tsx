import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ArrowLeft, Bell, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

type HeaderProps = {
  title?: string;
  showBack?: boolean;
  backUrl?: string;
  onBackClick?: () => void;
  showProfile?: boolean;
  showNotification?: boolean;
  showWallet?: boolean;
  className?: string;
};

export function Header({
  title,
  showBack = false,
  backUrl = "/",
  onBackClick,
  showProfile = false, // This prop is now ignored as per user's request
  showNotification = false,
  showWallet = true, // Always show wallet instead of profile
  className = "",
}: HeaderProps) {
  const { user } = useAuth();
  
  // Get notification count from API
  const { data: notificationData } = useQuery({
    queryKey: ["/api/get-notification-count"],
    queryFn: async () => {
      const res = await fetch("/api/get-notification-count");
      if (!res.ok) {
        throw new Error("Failed to fetch notification count");
      }
      return res.json();
    },
    // Don't refetch too often - just once per minute
    refetchInterval: 60000,
    // Return default value if not authenticated yet
    initialData: { count: 0 },
    enabled: !!user // Only fetch if user is logged in
  });
  
  const getInitials = (name: string) => {
    return name.split(" ").map(n => n[0]).join("").toUpperCase();
  };

  return (
    <header className={`sticky top-0 z-10 bg-white dark:bg-dark-bg border-b border-neutral-200 dark:border-dark-border ${className}`}>
      <div className="flex justify-between items-center p-4">
        {showBack ? (
          onBackClick ? (
            <Button variant="ghost" size="icon" className="p-2" onClick={onBackClick}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
          ) : (
            <Link href={backUrl}>
              <Button variant="ghost" size="icon" className="p-2">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
          )
        ) : (
          <div className="flex items-center">
            <img 
              src="/images/app-icon.png" 
              alt="11byChatGPT" 
              className="w-10 h-10" 
            />
            <h1 className="font-poppins font-semibold text-lg ml-2">11byChatGPT</h1>
          </div>
        )}
        
        {title && <h1 className="font-medium">{title}</h1>}
        
        <div className="flex items-center gap-3">
          {showNotification && (
            <Link href="/notifications">
              <Button variant="ghost" size="icon" className="relative p-2">
                <Bell className="h-5 w-5" />
                {notificationData.count > 0 && (
                  <span className="absolute top-0 right-0 bg-primary text-white text-xs font-medium rounded-full h-4 w-4 flex items-center justify-center">
                    {notificationData.count}
                  </span>
                )}
              </Button>
            </Link>
          )}
          
          {showWallet && (
            <Link href="/wallet">
              <Button variant="ghost" size="icon" className="relative p-2">
                <Wallet className="h-5 w-5" />
                <span className="absolute top-0 right-0 bg-primary text-white text-xs font-medium rounded-full h-4 w-4 flex items-center justify-center">
                  ₹
                </span>
              </Button>
            </Link>
          )}
          
          {/* Profile photo removed as per user's request */}
        </div>
      </div>
    </header>
  );
}
