import { createContext, ReactNode, useContext, useState } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { insertUserSchema, User as SelectUser } from "@shared/schema";
import { getQueryFn, apiRequest, queryClient } from "../lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { useLocation } from "wouter";
import { RestartAppModal } from "@/components/modals/restart-app-modal";

// Define the user type without the password field and with photoUrl
type SafeUser = Omit<SelectUser, "password">;

type AuthContextType = {
  user: SafeUser | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<SafeUser, Error, LoginData>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<SafeUser, Error, RegisterData>;
  forgotPasswordMutation: UseMutationResult<void, Error, ForgotPasswordData>;
  verifyPhoneMutation: UseMutationResult<void, Error, ForgotPasswordData>;
  resetPasswordMutation: UseMutationResult<void, Error, ResetPasswordData>;
  showRestartPrompt: boolean;
};

type LoginData = {
  username: string; // Using username field for compatibility with Passport LocalStrategy
  password: string;
};

type ForgotPasswordData = {
  phone: string; // For sending OTP
};

type ResetPasswordData = {
  phone: string;
  otp: string;
  newPassword: string;
};

type RegisterData = z.infer<typeof registerSchema>;

const registerSchema = insertUserSchema.extend({
  password: z.string().min(6, "Password must be at least 6 characters"),
  email: z.string().email("Invalid email format"),
  phone: z.string().regex(/^[6-9]\d{9}$/, "Invalid Indian phone number. Must be 10 digits starting with 6-9"),
});

export const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [showRestartPrompt, setShowRestartPrompt] = useState(false);
  
  const {
    data: user,
    error,
    isLoading,
  } = useQuery<SafeUser | null>({
    queryKey: ["/api/user"],
    queryFn: getQueryFn({ on401: "returnNull" }),
    select: (data) => {
      if (!data) return null;
      
      // Log the user data from API to debug
      console.log("User data from API:", {
        id: data.id,
        username: data.username,
        full_name: data.full_name,
        photo_url: data.photo_url || "(no photo URL)"
      });
      
      return data;
    }
  });

  const loginMutation = useMutation<SafeUser, Error, LoginData>({
    mutationFn: async (credentials: LoginData) => {
      try {
        const res = await apiRequest("POST", "/api/login", credentials);
        
        if (!res.ok) {
          // Handle specific error cases
          if (res.status === 401) {
            throw new Error("Invalid credentials");
          } else if (res.status === 429) {
            throw new Error("Too many attempts. Please try again later.");
          } else {
            const errorData = await res.json().catch(() => ({}));
            throw new Error(errorData.message || "Login failed");
          }
        }
        
        return await res.json();
      } catch (error) {
        console.error("Login error:", error);
        throw error;
      }
    },
    onSuccess: (user) => {
      // Set user data in cache
      queryClient.setQueryData(["/api/user"], user);
      
      // Show success toast
      toast({
        title: "Login Successful",
        description: "Welcome back!",
      });
      
      // Show restart prompt instead of redirecting
      setShowRestartPrompt(true);
    },
    onError: (error: Error) => {
      let description = "Please check your credentials and try again.";
      
      if (error.message.includes("Invalid credentials")) {
        description = "Invalid username or password. Please try again.";
      } else if (error.message.includes("Too many attempts")) {
        description = "Too many login attempts. Please try again later.";
      }
      
      toast({
        title: "Login Failed",
        description: description,
        variant: "destructive",
      });
    },
  });

  const registerMutation = useMutation<SafeUser, Error, RegisterData>({
    mutationFn: async (userData: RegisterData) => {
      try {
        const res = await apiRequest("POST", "/api/register", userData);
        
        if (!res.ok) {
          const errorData = await res.json().catch(() => ({}));
          throw new Error(errorData.message || "Registration failed");
        }
        
        return await res.json();
      } catch (error) {
        console.error("Registration error:", error);
        throw error;
      }
    },
    onSuccess: (user) => {
      // Set user data in cache
      queryClient.setQueryData(["/api/user"], user);
      
      // Show success toast
      toast({
        title: "Registration Successful",
        description: "Your account has been created!",
      });
      
      // Show restart prompt instead of redirecting
      setShowRestartPrompt(true);
    },
    onError: (error: Error) => {
      // Check for specific error messages and provide more friendly messages
      let description = "Please try again with different credentials";
      
      if (error.message.includes("Username already exists")) {
        description = "This username is already in use. Please choose a different username.";
      } else if (error.message.includes("Email already exists")) {
        description = "This email is already registered. Please use a different email.";
      } else if (error.message.includes("Invalid referral code")) {
        description = "The referral code you entered is invalid. Please check and try again.";
      }
      
      toast({
        title: "Registration Failed",
        description: description,
        variant: "destructive",
      });
    },
  });

  const logoutMutation = useMutation<void, Error, void>({
    mutationFn: async () => {
      try {
        // Make the logout API call first
        await apiRequest("POST", "/api/logout");
        
        // Clear user data in cache
        queryClient.setQueryData(["/api/user"], null);
        queryClient.removeQueries({ queryKey: ['/api/user'] });
        
        // Safely clear non-essential cached data
        const queryCache = queryClient.getQueryCache();
        queryCache.getAll().forEach(query => {
          // Keep system preferences but clear user-specific data
          if (!String(query.queryKey).includes('preferences')) {
            queryClient.removeQueries({ queryKey: query.queryKey });
          }
        });
        
        // Remove session storage items
        localStorage.removeItem('auth_token');
        sessionStorage.removeItem('user');
        
        return;
      } catch (error) {
        console.error("Logout API error:", error);
        // Even if there's an API error, still clear local data
        queryClient.setQueryData(["/api/user"], null);
        localStorage.removeItem('auth_token');
        sessionStorage.removeItem('user');
        throw error;
      }
    },
    onSuccess: () => {
      toast({
        title: "Logged Out",
        description: "You have been logged out successfully.",
      });
      
      // Show restart prompt instead of redirecting directly
      setShowRestartPrompt(true);
    },
    onError: (error: Error) => {
      console.error("Logout error:", error);
      
      // Even on error, show the restart prompt
      toast({
        title: "Logged Out",
        description: "You have been logged out.",
      });
      
      // Show restart prompt instead of redirecting directly
      setShowRestartPrompt(true);
    },
  });
  
  // Verify phone number before allowing password reset
  const verifyPhoneMutation = useMutation<void, Error, ForgotPasswordData>({
    mutationFn: async (data: ForgotPasswordData) => {
      const res = await apiRequest("POST", "/api/verify-phone", data);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to verify phone number");
      }
      return;
    },
    onSuccess: () => {
      // Phone number is verified, no need for toast
    },
    onError: (error: Error) => {
      toast({
        title: "Phone Verification Failed",
        description: error.message,
        variant: "default",
      });
    },
  });
  
  // Forgot password mutation (keeping for compatibility)
  const forgotPasswordMutation = useMutation<void, Error, ForgotPasswordData>({
    mutationFn: async (data: ForgotPasswordData) => {
      // Since we're not using OTP anymore, this is a no-op
      return;
    },
    onSuccess: () => {
      // No-op since we don't use this anymore
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "default",
      });
    },
  });
  
  // Reset password without OTP verification
  const resetPasswordMutation = useMutation<void, Error, ResetPasswordData>({
    mutationFn: async (data: ResetPasswordData) => {
      const res = await apiRequest("POST", "/api/reset-password", data);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to reset password");
      }
      return;
    },
    onSuccess: () => {
      toast({
        title: "Password Reset Successful",
        description: "Your password has been reset successfully. Please login with your new password.",
      });
    },
    onError: (error: Error) => {
      let description = "Unable to reset your password. Please try again.";
      
      if (error.message.includes("User not found")) {
        description = "No account was found with this phone number. Please check and try again.";
      }
      
      toast({
        title: "Password Reset Failed",
        description: description,
        variant: "default",
      });
    },
  });

  // Render RestartAppModal if prompt is active
  return (
    <AuthContext.Provider
      value={{
        user: user ?? null,
        isLoading,
        error: error as Error | null,
        loginMutation,
        logoutMutation,
        registerMutation,
        forgotPasswordMutation,
        verifyPhoneMutation,
        resetPasswordMutation,
        showRestartPrompt,
      }}
    >
      <RestartAppModal isOpen={showRestartPrompt} />
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
